function ncutility

% ncutility -- Switch to the ncutility directory.
%  ncutility (no arguments) switches to the directory
%   that contains the ncutility routines.
 
% Copyright (C) 1997 Dr. Charles R. Denham, ZYDECO.
%  All Rights Reserved.
%   Disclosure without explicit written consent from the
%    copyright owner does not constitute publication.

setdef ncutility
