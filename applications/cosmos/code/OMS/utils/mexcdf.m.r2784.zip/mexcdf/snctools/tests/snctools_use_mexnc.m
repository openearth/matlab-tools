function tf = snctools_use_mexnc()

tf = ~snctools_use_tmw();


