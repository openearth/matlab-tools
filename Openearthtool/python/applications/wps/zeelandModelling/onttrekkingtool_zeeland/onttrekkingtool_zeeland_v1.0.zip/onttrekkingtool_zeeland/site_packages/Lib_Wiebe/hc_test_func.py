#### IMPORTS ####

from raster_func import *
from plot_func import *
from graph_image_func import *
import StringIO, collections

#### TEST REPORT FUNTIONS ####

def _text2html(s_text):
    for s1,s2 in [["#","&#x0023"],["!","&#x0021"],["<","&lt;"],[">","&gt;"],['"',"&quot;"],["\n","<br/>"]]:
        s_text=s_text.replace(s1,s2)
    return s_text

def _html2html(s_html):
    for s1,s2 in [["#","&&"]]:
        s_html=s_html.replace(s1,s2)
    return s_html

def _text2span(s_text,bold=False,italic=False,color="#000000",size_percentage=100,bookmark=""):
    if bookmark != "":
        s_text='<span style="font-weight: %s; font-style: %s; color: %s; font-size: %s%%"; id="%s">%s</span>' \
            %(["normal","bold"][bold],["normal","italic"][italic],color,size_percentage,bookmark,s_text)
    else:
        s_text='<span style="font-weight: %s; font-style: %s; color: %s; font-size: %s%%">%s</span>' \
            %(["normal","bold"][bold],["normal","italic"][italic],color,size_percentage,s_text)
    s_text=_html2html(s_text)
    return s_text

def set_signals(f_par=""):
    signalsList,signalsHTML=collections.OrderedDict({}),collections.OrderedDict({})
    # symbol,color,font-size,font-weight,font-style
    signalsList["Failure"]=["X","FF0000","100","bold","normal"]
    signalsList["Warning2"]=["&x25B2;","990099","125","normal","normal"]
    signalsList["Warning1"]=["&x25B2;","FF0000","125","normal","normal"]
    signalsList["Warning0"]=["&x25B2;","FFAA00","125","normal","normal"]
    signalsList["Warning"]=["&x25B2;","FFAA00","125","normal","normal"]
    signalsList["Question"]=["?","0099FF","125","bold","normal"]
    signalsList["OK"]=["&x2713;","009900","125","bold","normal"]
    signalsList["Info"]=["i","0000CC","125","bold","normal"]

    f_sig=r"%s\signals.par" %(os.path.dirname(os.path.abspath(sys.argv[0])))
    if os.path.isfile(f_par) or os.path.isfile(f_sig):
        if not os.path.isfile(f_par):
            f_par=f_sig
        inf=open(f_par,"r"); lines=inf.readlines(); inf.close()
        for line in lines:
            try:
                line=line.strip()
                if line[0] != "#":
                    key,symbol,color,size,weight,style=line.split()
                    signalsList[key]=[symbol,color,size,weight,style]
            except:
                pass

    for key in signalsList:
        symbol,color,size,weight,style=signalsList[key]
        if symbol[0] == "&": symbol="&&%s" %(symbol)
        key2=key
        if key2[:7] == "Warning": key2=key2[:7]
        signalsHTML[key]='<span desc="signal%s" style="margin:auto; display:table; font-weight: %s; font-style: %s; color: &&%s; font-size: %s%%">%s</span>' %(key2,weight,style,color,size,symbol)
    return signalsHTML

global signalsHTML
signalsHTML=set_signals()

class testList(object):

    def __init__(self):

        self.list=[]

    def addSignal(self,sig,s_text,bold=False,italic=False,color="#000000",size_percentage=100,add2previous=False,position=-1,bookmark=""):
        if position < 0:
            position=len(self.list)+1+position
            if add2previous:
                position-=1
        s_text=_text2html(s_text)
        s_text=_text2span(s_text,bold,italic,color,size_percentage)
        s_html=signalsHTML[sig]
        if add2previous and len(self.list) != 0:
            self.list[position]+=[('<p>%s</td><td>%s</p>' %(s_html,s_text),)]
        else:
            self.list[position:position]=[[('<p>%s</td><td>%s</p>' %(s_html,s_text),)]]

    def addFailure(self,s_text,bold=False,italic=False,color="#000000",size_percentage=100,add2previous=False,position=-1,bookmark=""):
        self.addSignal(sig="Failure",s_text=s_text,bold=bold,italic=italic,color=color,size_percentage=size_percentage,add2previous=add2previous,position=position,bookmark=bookmark)

    def addWarning(self,s_text,bold=False,italic=False,color="#000000",size_percentage=100,add2previous=False,position=-1,bookmark="",warn_level=0):
        self.addSignal(sig="Warning%d" %(warn_level),s_text=s_text,bold=bold,italic=italic,color=color,size_percentage=size_percentage,add2previous=add2previous,position=position,bookmark=bookmark)

    def addWarning0(self,s_text,bold=False,italic=False,color="#000000",size_percentage=100,add2previous=False,position=-1,bookmark="",warn_level=0):
        self.addSignal(sig="Warning0",s_text=s_text,bold=bold,italic=italic,color=color,size_percentage=size_percentage,add2previous=add2previous,position=position,bookmark=bookmark)

    def addWarning1(self,s_text,bold=False,italic=False,color="#000000",size_percentage=100,add2previous=False,position=-1,bookmark="",warn_level=0):
        self.addSignal(sig="Warning1",s_text=s_text,bold=bold,italic=italic,color=color,size_percentage=size_percentage,add2previous=add2previous,position=position,bookmark=bookmark)

    def addWarning2(self,s_text,bold=False,italic=False,color="#000000",size_percentage=100,add2previous=False,position=-1,bookmark="",warn_level=0):
        self.addSignal(sig="Warning2",s_text=s_text,bold=bold,italic=italic,color=color,size_percentage=size_percentage,add2previous=add2previous,position=position,bookmark=bookmark)

    def addQuestion(self,s_text,bold=False,italic=False,color="#000000",size_percentage=100,add2previous=False,position=-1,bookmark=""):
        self.addSignal(sig="Question",s_text=s_text,bold=bold,italic=italic,color=color,size_percentage=size_percentage,add2previous=add2previous,position=position,bookmark=bookmark)

    def addOK(self,s_text,bold=False,italic=False,color="#000000",size_percentage=100,add2previous=False,position=-1,bookmark=""):
        self.addSignal(sig="OK",s_text=s_text,bold=bold,italic=italic,color=color,size_percentage=size_percentage,add2previous=add2previous,position=position,bookmark=bookmark)

    def addInfo(self,s_text,bold=False,italic=False,color="#000000",size_percentage=100,add2previous=False,position=-1,bookmark=""):
        self.addSignal(sig="Info",s_text=s_text,bold=bold,italic=italic,color=color,size_percentage=size_percentage,add2previous=add2previous,position=position,bookmark=bookmark)

    def addText(self,s_text,title="",bold=False,italic=False,color="#000000",size_percentage=100,add2previous=False,position=-1,bookmark=""):
        if position < 0:
            position=len(self.list)+1+position
            if add2previous:
                position-=1
        s_text=_text2html(s_text)
        if title == "":
            s_text=_text2span(s_text,bold,italic,color,size_percentage,bookmark=bookmark)
        else:
            s_text=_text2span(s_text,bold,italic,color,size_percentage)
            s_title=_text2html(title)
            s_title=_text2span(s_title,bold=True,italic=italic,color=color,size_percentage=size_percentage,bookmark=bookmark)
            s_text="%s<br/>%s" %(s_title,s_text)
        if add2previous and len(self.list) != 0:
            self.list[position]+=[('<p>%s</p>' %(s_text),)]
        else:
            self.list[position:position]=[[('<p>%s</p>' %(s_text),)]]

    def addDoc(self,s_doc,title="",add2previous=False,position=-1,bookmark=""):
        if position < 0:
            position=len(self.list)+1+position
            if add2previous:
                position-=1
        if bookmark != "":
            title='<a id="%s"></a>%s' %(bookmark,title)
        if add2previous and len(self.list) != 0:
            self.list[position]+=[(s_doc,title)]
        else:
            self.list[position:position]=[[(s_doc,title)]]

    def addFigure(self,fig,title="",width="",add2previous=False,position=-1,bookmark="",dpi=100):
        if position < 0:
            position=len(self.list)+1+position
            if add2previous:
                position-=1
        outf=StringIO.StringIO()
        fig.savefig(outf,format="png",dpi=dpi)
        pylab.clf(); pylab.close('all')
        fig=outf.getvalue()
        outf.close()
        if bookmark != "":
            title='<a id="%s"></a>%s' %(bookmark,title)
        if add2previous and len(self.list) != 0:
            self.list[position]+=[(fig,title,width)]
        else:
            self.list[position:position]=[[(fig,title,width)]]

    def addTable(self,arr_table,title="",gray_rowcol="1,0",link=False,add2previous=False,position=-1,bookmark=""):
        if position < 0:
            position=len(self.list)+1+position
            if add2previous:
                position-=1
        if bookmark != "":
            title='<a id="%s"></a>%s' %(bookmark,title)
        if add2previous and len(self.list) != 0:
            self.list[position]+=[(arr_table,title,"",gray_rowcol,["","link"][link])]
        else:
            self.list[position:position]=[[(arr_table,title,"",gray_rowcol,["","link"][link])]]

    def addRaster(self,rA,title="",width="",legend=None,add2previous=False,position=-1,bookmark=""):
        if position < 0:
            position=len(self.list)+1+position
            if add2previous:
                position-=1
        if bookmark != "":
            title='<a id="%s"></a>%s' %(bookmark,title)
        if add2previous and len(self.list) != 0:
            self.list[-1][position:position]=[(rA,title,width,"",legend)]
        else:
            self.list[position:position]=[[(rA,title,width,"",legend)]]

def get_signals():
    return signalsHTML.copy()

def bookmark_link(bookmark,link_text="",arrow=True):
    if arrow:
        link_text+=" %s" %("<b>&&&8680;</b>")
    return '<a href="&&%s"><span style="color: &&0000FF">%s</span></a>' %(bookmark,link_text.strip())

def arr2stats(rA,percentiles=True):

    msk=rA.arr.mask
    if np.rank(msk) == 0:
        msk=np.ones(rA.arr.shape,bool)*msk

    stats={}
    stats["N_cell"]=rA.nrow()*rA.ncol()
    stats["N_nodata"]=msk.sum()
    stats["N_data"]=(msk == False).sum()
    for key in ["mean","std","var","min","max","median"]:
        stats[key]="-"
    l_perc=[]
    if type(percentiles) != bool:
        l_perc=[p for p in percentiles]
        percentiles=True
    else:
        if percentiles:
            l_perc=range(0,101,1)
    if percentiles:
        stats["percentiles"]={}
        for p in l_perc:
            stats["percentiles"]["p%d" %(p)]="-"
    if stats["N_data"] > 0:
        stats["mean"]=rA.mean()
        if stats["N_data"] > 1:
            stats["std"]=rA.std()
            stats["var"]=rA.var()
            stats["min"]=rA.min()
            stats["max"]=rA.max()
            stats["median"]=rA.median()
            if percentiles:
                stats["percentiles"]={}
                for p in l_perc:
                    stats["percentiles"]["p%d" %(p)]=rA.percentile(p)

    return stats

def arr2hist(rA,n_bins=30,l_bounds=None,y_max=None,frm="%s"):

    if type(rA).__name__ == "rasterArr":
        arr_cp=np.compress(np.ravel(rA.arr.mask == False),np.ravel(rA.arr.data))
    elif type(rA).__name__ == "MaskedArray":
        arr_cp=np.compress(np.ravel(rA.mask == False),np.ravel(rA.data))
    else:
        arr_cp=np.ravel(rA)

    if type(l_bounds) == type(None):
        l_bounds=legendScale(arr_cp)
    try:
        l_bounds.getBoundaries()
    except:
        l_bounds=legendScale(l_bounds,len(l_bounds)-1)

    hist=np.histogram(arr_cp,n_bins,[l_bounds.getBoundaries()[0],l_bounds.getBoundaries()[-1]])

    N_under,N_over=(arr_cp < l_bounds.getBoundaries()[0]).sum(),(arr_cp > l_bounds.getBoundaries()[-1]).sum()
    N_tot=hist[0].sum()+N_under+N_over

    bu=np.ones((len(hist[0]),),uint8)
    bl=hist[1][:-1]
    if N_tot == 0:
        bh=np.zeros((len(hist[0]),),float64)
    else:
        bh=np.array(hist[0],float64)/N_tot
    bw=hist[1][1:]-hist[1][:-1]
    if N_under > 0:
        bu=np.insert(bu,[0],[2])
        bl=np.insert(bl,[0],[bl[0]-bw[0]])
        if N_tot == 0:
            bh=np.insert(bh,[0],[0])
        else:
            bh=np.insert(bh,[0],[float(N_under)/N_tot])
        bw=np.insert(bw,[0],[bw[0]])
    if N_over > 0:
        bu=np.insert(bu,[len(bu)],[2])
        bl=np.insert(bl,[len(bl)],[hist[1][-1]])
        if N_tot == 0:
            bh=np.insert(bh,[len(bh)],[0])
        else:
            bh=np.insert(bh,[len(bh)],[float(N_over)/N_tot])
        bw=np.insert(bw,[len(bw)],[bw[-1]])
    bb=np.zeros((len(bu),),float64)
    bh*=100

    if y_max != None:
        yscale=legendScale([0,y_max],5)
    else:
        yscale=legendScale([0,bh.max()],5)

    figdata=[bu.copy(),bl.copy(),bh.copy(),bw.copy(),bb.copy(),[bl[0],bl[-1]+bw[-1]],[0,0]]
    figlist=[[[None],[""],[" ",[bl[0],bl[-1]+bw[-1]],l_bounds.getBoundaries(),l_bounds.getTicks()],["%",[0,yscale.getBoundaries().max()],yscale.getBoundaries(),yscale.getTicks()],[None]]]

    figlist[-1]+=[["b",[0,1,2,3,4],[""],[[[1,(0,0,0)],[2,(0.5,0.5,0.5)]],[[1,1],[2,1]],[[1,(1,1,1)],[2,(1,1,1)]]]]]
    figlist[-1]+=[["l",[5,6],[""],["-",1,(0.5,0.5,0.5)]]]

    if frm != None:
        xrange=bl[-1]+bw[-1]-bl[0]
        x1=bl[-1]+bw[-1]-0.07*xrange
        x2=x1-0.02*xrange
        yrange=yscale.getBoundaries().max()
        i=1
        for s,val in [\
            ["N",len(arr_cp)],\
            ["mean","%s" %(frm) %(arr_cp.mean())],\
            ["stdev","%s" %(frm) %(arr_cp.std())],\
            ["min","%s" %(frm) %(arr_cp.min())],\
            ["p25","%s" %(frm) %(np.percentile(arr_cp,25))],\
            ["p50","%s" %(frm) %(np.percentile(arr_cp,50))],\
            ["p75","%s" %(frm) %(np.percentile(arr_cp,75))],\
            ["max","%s" %(frm) %(arr_cp.max())],\
            ]:
            y=yscale.getBoundaries().max()-i*0.05*yrange
            figdata+=[[y]]
            figlist[-1]+=[["t",[x1,y],[s],["left","bottom"]]]
            figlist[-1]+=[["t",[x2,y],[val],["right","bottom"]]]
            i+=1

    fig=graphfig(figdata=figdata,figlist=figlist,fig=[6,4,0.01,1,1],pars=[[0.08,0.04,0.0,0.08]])

    return fig,N_tot,N_under,N_over
