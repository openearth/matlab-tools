import numpy as np
from scipy.optimize import curve_fit
from copy import deepcopy

def spherical_variogram_nug(x,ran,sil,nug):
    """Calculates the semi-variance according to a spherical variogram with a nugget.
    """
    h=np.array(deepcopy(x),np.float64)
    hs=np.sort(h.copy())
    sil=max(sil,0.0)
    ran=max(ran,(hs[1]-hs[0])/2)
    return np.where(h < ran,(sil-nug)*((3*h)/(2*ran)-(h**3)/(2*ran**3))+nug,sil+nug)

def spherical_variogram(x,ran,sil):
    """Calculates the semi-variance according to a spherical variogram without a nugget.
    """
    return spherical_variogram_nug(x,ran,sil,nug=0.0)

def exponential_variogram_nug(x,ran,sil,nug):
    """Calculates the semi-variance according to a exponential variogram with a nugget.
    """
    h=np.array(deepcopy(x),np.float64)
    hs=np.sort(h.copy())
    sil=max(sil,0.0)
    ran=max(ran,(hs[1]-hs[0])/2)
    return (sil-nug)*(1-np.exp(-h/ran))+nug

def exponential_variogram(x,ran,sil):
    """Calculates the semi-variance according to a exponential variogram without a nugget.
    """
    return exponential_variogram_nug(x,ran,sil,nug=0.0)

def gaussian_variogram_nug(x,ran,sil,nug):
    """Calculates the semi-variance according to a gaussian variogram with a nugget.
    """
    h=np.array(deepcopy(x),np.float64)
    hs=np.sort(h.copy())
    sil=max(sil,0.0)
    ran=max(ran,(hs[1]-hs[0])/2)
    return (sil-nug)*(1-np.exp(-h**2/ran**2))+nug

def gaussian_variogram(x,ran,sil):
    """Calculates the semi-variance according to a gaussian variogram without a nugget.
    """
    return gaussian_variogram_nug(x,ran,sil,nug=0.0)

def nugget_variogram(x,nug):
    """Calculates the semi-variance according to a nugget variogram (constant variogram).
    """
    return np.ones((len(x),),np.float64)*nug

def get_variogram_line(x,variogram,ran,sil,nug):
    """Calculates the semi-variance according to the given variogram.
    """
    x=np.array(deepcopy(x),np.float64)
    h=np.arange(0,x.max(),x.max()/100.0)
    y=[None]*len(h)
    try:
        exec("y=%s_variogram_nug(h,ran=ran,sil=sil,nug=nug)" %(variogram))
    except:
        try:
            exec("y=nugget_variogram(h,nug=nug)" %(variogram))
        except:
            pass
    return h,y

def fit_variogram(x,y,variogram=None,nonug=True):
    """Estimates the variogram (type and parameters) that fits best to the data.
    """
    x=np.array(deepcopy(x),np.float64)
    y=np.array(deepcopy(y),np.float64)
    l_var=["spherical","exponential","gaussian","nugget"]
    if variogram in l_var:
        l_var=[variogram]

    l_result=[]
    for variogram in l_var:
        if variogram == "spherical":
            if nonug:
                nug=0.0
                [ran,sil]=curve_fit(spherical_variogram,x,y,[(x.max()-x.min())/10.0,y.mean()])[0]
            else:
                [ran,sil,nug]=curve_fit(spherical_variogram,x,y,[(x.max()-x.min())/10.0,y.mean(),0.0])[0]
            y2=spherical_variogram_nug(x,ran,sil,nug)
        elif variogram == "exponential":
            if nonug:
                nug=0.0
                [ran,sil]=curve_fit(exponential_variogram,x,y,[(x.max()-x.min())/10.0,y.mean()])[0]
            else:
                [ran,sil,nug]=curve_fit(exponential_variogram,x,y,[(x.max()-x.min())/10.0,y.mean(),0.0])[0]
            y2=exponential_variogram_nug(x,ran,sil,nug)
        elif variogram == "gaussian":
            if nonug:
                nug=0.0
                [ran,sil]=curve_fit(gaussian_variogram,x,y,[(x.max()-x.min())/10.0,y.mean()])[0]
            else:
                [ran,sil,nug]=curve_fit(gaussian_variogram,x,y,[(x.max()-x.min())/10.0,y.mean(),0.0])[0]
            y2=gaussian_variogram_nug(x,ran,sil,nug)
        elif variogram == "nugget":
            ran,sil=0.0,0.0
            [nug]=curve_fit(nugget_variogram,x,y,[y.mean()])[0]
            y2=nugget_variogram(x,nug)

        r2=(np.corrcoef(y,y2)[0,1])**2
        rmse=((y-y2)**2).mean()**0.5
        l_result+=[[variogram,ran,sil,nug,r2,rmse,y2]]

    ii=np.argsort([rec[4] for rec in l_result])[-1]
    return l_result[ii]
