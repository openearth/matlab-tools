"""
    This module contains GIS functions.
"""

__author__  = "Wiebe Borren <Wiebe.Borren@deltares.nl>"
__version__ = "1.0"
__date__    = "Jan 2014"



####################################
## EXTERNAL MODULES AND FUNCTIONS ##
####################################

import string, math, struct
from raster_func import *
from table_func import *
import shapefile
import shapely
from shapely.geometry import Point
from shapely.geometry import Polygon
from rtree import index
from PIL import Image, ImageDraw


#############################
## SHAPEFILES AND GENFILES ##
#############################

def get_gen_data(f_gen,f_table=None,fld_id="ID",l_flds=None,fld_str=None,xy_center=False):
    """Function to get the data of an ArcInfo generate file.

    Parameters
    ----------
    f_gen : str
        The ArcInfo generate file to be converted.

    f_table : str or None (optional)
        Table file containing data linked to the generate file.
        This file may be a comma-separated file (\*.csv), dbf file (\*.dbf), iMOD ipf file (\*.ipf) or space-separated file.

        The table file is structured in fields (columns) and records (rows). It should contain a name for each field.
        Comma-separated and space-separated files should contain 1 header line with the field names.

    fld_id : str or None (optional)
        Field name of the field to link the table data to the IDs of the shapes in the generate file.

    l_flds : list or None (optional)
        List of field names to read. If *l_flds* is None all fields are read.

    fld_str : str or None (optional)
        An arbitrary string which is scanned for occurences of field names.
        Occuring field names will be included in the list of fields to be read.

        Such a string could originate from user input, e.g. a condition string which is specified in an input file for a tool.

    xy_center : bool (optional)
        True = return additionally the x,y coordinates of the centers of the polylines or polygons.

        False = do not return the x,y coordinates of the centers of the polylines or polygons.

    Returns
    -------
    shptype : str
        Type of the shapes: 'POINT', 'POLYLINE' or 'POLYGON'.

    xy : list or numpy ndarray
        The x,y coordinates of the shapes.

        If *shptype* is 'POINT' this is a Nx2 array: [(x1,y1), (x2,y2) ... (xN,yN)].

        If *shptype* is 'POLYLINE' or 'POLYGON' this is a list of Nx2 arrays: [[(x1,y1),(x2,y2) .. (xN,yN)], [(x1,y1),(x2,y2) .. (xM,yM)] ...].

    data : numpy recarray
        The data belonging to the shapes.

        The number of records is equal to the number of shapes (i.e. the length of *xy*).

    xy_center : numpy ndarray
        The x,y coordinates of the centers of the polylines or polygons.

        Only returned if *xy_center* is True.

    i_center : numpy ndarray
        Index numbers of the centers refering to the data array.

        Only returned if *xy_center* is True.
    """
    ## Read file
    inf=open(f_gen,"r"); lines=inf.readlines(); inf.close()

    recs,arr_id=[],[]

    for line in lines:
        line=string.strip(line)
        if len(line) > 0:
            recs+=[string.split(string.replace(line,","," "))]

    ## Gen type and IDs
    if recs[-1][0] == "END" and recs[-2][0] == "END":
        if len(recs[0]) > 2: shptype="POLYGON"
        else: shptype="POLYLINE"
        arr_id+=[int(recs[0][0])]
        for i in range(1,len(recs)-2):
            if recs[i][0] == "END":
                arr_id+=[int(recs[i+1][0])]
    else:
        shptype="POINT"
        for rec in recs:
            if rec[0] != "END":
                arr_id+=[int(rec[0])]

    ## XY
    if shptype == "POINT":
        xy=[]
        for rec in recs:
            if rec[0] != "END":
                xy+=[(float(rec[1]),float(rec[2]))]
        xy=np.array(xy)
    else:
        xy=[[]]
        i=1
        while True:
            if recs[i][0] == "END":
                if shptype == "POLYGON":
                    if xy[-1][0][0] != xy[-1][-1][0] or xy[-1][0][1] != xy[-1][-1][1]:
                        xy[-1]+=[xy[-1][0]]
                xy[-1]=np.array(xy[-1])
                if recs[i+1][0] == "END": break
                xy+=[[]]
                i+=2
            xy[-1]+=[(float(recs[i][0]),float(recs[i][1]))]
            i+=1

    if shptype == "POLYGON":
        for i in range(0,len(xy)):
            if xy[i][0,0] != xy[i][-1,0] or xy[i][0,1] != xy[i][-1,1]:
                xy[i]=np.insert(xy[i],len(xy[i]),xy[i][0],0)

    ## XY center
    if xy_center and shptype in ["POLYLINE","POLYGON"]:
        xy_cen=np.array([np.mean([xy[i].min(0),xy[i].max(0)],0) for i in range(0,len(xy))])
        i_cen=np.arange(0,len(xy))
    else:
        xy_center=False

    ## Data
    if fld_id != None:
        arr_id=np.array(np.array(arr_id,int64),dtype=[(fld_id,int64)])
    else:
        arr_id=np.array(np.array(arr_id,int64),dtype=[("ID",int64)])

    if fld_id != None:
        try:
            try: fld_str+="_%s_" %(fld_id)
            except: fld_str=fld_id
            arr=table2arr(f_table,l_flds=l_flds,fld_str=fld_str)
            if fld_id not in arr.dtype.names: raise
        except:
            arr=arr_id.copy()
    else:
        arr=arr_id.copy()
        fld_id="ID"

    l_id=arr[fld_id].tolist()
    ii=[l_id.index(i) for i in arr_id[fld_id]]
    data=np.take(arr,ii)


    if xy_center:
        return shptype,xy,data,xy_cen,i_cen
    else:
        return shptype,xy,data

def get_shp_data(f_shp,l_flds=None,fld_str=None,xy_center=False,l_extent=None):
    """Function to get the data of an ESRI shape file.

    Parameters
    ----------
    f_shp : str
        The ESRI shape file to be converted.

    l_flds : list or None (optional)
        List of field names to read. If *l_flds* is None all fields are read.

    fld_str : str or None (optional)
        An arbitrary string which is scanned for occurences of field names.
        Occuring field names will be included in the list of fields to be read.

        Such a string could originate from user input, e.g. a condition string which is specified in an input file for a tool.

    xy_center : bool (optional)
        True = return additionally the x,y coordinates of the centers of the polylines or polygons.

        False = do not return the x,y coordinates of the centers of the polylines or polygons.

    l_extent : list (optional)
        A list containing xll, yll, xur and yur of the target extent (in this order).

        Shapes which are entirely outside this extent are not returned.

    Returns
    -------
    shptype : str
        Type of the shapes: 'POINT', 'POLYLINE' or 'POLYGON'.

    xy : list or numpy ndarray
        The x,y coordinates of the shapes.

        If *shptype* is 'POINT' this is a Nx2 array: [(x1,y1), (x2,y2) ... (xN,yN)].

        If *shptype* is 'POLYLINE' or 'POLYGON' this is a list of Nx2 arrays: [[(x1,y1),(x2,y2) .. (xN,yN)], [(x1,y1),(x2,y2) .. (xM,yM)] ...].

    data : numpy recarray
        The data belonging to the shapes.

        The number of records is equal to the number of shapes (i.e. the length of *xy*).

    xy_center : numpy ndarray
        The x,y coordinates of the centers of the polylines or polygons.

        Only returned if *xy_center* is True.

    i_center : numpy ndarray
        Index numbers of the centers refering to the data array.

        Only returned if *xy_center* is True.
    """
    shp=shapefile.Reader(f_shp)
    shapes=shp.shapes()

    ## Shp type
    shptype=["","POINT","","POLYLINE","","POLYGON"][shapes[0].shapeType]

    ## XY and XY center
    if shptype == "POINT":
        xy=np.array([shapes[i].points[0] for i in range(0,len(shapes))])
        ii=np.arange(0,len(shapes))
        xy_center=False
        if l_extent != None:
            cp=(xy[:,0] >= l_extent[0])*(xy[:,0] <= l_extent[2])*(xy[:,1] >= min(l_extent[1],l_extent[3]))*(xy[:,1] <= max(l_extent[1],l_extent[3]))
            xy=np.compress(cp,xy,0)
            ii=np.compress(cp,ii,0)
    else:
        xy,ii=[],[]
        if xy_center:
            xy_cen=np.zeros((len(shapes),2),float64)
            i_cen=np.ones((len(shapes),),int32)*-1
            i_cen_ii=[]
        for i in range(0,len(shapes)):
            pnts=np.array(shapes[i].points)
            try: prts=shapes[i].parts.tolist()+[len(pnts)]
            except: prts=[0,len(pnts)]
            i0=len(ii)
            for p in range(0,len(prts)-1):
                xy0=pnts[prts[p]:prts[p+1]]
                if l_extent != None:
                    if not (xy0[:,0].min() > l_extent[2] or xy0[:,0].max() < l_extent[0] or xy0[:,1].min() > max(l_extent[1],l_extent[3]) or xy0[:,1].max() < min(l_extent[1],l_extent[3])):
                        xy+=[xy0]
                        ii+=[i]
                else:
                    xy+=[xy0]
                    ii+=[i]
            i1=len(ii)
            if xy_center and i1 > i0:
                xystat=[np.array([0,0],float64),0]
                for j in range(i0,i1):
                    xystat[0]+=xy[j].sum(0); xystat[1]+=len(xy[j])
                if xystat[1] > 0:
                    xy_cen[i]=xystat[0]/xystat[1]
                    i_cen[i]=i0
                i_cen_ii+=[range(i0,i1)]

        ii=np.array(ii)

    if shptype == "POLYGON":
        for i in range(0,len(xy)):
            if xy[i][0,0] != xy[i][-1,0] or xy[i][0,1] != xy[i][-1,1]:
                xy[i]=np.insert(xy[i],len(xy[i]),xy[i][0],0)

    ## Data
    arr=table2arr("%s.dbf" %(f_shp[:-4]),l_flds=l_flds,fld_str=fld_str)
    data=np.take(arr,ii.tolist())

    if xy_center:
        cp=(i_cen != -1)
        return shptype,xy,data,np.compress(cp,xy_cen,0),np.compress(cp,i_cen,0),i_cen_ii
    else:
        return shptype,xy,data

def get_iff_data(f_iff,shptype="POLYLINE",line_parts=True):
    """Function to get the data of an iMOD iff file.

    Parameters
    ----------
    f_iff : str
        The iMOD iff file to be read.

    shptype : str (optional)
        Type of the shapes to be returned: 'POINT' or 'POLYLINE'.

    line_parts : bool (optional)
        True = polylines are returned in parts (individual line segments); only relevant if *shptype* is 'POLYLINE'.

        False = polylines are returned as whole lines (multi segments).

    Returns
    -------
    shptype : str
        Type of the shapes: 'POINT' or 'POLYLINE'.

    xy : list or numpy ndarray
        The x,y coordinates of the shapes.

        If *shptype* is 'POINT' this is a Nx2 array: [(x1,y1), (x2,y2) ... (xN,yN)].

        If *shptype* is 'POLYLINE' this is a list of Nx2 arrays: [[(x1,y1),(x2,y2) .. (xN,yN)], [(x1,y1),(x2,y2) .. (xM,yM)] ...].

    data : numpy recarray
        The data belonging to the shapes.

        The number of records is equal to the number of shapes (i.e. the length of *xy*).

        If *shptype* is 'POINT' the fields are: 'particle', 'lay', 'row', 'col', 'x', 'y', 'z', 'time', 'velocity'.

        If *shptype* is 'POLYLINE' the fields are: 'particle', 'lay_start', 'row_start', 'col_start', 'x_start', 'y_start', 'z_start', 'time_start', 'lay_end', 'row_end', 'col_end', 'x_end', 'y_end', 'z_end', 'time_end', 'velocity'.
    """
    shptype=shptype.upper()
    if shptype != "POINT":
        shptype="POLYLINE"
    dt=[("particle",int32),("lay",int32),("x",float32),("y",float32),("z",float32),("time",float32),("velocity",float32),("row",int32),("col",int32)]
    inf=open(f_iff,"r")
    ncol=int(inf.readline())
    for i in range(0,ncol): inf.readline()
    data=re.findall(r'[^,\n]+',inf.read())
    data=np.array([tuple(data[i:i+9]) for i in range(0,len(data),9)],dtype=dt)
    data=data[["particle","lay","row","col","x","y","z","time","velocity"]]
    inf.close()

    if shptype == "POINT":
        xy=np.zeros((len(data),2),float32)
        xy[:,0]=data["x"]
        xy[:,1]=data["y"]
    else:
        dt=[("particle",int32),\
            ("lay_start",int32),("row_start",int32),("col_start",int32),\
            ("x_start",float32),("y_start",float32),("z_start",float32),\
            ("time_start",float32),\
            ("lay_end",int32),("row_end",int32),("col_end",int32),\
            ("x_end",float32),("y_end",float32),("z_end",float32),\
            ("time_end",float32),\
            ("time_average",float32),\
            ("velocity",float32)]
        ii=np.compress((data["particle"][1:]-data["particle"][:-1]) != 0,np.arange(0,len(data)-1),0)+1
        ii=np.insert(ii,0,0,0)
        ii=np.insert(ii,len(ii),len(data),0)
        if line_parts:
            jj=[]
            for i in range(0,len(ii)-1):
                jj+=range(ii[i],ii[i+1]-1)
            ii=np.insert(jj,len(jj),len(data),0)
        xy=[]
        for p in range(0,len(ii)-1):
            xy+=[np.swapaxes(np.array([data["x"][ii[p]:ii[p+1]],data["y"][ii[p]:ii[p+1]]]),0,1)]
        data2=np.zeros((len(ii)-1,),dtype=dt)
        for f1,f2 in [["particle","particle"], ["lay_start","lay"], ["row_start","row"], ["col_start","col"], ["x_start","x"], ["y_start","y"], ["z_start","z"], ["time_start","time"]]:
            data2[f1]=data[f2][ii[:-1]]
        for f1,f2 in [["lay_end","lay"], ["row_end","row"], ["col_end","col"], ["x_end","x"], ["y_end","y"], ["z_end","z"], ["time_end","time"]]:
            data2[f1]=data[f2][ii[1:]-1]
        if line_parts:
            data2["velocity"]=data["velocity"][ii[:-1]+1]
        else:
            pass

        data2["time_average"]=0.5*data2["time_start"]+0.5*data2["time_end"]

        data=data2

    return shptype,xy,data

def get_isg_data(f_isg):
    """Function to get the data of an iMOD isg file.

    Parameters
    ----------
    f_isg : str
        The iMOD isg file to be read.

    Returns
    -------
    result : tuple
        Three sets of data: the isg lines, the isd1 (calculation) points and the isc1 (cross section) points:

        (isg shptype,isg xy,isg data), (isd1 shptype,isd1 xy,isd1 data), (isc1 shptype,isc1 xy,isc1 data)

        Isg:

        - shptype : 'POLYLINE'.

        - xy : list of Nx2 arrays: [[(x1,y1),(x2,y2) .. (xN,yN)], [(x1,y1),(x2,y2) .. (xM,yM)] ...].

        - data : numpy recarray with the data belonging to the lines.

        Isd1 and isc1:

        - shptype : 'POINT'.

        - xy : Nx2 array: [(x1,y1), (x2,y2) ... (xN,yN)].

        - data : numpy recarray with the data belonging to the points.
    """
    f_isg="%s.isg" %(os.path.splitext(f_isg)[0])
    f_isp="%s.isp" %(os.path.splitext(f_isg)[0])
    f_isd1="%s.isd1" %(os.path.splitext(f_isg)[0])
    f_isc1="%s.isc1" %(os.path.splitext(f_isg)[0])

    inf_isg=open(f_isg)
    inf_isp=open(f_isp,"rb")
    inf_isd1=open(f_isd1,"rb")
    inf_isc1=open(f_isc1,"rb")
    mm_isp=mmap.mmap(inf_isp.fileno(),0,access=mmap.ACCESS_READ)
    mm_isd1=mmap.mmap(inf_isd1.fileno(),0,access=mmap.ACCESS_READ)
    mm_isc1=mmap.mmap(inf_isc1.fileno(),0,access=mmap.ACCESS_READ)

    isg_data,isg_xy=[],[]
    isd1_data,isd1_xy=[],[]
    isc1_data,isc1_xy=[],[]

    n=int(inf_isg.readline())
    for i in range(0,n):
        ## ISG
        rec=inf_isg.readline().split(",")
        label=string.join(rec[:-10],",").replace('"',"").strip()
        iseg,nseg,iclc,nclc,icrs,ncrs,istw,nstw,iqhr,nqhr=[int(v) for v in rec[-10:]]

        # ISP
        mm_isp.seek(8*iseg)
        xy=np.fromstring(mm_isp.read(8*nseg),dtype=float32).reshape((nseg,2))

        dist=np.insert(np.add.accumulate((((xy[1:]-xy[:-1])**2).sum(1))**0.5),0,0)

        # ISD1
        mm_isd1.seek(44*iclc)
        l_d,l_cname=[],[]
        for j in range(0,nclc):
            d,cname=struct.unpack("=llf32s",mm_isd1.read(44))[2:4]
            l_d+=[d]
            l_cname+=[cname]
        l_x=np.interp(l_d,dist,xy[:,0])
        l_y=np.interp(l_d,dist,xy[:,1])

        isd1_data+=[(l_cname[j].strip(),label) for j in range(0,len(l_cname))]
        isd1_xy+=[(l_x[j],l_y[j]) for j in range(0,len(l_cname))]

        # ISC1
        mm_isc1.seek(44*icrs)
        l_d,l_cname=[],[]
        for j in range(0,ncrs):
            d,cname=struct.unpack("=llf32s",mm_isc1.read(44))[2:4]
            l_d+=[d]
            l_cname+=[cname]
        l_x=np.interp(l_d,dist,xy[:,0])
        l_y=np.interp(l_d,dist,xy[:,1])

        isc1_data+=[(l_cname[j].strip(),label) for j in range(0,len(l_cname))]
        isc1_xy+=[(l_x[j],l_y[j]) for j in range(0,len(l_cname))]

        # ISG
        isg_data+=[(label,nclc,ncrs)]
        isg_xy+=[xy]

    mm_isp.close()
    mm_isd1.close()
    mm_isc1.close()

    inf_isg.close()
    inf_isp.close()
    inf_isd1.close()
    inf_isc1.close()

    isg_dt=[("label","a200"),("nclc",uint32),("ncrs",uint32)]
    isd1_dt=[("cname","a200"),("label_isg","a200")]
    isc1_dt=[("cname","a200"),("label_isg","a200")]

    isg_data=np.array(isg_data,dtype=isg_dt)
    isd1_data=np.array(isd1_data,dtype=isd1_dt)
    isc1_data=np.array(isc1_data,dtype=isc1_dt)

    isd1_xy=np.array(isd1_xy)
    isc1_xy=np.array(isc1_xy)

    return ('POLYLINE',isg_xy,isg_data),('POINT',isd1_xy,isd1_data),('POINT',isc1_xy,isc1_data)

def write_gen(f_gen,xy,shptype=None,data=None,fld_id=None,f_table=None):
    """Function to write an ArcInfo generate file.

    Parameters
    ----------
    f_gen : str
        The ArcInfo generate file to be created.

    xy : list or numpy ndarray
        The x,y coordinates of the shapes.

        If the type of the shapes is 'POINT' this should be a Nx2 array: [(x1,y1), (x2,y2) ... (xN,yN)].

        If the type of the shapes is 'POLYLINE' or 'POLYGON' this should be a list of Nx2 arrays: [[(x1,y1),(x2,y2) .. (xN,yN)], [(x1,y1),(x2,y2) .. (xM,yM)] ...].

    shptype : str or None (optional)
        Type of the shapes: 'POINT', 'POLYLINE' or 'POLYGON'.

        If *shptype* is None the type is determined from *xy*. If the shapes are points *shptype* is ignored.

    data : numpy recarray or None (optional)
        The data belonging to the shapes.

        The number of records should be equal to the number of shapes (i.e. the length of *xy*).

    fld_id : str or None (optional)
        Field name of the field in the data array to be used for the IDs of the shapes in the generate file.

        If *fld_id* is None or can not be linked to the data array of *data* then the IDs will be index numbers.

        If the field contains non-unique values then the IDs will be index numbers.

    f_table : str or None (optional)
        Table file to be created, containing the data of *data*.
        This file may be a comma-separated file (\*.csv), dbf file (\*.dbf), iMOD ipf file (\*.ipf) or space-separated file.

        If *f_table* is None or *data* is None no table file will be created.
    """
    if type(xy) == list:
        if xy[0][0][0] == xy[0][-1][0] and xy[0][0][1] == xy[0][-1][1]:
            shptype0="POLYGON"
        else:
            shptype0="POLYLINE"
    else:
        shptype0="POINT"
    if shptype == None:
        shptype=shptype0
    elif shptype0 == "POINT":
        shptype=shptype0

    if type(data) != type(None):
        if len(data) != len(xy):
            raise Exception, "Number of records in data is not equal to the number of shapes"

    try:
        if fld_id == None:
            raise
        l_id=data[fld_id]
        if len(l_id) != len(xy):
            raise
    except:
        l_id=np.arange(1,len(xy)+1)

    outf=open(f_gen,"w")
    if shptype == "POINT":
        for i in range(0,len(xy)):
            outf.write("%s,%s,%s\n" %(l_id[i],xy[i,0],xy[i,1]))
        outf.write("END\n")
    elif shptype == "POLYLINE":
        for i in range(0,len(xy)):
            outf.write("%s\n" %(l_id[i]))
            for j in range(0,len(xy[i])):
                outf.write("%s,%s\n" %(xy[i][j,0],xy[i][j,1]))
            outf.write("END\n")
        outf.write("END\n")
    else:
        for i in range(0,len(xy)):
            xcen,ycen=np.mean([xy[i][:,0].min(),xy[i][:,0].max()]),np.mean([xy[i][:,1].min(),xy[i][:,1].max()])
            outf.write("%s,%s,%s\n" %(l_id[i],xcen,ycen))
            for j in range(0,len(xy[i])):
                outf.write("%s,%s\n" %(xy[i][j,0],xy[i][j,1]))
            if xy[i][0,0] != xy[i][-1,0] or xy[i][0,1] != xy[i][-1,1]:
                outf.write("%s,%s\n" %(xy[i][0,0],xy[i][0,1]))
            outf.write("END\n")
        outf.write("END\n")
    outf.close()

    if f_table != None:
        try: arr2table(data,f_table)
        except: pass

def write_shp(f_shp,xy,shptype=None,data=None):
    """Function to write an ESRI shape file.

    Parameters
    ----------
    f_shp : str
        The ESRI shape file to be created.

    xy : list or numpy ndarray
        The x,y coordinates of the shapes.

        If the type of the shapes is 'POINT' this should be a Nx2 array: [(x1,y1), (x2,y2) ... (xN,yN)].

        If the type of the shapes is 'POLYLINE' or 'POLYGON' this should be a list of Nx2 arrays: [[(x1,y1),(x2,y2) .. (xN,yN)], [(x1,y1),(x2,y2) .. (xM,yM)] ...].

    shptype : str or None (optional)
        Type of the shapes: 'POINT', 'POLYLINE' or 'POLYGON'.

        If *shptype* is None the type is determined from *xy*. If the shapes are points *shptype* is ignored.

    data : numpy recarray or None (optional)
        The data belonging to the shapes.

        The number of records should be equal to the number of shapes (i.e. the length of *xy*).
    """
    if type(xy) == list:
        if xy[0][0][0] == xy[0][-1][0] and xy[0][0][1] == xy[0][-1][1]:
            shptype0="POLYGON"
        else:
            shptype0="POLYLINE"
    else:
        shptype0="POINT"
    if shptype == None:
        shptype=shptype0
    elif shptype0 == "POINT":
        shptype=shptype0

    if type(data) != type(None):
        if len(data) != len(xy):
            raise Exception, "Number of records in data is not equal to the number of shapes"
    else:
        data=np.array(np.arange(1,len(xy)+1),dtype=[("ID",int32)])

    dbfspecs=arr2dbfspecs(data)

    exec("shp=shapefile.Writer(shapefile.%s)" %(shptype))
    for i in range(0,len(data.dtype)):
        shp.field(data.dtype.names[i],dbfspecs[i][0],dbfspecs[i][1],dbfspecs[i][2])

    if shptype == "POINT":
        for i in range(0,len(xy)):
            shp.point(xy[i][0],xy[i][1])
    elif shptype == "POLYLINE":
        for i in range(0,len(xy)):
            shp.line(parts=[xy[i]])
    else:
        for i in range(0,len(xy)):
            shp.poly(parts=[xy[i]])

##    for j in range(0,len(xy)):
##        s_rec=""
##        for i in range(0,len(data.dtype)):
##            if dbfspecs[i][0] == "C":
##                s_rec+=",'%s'" %(data[data.dtype.names[i]][j])
##            else:
##                s_rec+=",%s" %(data[data.dtype.names[i]][j])
##        exec("shp.record(%s)" %(s_rec[1:]))

    shp.save(f_shp)

    arr2table(data,"%s.dbf" %(os.path.splitext(f_shp)[0]))

def write_isg(f_lines,f_points,f_isg,fld_points=["ILINE","DIST","ZP","WP","BOT","RES","INF"],startendyr=[1980,2020],l_crs=[2.0,10.0,25.0]):
    """Function to write an iMOD isg file.

    The isg file is based on a line shape file (water courses) and a point shape file (calculation points on the lines).

    Parameters
    ----------
    f_lines : str
        File name of the line shape file.

    f_points : str
        File name of the point shape file.

    f_isg : str
        File name of the isg file.

    fld_points : list or tuple (optional)
        List of the necessary field names of the point shape file: line index number corresponding to the line shape file, distance on the line, summer level, winter level, bottom level, resistance, infiltration factor.

    startendyr : list or tuple (optional)
        List with start year and end year of the summer/winter level time series.

    l_crs : list or tuple (optional)
        List with the parameter values for the default cross section: width, depth, K-manning.
    """
    startyr,endyr=[int(v) for v in startendyr[:2]]
    l_date=[startyr*10000+101]
    l_zpwp=[1]
    for yr in range(startyr,endyr+1):
        l_date+=[yr*10000+401]
        l_zpwp+=[0]
        l_date+=[yr*10000+1001]
        l_zpwp+=[1]
    l_date=[struct.pack("=L",d) for d in l_date]

    wid,dep,km=[float(v) for v in l_crs[:3]]
    l_crs=[\
        [(-wid/2,dep,km),\
         (-wid/2,0.0,km),\
         (wid/2,0.0,km),\
         (wid/2,dep,km)],\
        ]
    l_isc=[]
    for i_crs in range(0,len(l_crs)):
        l_isc+=[[]]
        for dist,bot,km in l_crs[i_crs]:
            l_isc[-1]+=[struct.pack("=3f",dist,bot,km)]


    shptype,xy_lines,data_lines=get_shp_data(f_lines)
    shptype,xy_points,data_points=get_shp_data(f_points)


    outf_isg=open(r"%s.ISG" %(os.path.splitext(f_isg)[0]),"w")
    outf_isp=open(r"%s.ISP" %(os.path.splitext(f_isg)[0]),"wb")
    outf_isd1=open(r"%s.ISD1" %(os.path.splitext(f_isg)[0]),"wb")
    outf_isd2=open(r"%s.ISD2" %(os.path.splitext(f_isg)[0]),"wb")
    outf_isc1=open(r"%s.ISC1" %(os.path.splitext(f_isg)[0]),"wb")
    outf_isc2=open(r"%s.ISC2" %(os.path.splitext(f_isg)[0]),"wb")
    outf_ist1=open(r"%s.IST1" %(os.path.splitext(f_isg)[0]),"wb")
    outf_ist2=open(r"%s.IST2" %(os.path.splitext(f_isg)[0]),"wb")
    outf_isq1=open(r"%s.ISQ1" %(os.path.splitext(f_isg)[0]),"wb")
    outf_isq2=open(r"%s.ISQ2" %(os.path.splitext(f_isg)[0]),"wb")

    outf_isg.write("%d\n" %(len(xy_lines)))
    outf_isp.write(struct.pack("=2L",2295,0))
    outf_isd1.write(struct.pack("=11L",11511,0,0,0,0,0,0,0,0,0,0))
    outf_isd2.write(struct.pack("=5L",5367,0,0,0,0))
    outf_isc1.write(struct.pack("=11L",11511,0,0,0,0,0,0,0,0,0,0))
    outf_isc2.write(struct.pack("=3L",3319,0,0))
    outf_ist1.write(struct.pack("=11L",11511,0,0,0,0,0,0,0,0,0,0))
    outf_ist2.write(struct.pack("=3L",3319,0,0))
    outf_isq1.write(struct.pack("=11L",11511,0,0,0,0,0,0,0,0,0,0))
    outf_isq2.write(struct.pack("=4L",4343,0,0,0))

    iseg=1
    iclc=1
    icrs=1
    istw=0
    iqhr=0
    iref_isd=1
    iref_isc=1

    for i_line in range(0,len(xy_lines)):

        cp_points=data_points[fld_points[0]] == i_line
        ii_points=np.arange(0,len(xy_points))[cp_points]

        nseg=len(xy_lines[i_line])
        nclc=len(ii_points)
        ncrs=len(l_isc)
        nstw=0
        nqhr=0

        outf_isg.write('"Segment %06d",%d,%d,%d,%d,%d,%d,%d,%d,%d,%d\n' %(i_line+1,iseg,nseg,iclc,nclc,icrs,ncrs,istw,nstw,iqhr,nqhr))

        outf_isp.write(np.array(xy_lines[i_line],float32).tostring())

        for i_clc in range(0,nclc):

            i_point=ii_points[i_clc]

            nref_isd=len(l_date)

            dist=float(data_points[fld_points[1]][i_point])
            cname="%-32s" %("Clc %04d on Seg %06d" %(i_clc+1,i_line+1))

            outf_isd1.write(struct.pack("=2L f 32s",nref_isd,iref_isd,dist,cname))

            zp=float(data_points[fld_points[2]][i_point])
            wp=float(data_points[fld_points[3]][i_point])
            btml=float(data_points[fld_points[4]][i_point])
            resis=float(data_points[fld_points[5]][i_point])
            inff=float(data_points[fld_points[6]][i_point])

            l_wlvl=[struct.pack("=4f",zp,btml,resis,inff),\
                    struct.pack("=4f",wp,btml,resis,inff)]

            for i_isd in range(0,nref_isd):

                idate=l_date[i_isd]
                wlvl=l_wlvl[l_zpwp[i_isd]]

                outf_isd2.write(idate+wlvl)

            iref_isd+=nref_isd

        for i_crs in range(0,ncrs):

            nref_isc=len(l_isc[i_crs])

            dist=(data_points[fld_points[1]][cp_points].max()/(ncrs+1.0))*(i_crs+1)
            cname="%-32s" %("Crs %04d on Seg %06d" %(i_crs+1,i_line+1))

            outf_isc1.write(struct.pack("=2L f 32s",nref_isc,iref_isc,dist,cname))

            for i_isc in range(0,nref_isc):

                outf_isc2.write(l_isc[i_crs][i_isc])

            iref_isc+=nref_isc

        iseg+=nseg
        iclc+=nclc
        icrs+=ncrs
        istw+=nstw
        iqhr+=nqhr

    outf_isg.close()
    outf_isp.close()
    outf_isd1.close()
    outf_isd2.close()
    outf_isc1.close()
    outf_isc2.close()
    outf_ist1.close()
    outf_ist2.close()
    outf_isq1.close()
    outf_isq2.close()

def gen2shp(f_gen,f_shp,f_table=None,fld_id="ID"):
    """Function to convert an ArcInfo generate file into an ESRI shapefile.

    Parameters
    ----------
    f_gen : str
        The ArcInfo generate file to be converted.

    f_shp : str
        The ESRI shapefile to be created (\*.shp).

    f_table : str or None (optional)
        Table file containing data to be included in the shapefile.
        This file may be a comma-separated file (\*.csv), dbf file (\*.dbf), iMOD ipf file (\*.ipf) or space-separated file.

        The table file is structured in fields (columns) and records (rows). It should contain a name for each field.
        Comma-separated and space-separated files should contain 1 header line with the field names.

    fld_id : str or None (optional)
        Field name of the field to link the table data to the IDs of the shapes in the generate file.

        If *f_table* is specified and *fld_id* is not a field name in *f_table* then an error is raised.

        If *f_table* is not specified then *fld_id* is used as field name for the IDs of the shapes in the generate file.
        However, if *fld_id* is None in this case then the default name 'ID' is used.

    See Also
    --------
    :ref:`gen_file`
    """
    shptype,xy,data=get_gen_data(f_gen,f_table=f_table,fld_id=fld_id,l_flds=None,fld_str=None,xy_center=False)
    write_shp(f_shp,xy,shptype=shptype,data=data)

def shp2gen(f_shp,f_gen,fld_id=None,f_table=None):
    """Function to convert an ESRI shapefile into an ArcInfo generate file.

    Parameters
    ----------
    f_shp : str
        The ESRI shapefile to be converted (\*.shp).

    f_gen : str
        The ArcInfo generate file to be created.

    fld_id : str or None (optional)
        Field name of the field to be used for the IDs of the shapes in the generate file.

        If *fld_id* is None then the first field of the shapefile is used.

    f_table : str or None (optional)
        Table file to be created, containing the data from the shapefile.
        This file may be a comma-separated file (\*.csv), dbf file (\*.dbf), iMOD ipf file (\*.ipf) or space-separated file.

    See Also
    --------
    :ref:`shapefile`
    """
    shptype,xy,data=get_shp_data(f_shp,l_flds=None,fld_str=None,xy_center=False)
    write_gen(f_gen,xy,shptype=shptype,data=data,fld_id=fld_id,f_table=f_table)


############################
## SHAPEFILES AND RASTERS ##
############################

def shp2arr(f_shape,gi,field=None,nodata=None,set_gi_extent=True,all_touched=False):
    """Function to rasterize an ESRI shapefile using GDAL's RasterizeLayer function.

    Does not work to create non-equidistant rasters.

    Parameters
    ----------
    f_shape : str
        Shapefile.

        Recognized features are point, line and polygon shapefiles. Multi-part features are supported.

    gi : list or dict
        Dict or list with basic geographical information according to rasterArr object.

        See :ref:`geo_info`

        The geographical information is used to set the cell sizes, cell boundaries and (depending on *set_gi_extent*) the extent.

    field : str or None (optional)
        Name of the field to be rasterized.

        If *field* is None or does not exist in the shapefile the shapes are rasterized to the value 1.
        This is faster than rasterizing a specific field.

    nodata : float, int or None (optional)

    set_gi_extent : bool (optional)
        True = the extent is taken from *gi*.

        False = the extent is taken from the shapefile itself. The cell sizes and cell boundaries are taken from *gi*.

    all_touched : bool (optional)
         True  = Option to rasterize shapefiles using all cells that touch the border of the shape.

         False = Option disabled.

    Returns
    -------
    result : rasterArr object
    """
    import osgeo.ogr

    l_data_type=[["Byte","UInt16","Int16","UInt32","Int32","Float32","Float64","CInt16","CInt32","CFloat32","CFloat64"],\
                 [osgeo.gdal.GDT_Byte,osgeo.gdal.GDT_UInt16,osgeo.gdal.GDT_Int16,osgeo.gdal.GDT_UInt32,osgeo.gdal.GDT_Int32,osgeo.gdal.GDT_Float32,osgeo.gdal.GDT_Float64,osgeo.gdal.GDT_CInt16,osgeo.gdal.GDT_CInt32,osgeo.gdal.GDT_CFloat32,osgeo.gdal.GDT_CFloat64],\
                 [uint8,uint16,int16,uint32,int32,float32,float64,int16,int32,float32,float64],\
                 ["B","H","h","L","l","f","d","h","l","f","d"]]

    shp=osgeo.ogr.Open(f_shape)
    shplay=shp.GetLayer()

    shpdef=shplay.GetLayerDefn()
    if field not in [shpdef.GetFieldDefn(i).GetName() for i in range(0,shpdef.GetFieldCount())]:
        field=None

    if field != None:
        f_dbf="%s.dbf" %(f_shape[:-4])
        dbf2fields_specs
        data=table2arr(f_dbf,l_flds=[field])[field]
        dt=data.dtype
        if nodata == None:
            nodata=_get_prefered_nodata(data)
    else:
        dt=uint8
        nodata=0

    gi=gi2dict(gi)
    if not set_gi_extent:
        xmin,xmax,ymin,ymax=shplay.GetExtent()
        if ymin > ymax:
            ymin,ymax=ymax,ymin
        xmin,xmax=_rounddown(xmin,gi["dx"]),_roundup(xmax,gi["dx"])
        ymin,ymax=_rounddown(ymin,gi["dy"]),_roundup(ymax,gi["dy"])
        if gi["proj"] == 1:
            gi=gi_set_extent(gi,[xmin,ymin,xmax,ymax],True)
        else:
            gi=gi_set_extent(gi,[xmin,ymax,xmax,ymin],True)

    rot1,rot2=0,0
    rast=osgeo.gdal.GetDriverByName("MEM").Create("",gi["ncol"],gi["nrow"],1,l_data_type[1][l_data_type[2].index(dt)])
    rast.SetGeoTransform([gi["xll"],gi["dx"],rot1,gi_get_yur(gi),rot2,-gi["dy"]])
    rast.GetRasterBand(1).WriteArray(np.ones((gi["nrow"],gi["ncol"]),dt)*nodata)

    if field != None:
        osgeo.gdal.RasterizeLayer(rast,[1],shplay,burn_values=[1],options=["ATTRIBUTE=%s" %(field),"ALL_TOUCHED=%s" %(str(all_touched).upper())])
    else:
        osgeo.gdal.RasterizeLayer(rast,[1],shplay,burn_values=[1],options=["ALL_TOUCHED=%s" %(str(all_touched).upper())])

    arr=np.fromstring(rast.GetRasterBand(1).ReadRaster(0,0,gi["ncol"],gi["nrow"],gi["ncol"],gi["nrow"],l_data_type[1][l_data_type[2].index(dt)]),dt).reshape(gi["nrow"],gi["ncol"])
    del rast
    arr=rasterArr(arr,gi,nodata)

    return arr

def shp2arr_refined(f_shape,gi,field=None,nodata=None,set_gi_extent=True,downscale_factor=5,x_split=5,y_split=5,frac=0.5,method="mean"):
    """Function to rasterize an ESRI shapefile using GDAL's RasterizeLayer function by using a refined underlying grid.

    Does not work to create non-equidistant rasters.

    Parameters
    ----------
    f_shape : str
        Shapefile.

        Recognized features are point, line and polygon shapefiles. Multi-part features are supported.

    gi : list or dict
        Dict or list with basic geographical information according to rasterArr object.

        See :ref:`geo_info`

        The geographical information is used to set the cell sizes, cell boundaries and (depending on *set_gi_extent*) the extent.

    field : str or None (optional)
        Name of the field to be rasterized.

        If *field* is None or does not exist in the shapefile the shapes are rasterized to the value 1.
        This is faster than rasterizing a specific field.

    nodata : float, int or None (optional)

    set_gi_extent : bool (optional)
        True = the extent is taken from *gi*.

        False = the extent is taken from the shapefile itself. The cell sizes and cell boundaries are taken from *gi*.

    downscale_factor : int (optional)
        Downscaling factor (refinement factor); 1 or greater.

    x_split : int (optional)
        Number of times the grid is splitted in x direction; 1 or greater. Grid splitting is needed to avoid memory errors if the refined grid become to large.

    y_split : int (optional)
        Number of times the grid is splitted in y direction; 1 or greater. Grid splitting is needed to avoid memory errors if the refined grid become to large.

    frac : float (optional)
        Fraction (range 0-1). This fraction is used in the upscaling to determine which resulting cells are covered by the shape and which not.

    method : str or None (optional)
        The rescaling/resampling method for upscaling the refined grid to the final grid. Possible methods are:
        'sum', 'min', 'max', 'harm', 'log10', 'log', 'mean', 'sample', None.

    Returns
    -------
    result : rasterArr object
    """
    downscale_factor=max(int(downscale_factor+0.5),1)
    x_split,y_split=int(x_split+0.5),int(y_split+0.5)
    frac=float(frac)

    xll,yll,xur,yur=gi["xll"],gi["yll"],gi_get_xur(gi),gi_get_yur(gi)
    nrow,ncol=gi["nrow"],gi["ncol"]
    dx,dy=gi["dx"],gi["dy"]
    dx0,dy0=dx/downscale_factor,dy/downscale_factor

    Dx=(xur-xll)/x_split
    Dy=(yur-yll)/y_split

    for xll0 in np.arange(xll,xur,Dx):

        xur0=min(xur,xll0+Dx)
        C=int(0.5+(xll0-xll)/gi["dx"])
        ncol0=int(0.5+(xur0-xll0)/dx0)
        ncol1=int(0.5+(xur0-xll0)/dx)

        for yll0 in np.arange(yll,yur,Dy):

            yur0=min(yur,yll0+Dy)
            R=int(0.5+nrow-(yur0-yll)/gi["dy"])
            nrow0=int(0.5+(yur0-yll0)/dy0)
            nrow1=int(0.5+(yur0-yll0)/dy)

            gi0=gi2dict([xll0,yll0,dx0,dy0,nrow0,ncol0,gi["proj"],gi["ang"],gi["crs"]])
            gi1=gi2dict([xll0,yll0,dx,dy,nrow1,ncol1,gi["proj"],gi["ang"],gi["crs"]])

            arr0=shp2arr(f_shape,gi0,field=field,nodata=nodata,set_gi_extent=set_gi_extent)
            dt,nodata=arr0.dtype(),arr0.nodata()

            msk=rasterArr(np.array(arr0.arr.mask == False,float32),gi0,nodata).rescale(gi1,"sum").cover(0)
            msk/=((dx/dx0)*(dy/dy0))
            msk=msk.arr.data >= frac

            arr0=arr0.rescale(gi1,method).arr.data

            try:
                arr[0,0]
            except:
                arr=np.ones((nrow,ncol),dt)*nodata

            arr[R:R+arr0.shape[0],C:C+arr0.shape[1]][msk]=arr0[msk]

    return rasterArr(arr,gi,nodata)

def shp2arr_PIL(f_shape,gi,field=None,precision=1,frac=0.5,st=None,set_gi_extent=True):
    """Function to rasterize an ESRI shapefile using PIL.

    Does not work to create non-equidistant rasters.

    Parameters
    ----------
    f_shape : str
        Shapefile.

        Recognized features are point, line and polygon shapefiles. Multi-part features are supported.

    gi : list or dict
        Dict or list with basic geographical information according to rasterArr object.

        See :ref:`geo_info`

        The geographical information is used to set the cell sizes, cell boundaries and (depending on *set_gi_extent*) the extent.

    field : str or None (optional)
        Name of the field to be rasterized.

        If *field* is None or does not exist in the shapefile the shapes are rasterized to the value 1.
        This is faster than rasterizing a specific field.

    precision : int (optional)
        Precision number (>= 0).

        If *precision* is >0 then the shape file is rasterized to the downscaled raster and thereafter upscaled again.
        The downscale factor is *precision*+1, e.g. if *precision* is 1 the downscaling factor is 2, meaning that the cell sizes are divided by 2.
        This could give a better (more precise) result. See also the parameter *frac*.

        The higher the precision number, the slower the calculation. Memory error could occur if the number is too large.

    frac : float (optional)
        Fraction (range 0-1). This fraction is used in the upscaling mentioned above (see parameter *precision*) to determine which resulting cell are covered by the shape and which not.

    st : str or None (optional)
        Shape type. Recognized are: 'point', 'line' and polygon'. These overrule the shape type of each shape, if possible.

        If *st* is None the shape type of the shapes is not changed.

    set_gi_extent : bool (optional)
        True = the extent is taken from *gi*.

            Note that first the shapefile is rasterized to the full extent of the shapefile and thereafter clipped to the extent of *gi*.

        False = the extent is taken from the shapefile itself. The cell sizes and cell boundaries are taken from *gi*.

    Returns
    -------
    result : rasterArr object
    """
    shp=shapefile.Reader(f_shape)
    bnds=shp.bbox
    shapes=shp.shapes()

    if field not in [rec[0] for rec in shp.fields]:
        field=None
    del shp
    if field != None:
        f_dbf="%s.dbf" %(f_shape[:-4])
        data=table2arr(f_dbf,l_flds=[field])[field]

    lut_st=[[1,3,3,5],["POINT","POLYLINE","LINE","POLYGON"]]
    if st != None:
        if st.upper() in lut_st[1]:
            l_st=lut_st[0][lut_st[1].index()]
        else:
            l_st=[5]*len(shapes)
    else:
        l_st=[shapes[i].shapeType for i in range(0,len(shapes))]

    ## gi:  for final raster
    ## gi0: for initial raster
    gi=gi2dict(gi)

    include_shps=np.ones((len(shapes),),bool)
    if set_gi_extent:
        l_x,l_y=[],[]
        for i in range(0,len(shapes)):
            pnts=np.array(shapes[i].points)
            if gi["proj"] == 1:
                if (pnts[:,0].min() > gi_get_xur(gi) or pnts[:,0].max() < gi["xll"]) or (pnts[:,1].min() > gi_get_yur(gi) or pnts[:,1].max() < gi["yll"]):
                    include_shps[i]=False
            else:
                if (pnts[:,0].min() > gi_get_xur(gi) or pnts[:,0].max() < gi["xll"]) or (pnts[:,1].max() > gi_get_yur(gi) or pnts[:,1].min() < gi["yll"]):
                    include_shps[i]=False
            if include_shps[i]:
                l_x+=[pnts[:,0].min(),pnts[:,0].max()]
                l_y+=[pnts[:,1].min(),pnts[:,1].max()]
        xmin,xmax=min(l_x),max(l_x)
        ymin,ymax=min(l_y),max(l_y)
    else:
        xmin,xmax=min(bnds[0],bnds[2]),max(bnds[0],bnds[2])
        ymin,ymax=min(bnds[1],bnds[3]),max(bnds[1],bnds[1])

    xmin,xmax=_rounddown(xmin,gi["dx"]),_roundup(xmax,gi["dx"])
    ymin,ymax=_rounddown(ymin,gi["dy"]),_roundup(ymax,gi["dy"])

    if 1 in l_st:
        xmin-=gi["dx"]
        xmax+=gi["dx"]
        ymin-=gi["dy"]
        ymax+=gi["dy"]
    if xmin == xmax:
        xmin-=gi["dx"]
    if ymin == ymax:
        ymax+=gi["dy"]

    if gi["proj"] == 1:
        gi0=gi_set_extent(gi,[xmin,ymin,xmax,ymax],True)
    else:
        gi0=gi_set_extent(gi,[xmin,ymax,xmax,ymin],True)

    if not set_gi_extent:
        gi=deepcopy(gi0)

    if (3 in l_st or 5 in l_st) and precision > 0:
        gi0=gi_set_dxdy(gi0,gi0["dx"]/(precision+1),gi0["dy"]/(precision+1))

    if field == None:

        arr=np.zeros((gi0["nrow"],gi0["ncol"]),float32)

        if 3 in l_st or 5 in l_st:

            img=Image.new("L",(gi0["ncol"],gi0["nrow"]),0)
            drw=ImageDraw.Draw(img)

            for i in np.compress(include_shps,np.arange(0,len(shapes)),0):

                if l_st[i] in [3,5]:

                    rc=np.take(np.swapaxes(xy2rc(np.swapaxes(shapes[i].points,0,1),gi0),0,1),[1,0],1)
                    try:
                        prts=shapes[i].parts.tolist()+[len(rc)]
                    except:
                        prts=[0,len(shapes[i].points)]
                    if l_st[i] == 3:
                        for j in range(0,len(prts)-1):
                            drw.line(np.ravel(rc[prts[j]:prts[j+1]]).tolist(),fill=1)
                    elif l_st[i] == 5:
                        for j in range(0,len(prts)-1):
                            drw.polygon(np.ravel(rc[prts[j]:prts[j+1]]).tolist(),fill=1)

            arr=np.array(np.reshape(np.array(img.getdata()),(gi0["nrow"],gi0["ncol"])),float32)

        if 1 in l_st:

            for i in np.compress(include_shps,np.arange(0,len(shapes)),0):

                if l_st[i] == 1:

                    rc=xy2rc(np.swapaxes(shapes[i].points,0,1),gi0)
                    arr[rc[0],rc[1]]=1

        arr=rasterArr(arr,gi0).rescale(gi,method="mean")
        arr=if_then_else(arr >= frac,1,0)
        arr.set_nodata(0)
        arr=arr.int()

    else:

        arr=np.zeros((gi["nrow"],gi["ncol"]),data.dtype)
        frac=np.ones(arr.shape,float32)*frac
        msk=np.ones(arr.shape,bool)

        if 3 in l_st or 5 in l_st:

            for i in np.compress(include_shps,np.arange(0,len(shapes)),0):

                if l_st[i] in [3,5]:

                    img=Image.new("L",(gi0["ncol"],gi0["nrow"]),0)
                    drw=ImageDraw.Draw(img)
                    rc=np.take(np.swapaxes(xy2rc(np.swapaxes(shapes[i].points,0,1),gi0),0,1),[1,0],1)
                    try:
                        prts=shapes[i].parts.tolist()+[len(rc)]
                    except:
                        prts=[0,len(shapes[i].points)]
                    if l_st[i] == 3:
                        for j in range(0,len(prts)-1):
                            drw.line(np.ravel(rc[prts[j]:prts[j+1]]).tolist(),fill=1)
                    elif l_st[i] == 5:
                        for j in range(0,len(prts)-1):
                            drw.polygon(np.ravel(rc[prts[j]:prts[j+1]]).tolist(),fill=1)

                    arr0=np.array(np.reshape(np.array(img.getdata()),(gi0["nrow"],gi0["ncol"])),float32)
                    arr0=rasterArr(arr0,gi0).rescale(gi,"mean").arr.data

                    #arr=np.where(arr0 >= frac,data[i],arr)
                    #msk=np.where(arr0 >= frac,False,msk)
                    #frac=np.maximum(arr0,frac)

                    arr[arr0 >= frac]=data[i]
                    msk[arr0 >= frac]=False
                    frac[arr0 >= frac]=arr0[arr0 >= frac]

        if 1 in l_st:

            for i in np.compress(include_shps,np.arange(0,len(shapes)),0):

                if l_st[i] == 1:

                    rc=xy2rc(np.swapaxes(shapes[i].points,0,1),gi0)
                    arr[rc[0],rc[1]]=np.where(arr[rc[0],rc[1]] == 0,i+1,arr[rc[0],rc[1]])

        arr=rasterArr(arr,gi)
        arr.set_mask(msk)

    return arr


############################
## COORDINATE CONVERSIONS ##
############################

def xy_reproject(xy,crs_in,crs_out):
    """Function to reproject x,y coordinates of shapes.

    Parameters
    ----------
    xy : list or numpy ndarray
        The x,y coordinates of the shapes to be reprojected.

        If the type of the shapes is 'POINT' this should be a Nx2 array: [(x1,y1), (x2,y2) ... (xN,yN)].

        If the type of the shapes is 'POLYLINE' or 'POLYGON' this should be a list of Nx2 arrays: [[(x1,y1),(x2,y2) .. (xN,yN)], [(x1,y1),(x2,y2) .. (xM,yM)] ...].

    crs_in : int or str
        Input crs reference.

        One of the following forms:

        Integer: EPSG reference number.

        String: 'EPSG:i' where i denotes a EPSG reference number.

        String: 'UTMiC' where i denotes a UTM zone number and C denotes 'N' or 'S' for the hemisphere.

        String: GDAL's so called WellKnownGeogCS string, e.g. 'WGS84'.

        String: Ohter recognized strings are: 'amersfoort', 'rd', 'gda94', 'gda94_vicgrid'

        String: WKT string

    crs_out : int or str
        Output crs reference.

        Same possible forms as *crs_in*.

    Returns
    -------
    xy_out : list or numpy ndarray
        The reprojected x,y coordinates of the shapes.

        If the type of the shapes is 'POINT' this is a Nx2 array: [(x1,y1), (x2,y2) ... (xN,yN)].

        If the type of the shapes is 'POLYLINE' or 'POLYGON' this is a list of Nx2 arrays: [[(x1,y1),(x2,y2) .. (xN,yN)], [(x1,y1),(x2,y2) .. (xM,yM)] ...].
    """
    sr_in=osgeo.osr.SpatialReference()
    sr_in.ImportFromWkt(crs2wkt(crs_in,crs_in))
    sr_out=osgeo.osr.SpatialReference()
    sr_out.ImportFromWkt(crs2wkt(crs_out,crs_out))
    ct=osgeo.osr.CoordinateTransformation(sr_in,sr_out)
    xy_out=deepcopy(xy)
    try:
        xy_out[0][0][0]
        for s in range(0,len(xy_out)):
            xy_out[s]=np.array(xy_out[s],float64)
            for i in range(0,len(xy_out[s])):
                xy_out[s][i]=np.array(ct.TransformPoint(xy_out[s][i,0],xy_out[s][i,1])[:2],float64)
    except:
        xy_out=np.array(xy_out,float64)
        try:
            xy_out[0][0]
            for i in range(0,len(xy_out)):
                xy_out[i]=np.array(ct.TransformPoint(xy_out[i,0],xy_out[i,1])[:2],float64)
        except:
            xy_out=np.array(ct.TransformPoint(xy_out[0],xy_out[1])[:2],float64)
    return xy_out

def xy_rotate(xy,rot_CwRad,xy_rot=[0,0],rot_inDeg=False):
    """Function to rotate x,y coordinates of shapes.

    Parameters
    ----------
    xy : list or numpy ndarray
        The x,y coordinates of the shapes to be reprojected.

        If the type of the shapes is 'POINT' this should be a Nx2 array: [(x1,y1), (x2,y2) ... (xN,yN)].

        If the type of the shapes is 'POLYLINE' or 'POLYGON' this should be a list of Nx2 arrays: [[(x1,y1),(x2,y2) .. (xN,yN)], [(x1,y1),(x2,y2) .. (xM,yM)] ...].

    rot_CwRad : float
        The rotation angle in clock-wise radians.

    xy_rot : list, tuple or numpy ndarray (optional)
        The x,y coordinates (1-D) of the point around which the rotation should be done.

    rot_inDeg : bool (optional)
        True = rotation angle *rot_CwRad* is given in degrees.

        False = rotation angle is not given in degrees.

    Returns
    -------
    xy_out : list or numpy ndarray
        The reprojected x,y coordinates of the shapes.

        If the type of the shapes is 'POINT' this is a Nx2 array: [(x1,y1), (x2,y2) ... (xN,yN)].

        If the type of the shapes is 'POLYLINE' or 'POLYGON' this is a list of Nx2 arrays: [[(x1,y1),(x2,y2) .. (xN,yN)], [(x1,y1),(x2,y2) .. (xM,yM)] ...].
    """
    def _xy_arr_rotate(xy_arr,rot_CwRad,xy_rot):
        xy_out=np.array(xy_arr,float64)
        xy_out[:,0]=((xy_arr[:,0]-xy_rot[0])*np.cos(rot_CwRad)-(xy_arr[:,1]-xy_rot[1])*np.sin(rot_CwRad))+xy_rot[0]
        xy_out[:,1]=((xy_arr[:,0]-xy_rot[0])*np.sin(rot_CwRad)+(xy_arr[:,1]-xy_rot[1])*np.cos(rot_CwRad))+xy_rot[1]
        return xy_out

    rot_CwRad=float(rot_CwRad)
    if rot_inDeg:
        rot_CwRad=(rot_CwRad/360)*(2*math.pi)
    rot_CwRad=(-rot_CwRad)%(2*math.pi)

    try:
        xy_rot=np.ravel(np.array(xy_rot,float64))[:2]
    except:
        xy_rot=np.array([0,0],float64)

    xy_out=deepcopy(xy)
    try:
        xy_out[0][0][0]
        for s in range(0,len(xy_out)):
            xy_out[s]=_xy_arr_rotate(np.array(xy_out[s],float64),rot_CwRad,xy_rot)
    except:
        xy_out=np.array(xy_out,float64)
        try:
            xy_out[0][0]
            xy_out=_xy_arr_rotate(np.array(xy_out,float64),rot_CwRad,xy_rot)
        except:
            xy_out=_xy_arr_rotate(np.array([xy_out],float64),rot_CwRad,xy_rot)[0]
    return xy_out

def xy_shift(xy,xy_shift=[0,0],backward=False):
    """Function to shift/translate x,y coordinates of shapes.

    Parameters
    ----------
    xy : list or numpy ndarray
        The x,y coordinates of the shapes to be reprojected.

        If the type of the shapes is 'POINT' this should be a Nx2 array: [(x1,y1), (x2,y2) ... (xN,yN)].

        If the type of the shapes is 'POLYLINE' or 'POLYGON' this should be a list of Nx2 arrays: [[(x1,y1),(x2,y2) .. (xN,yN)], [(x1,y1),(x2,y2) .. (xM,yM)] ...].

    xy_shift : list, tuple or numpy ndarray (optional)
        The shift in x and y direction (1-D).

    backward : bool (optional)
        True = the shift is done 'backward' (in oposite direction).

        False = the shift is done 'forward' (normal direction).

    Returns
    -------
    xy_out : list or numpy ndarray
        The shifted x,y coordinates of the shapes.

        If the type of the shapes is 'POINT' this is a Nx2 array: [(x1,y1), (x2,y2) ... (xN,yN)].

        If the type of the shapes is 'POLYLINE' or 'POLYGON' this is a list of Nx2 arrays: [[(x1,y1),(x2,y2) .. (xN,yN)], [(x1,y1),(x2,y2) .. (xM,yM)] ...].
    """
    def _xy_arr_shift(xy_arr,xy_shift):
        xy_out=np.array(xy_arr,float64)
        xy_out[:,0]+=xy_shift[0]
        xy_out[:,1]+=xy_shift[1]
        return xy_out

    xy_shift=np.ravel(np.array(xy_shift,float64))[:2]
    if backward:
        xy_shift=-xy_shift

    xy_out=deepcopy(xy)
    try:
        xy_out[0][0][0]
        for s in range(0,len(xy_out)):
            xy_out[s]=_xy_arr_shift(np.array(xy_out[s],float64),xy_shift)
    except:
        xy_out=np.array(xy_out,float64)
        try:
            xy_out[0][0]
            xy_out=_xy_arr_shift(np.array(xy_out,float64),xy_shift)
        except:
            xy_out=_xy_arr_shift(np.array([xy_out],float64),xy_shift)[0]
    return xy_out

def utm2latlong(utm_zone, easting, northing, northernHemisphere=True):
    """Function to convert UTM coordinates to LatLong coordinates.

    WGS84 ellipsoid is assumed.

    Parameters
    ----------
    utm_zone : int
        UTM zone.

    easting : int or float
        UTM easting (x coordinate) in [m].

    northing : int or float
        UTM northing (y coordinate) in [m].

    northernHemisphere : bool (optional)
        True = northern hemisphere

        False = southern hemisphere

    Returns
    -------
    latitude : float
        Latitude in [decimal degrees].

    longitude : float
        Longitude in [decimal degrees].

    See Also
    --------
    LL_UTM module to convert LatLong to UTM and/or to use other ellipsoids.

    """
    if not northernHemisphere:
        northing = 10000000 - northing

    a = 6378137
    e = 0.081819191
    e1sq = 0.006739497
    k0 = 0.9996

    arc = northing / k0
    mu = arc / (a * (1 - math.pow(e, 2) / 4.0 - 3 * math.pow(e, 4) / 64.0 - 5 * math.pow(e, 6) / 256.0))

    ei = (1 - math.pow((1 - e * e), (1 / 2.0))) / (1 + math.pow((1 - e * e), (1 / 2.0)))

    ca = 3 * ei / 2 - 27 * math.pow(ei, 3) / 32.0

    cb = 21 * math.pow(ei, 2) / 16 - 55 * math.pow(ei, 4) / 32
    cc = 151 * math.pow(ei, 3) / 96
    cd = 1097 * math.pow(ei, 4) / 512
    phi1 = mu + ca * math.sin(2 * mu) + cb * math.sin(4 * mu) + cc * math.sin(6 * mu) + cd * math.sin(8 * mu)

    n0 = a / math.pow((1 - math.pow((e * math.sin(phi1)), 2)), (1 / 2.0))

    r0 = a * (1 - e * e) / math.pow((1 - math.pow((e * math.sin(phi1)), 2)), (3 / 2.0))
    fact1 = n0 * math.tan(phi1) / r0

    _a1 = 500000 - easting
    dd0 = _a1 / (n0 * k0)
    fact2 = dd0 * dd0 / 2

    t0 = math.pow(math.tan(phi1), 2)
    Q0 = e1sq * math.pow(math.cos(phi1), 2)
    fact3 = (5 + 3 * t0 + 10 * Q0 - 4 * Q0 * Q0 - 9 * e1sq) * math.pow(dd0, 4) / 24

    fact4 = (61 + 90 * t0 + 298 * Q0 + 45 * t0 * t0 - 252 * e1sq - 3 * Q0 * Q0) * math.pow(dd0, 6) / 720

    lof1 = _a1 / (n0 * k0)
    lof2 = (1 + 2 * t0 + Q0) * math.pow(dd0, 3) / 6.0
    lof3 = (5 - 2 * Q0 + 28 * t0 - 3 * math.pow(Q0, 2) + 8 * e1sq + 24 * math.pow(t0, 2)) * math.pow(dd0, 5) / 120
    _a2 = (lof1 - lof2 + lof3) / math.cos(phi1)
    _a3 = _a2 * 180 / math.pi

    latitude = 180 * (phi1 - fact1 * (fact2 + fact3 + fact4)) / math.pi

    if not northernHemisphere:
        latitude = -latitude

    longitude = ((utm_zone > 0) and (6 * utm_zone - 183.0) or 3.0) - _a3

    return latitude, longitude

def latlong2utm(latitude,longitude,utm_zone=None,utm_letter=None,return_zone=False):
    """Function to convert LatLong coordinates to UTM coordinates.

    WGS84 ellipsoid is assumed.

    Parameters
    ----------
    latitude : float
        Latitude in [decimal degrees].

    longitude : float
        Longitude in [decimal degrees].

    utm_zone : int (optional)
        UTM zone.

    utm_letter : str (optional)
        UTM letter designator.

    return_zone : bool (optional)
        True = return UTM zone (incl. UTM letter)

        False = do not return UTM zone

    Returns
    -------
    easting : int or float
        UTM easting (x coordinate) in [m].

    northing : int or float
        UTM northing (y coordinate) in [m].

    UTM zone : str (optional)
        UTM zone (incl. UTM letter)

        Only return if *return_zone* is True.
    """
    _deg2rad = math.pi / 180.0
    _rad2deg = 180.0 / math.pi

    _equatorialRadius = 2
    _eccentricitySquared = 3
    _ellipsoid = [
        [ -1, "Placeholder", 0, 0],
        [ 1, "Airy", 6377563, 0.00667054],
        [ 2, "Australian National", 6378160, 0.006694542],
        [ 3, "Bessel 1841", 6377397, 0.006674372],
        [ 4, "Bessel 1841 (Nambia] ", 6377484, 0.006674372],
        [ 5, "Clarke 1866", 6378206, 0.006768658],
        [ 6, "Clarke 1880", 6378249, 0.006803511],
        [ 7, "Everest", 6377276, 0.006637847],
        [ 8, "Fischer 1960 (Mercury] ", 6378166, 0.006693422],
        [ 9, "Fischer 1968", 6378150, 0.006693422],
        [ 10, "GRS 1967", 6378160, 0.006694605],
        [ 11, "GRS 1980", 6378137, 0.00669438],
        [ 12, "Helmert 1906", 6378200, 0.006693422],
        [ 13, "Hough", 6378270, 0.00672267],
        [ 14, "International", 6378388, 0.00672267],
        [ 15, "Krassovsky", 6378245, 0.006693422],
        [ 16, "Modified Airy", 6377340, 0.00667054],
        [ 17, "Modified Everest", 6377304, 0.006637847],
        [ 18, "Modified Fischer 1960", 6378155, 0.006693422],
        [ 19, "South American 1969", 6378160, 0.006694542],
        [ 20, "WGS 60", 6378165, 0.006693422],
        [ 21, "WGS 66", 6378145, 0.006694542],
        [ 22, "WGS-72", 6378135, 0.006694318],
        [ 23, "WGS-84", 6378137, 0.00669438]
    ]

    ## Assume WGS-84
    ReferenceEllipsoid=23

    a = _ellipsoid[ReferenceEllipsoid][_equatorialRadius]
    eccSquared = _ellipsoid[ReferenceEllipsoid][_eccentricitySquared]
    k0 = 0.9996

    LongTemp = (longitude+180)-int((longitude+180)/360)*360-180 # -180.00 .. 179.9

    LatRad = latitude*_deg2rad
    LongRad = LongTemp*_deg2rad

    if utm_zone == None:

        utm_zone = int((LongTemp + 180)/6) + 1

        if latitude >= 56.0 and latitude < 64.0 and LongTemp >= 3.0 and LongTemp < 12.0:
            utm_zone = 32

        # Special zones for Svalbard
        if latitude >= 72.0 and latitude < 84.0:
            if  LongTemp >= 0.0  and LongTemp <  9.0: utm_zone = 31
            elif LongTemp >= 9.0  and LongTemp < 21.0: utm_zone = 33
            elif LongTemp >= 21.0 and LongTemp < 33.0: utm_zone = 35
            elif LongTemp >= 33.0 and LongTemp < 42.0: utm_zone = 37

    if utm_letter == None:

        if 84 >= latitude >= 72: utm_letter='X'
        elif 72 > latitude >= 64: utm_letter='W'
        elif 64 > latitude >= 56: utm_letter='V'
        elif 56 > latitude >= 48: utm_letter='U'
        elif 48 > latitude >= 40: utm_letter='T'
        elif 40 > latitude >= 32: utm_letter='S'
        elif 32 > latitude >= 24: utm_letter='R'
        elif 24 > latitude >= 16: utm_letter='Q'
        elif 16 > latitude >= 8: utm_letter='P'
        elif  8 > latitude >= 0: utm_letter='N'
        elif  0 > latitude >= -8: utm_letter='M'
        elif -8> latitude >= -16: utm_letter='L'
        elif -16 > latitude >= -24: utm_letter='K'
        elif -24 > latitude >= -32: utm_letter='J'
        elif -32 > latitude >= -40: utm_letter='H'
        elif -40 > latitude >= -48: utm_letter='G'
        elif -48 > latitude >= -56: utm_letter='F'
        elif -56 > latitude >= -64: utm_letter='E'
        elif -64 > latitude >= -72: utm_letter='D'
        elif -72 > latitude >= -80: utm_letter='C'
        else: utm_letter='Z'    # if the Latitude is outside the UTM limits

    LongOrigin = (utm_zone - 1)*6 - 180 + 3 #+3 puts origin in middle of zone
    LongOriginRad = LongOrigin * _deg2rad

    eccPrimeSquared = (eccSquared)/(1-eccSquared)
    N = a/math.sqrt(1-eccSquared*math.sin(LatRad)*math.sin(LatRad))
    T = math.tan(LatRad)*math.tan(LatRad)
    C = eccPrimeSquared*math.cos(LatRad)*math.cos(LatRad)
    A = math.cos(LatRad)*(LongRad-LongOriginRad)

    M = a*((1
            - eccSquared/4
            - 3*eccSquared*eccSquared/64
            - 5*eccSquared*eccSquared*eccSquared/256)*LatRad
           - (3*eccSquared/8
              + 3*eccSquared*eccSquared/32
              + 45*eccSquared*eccSquared*eccSquared/1024)*math.sin(2*LatRad)
           + (15*eccSquared*eccSquared/256 + 45*eccSquared*eccSquared*eccSquared/1024)*math.sin(4*LatRad)
           - (35*eccSquared*eccSquared*eccSquared/3072)*math.sin(6*LatRad))

    easting = (k0*N*(A+(1-T+C)*A*A*A/6
                        + (5-18*T+T*T+72*C-58*eccPrimeSquared)*A*A*A*A*A/120)
                  + 500000.0)

    northing = (k0*(M+N*math.tan(LatRad)*(A*A/2+(5-T+9*C+4*C*C)*A*A*A*A/24
                                        + (61
                                           -58*T
                                           +T*T
                                           +600*C
                                           -330*eccPrimeSquared)*A*A*A*A*A*A/720)))

    if latitude < 0:
        northing = northing + 10000000.0 #10000000 meter offset for southern hemisphere

    if return_zone:
        return easting,northing,"%d%s" %(utm_zone,utm_letter)
    else:
        return easting,northing

def rd2latlong(x_rd,y_rd,z_nap=None):
    """Function to convert RD coordinates to LatLong coordinates.

    WGS84 ellipsoid is assumed.


    Parameters
    ----------
    x_rd : int or float
        RD x coordinate in [m].

    y_rd : int or float
        RD y coordinate in [m].

    z_nap : int or float (optional)
        Elevation (z coordinate) in [m +NAP].

        If *z_nap* is None the elevation is set to 0.0 m +NAP.

    Returns
    -------
    latitude : float
        Latitude in [decimal degrees].

    longitude : float
        Longitude in [decimal degrees].

    h_wgs : float or None
        Elevation in [m] relative to WGS84 ellipsoid.

        If *z_nap* is None then *h* will be None too.
    """
    x,y=float(x_rd),float(y_rd)
    if z_nap == None: z=0.0
    else: z=float(z_nap)
    phi,lam,h=_rd_xyz2latlongh(x,y,z)
    x,y,z=_latlongh2xyz(phi,lam,h,0)
    x,y,z=_xyz_rd2etrs(x,y,z)
    phi,lam,h=_xyz2latlongh(x,y,z,1)
    if z_nap == None: h=None
    return phi,lam,h

def latlong2rd(latitude,longitude,h_wgs=None):
    """Function to convert LatLong coordinates to RD coordinates.

    WGS84 ellipsoid is assumed.

    Parameters
    ----------
    latitude : float
        Latitude in [decimal degrees].

    longitude : float
        Longitude in [decimal degrees].

    h_wgs : float or None (optional)
        Elevation in [m] relative to WGS84 ellipsoid.

    Returns
    -------
    x_rd : float
        RD x coordinate in [m].

    y_rd : float
        RD y coordinate in [m].

    z_nap : float or None
        Elevation (z coordinate) in [m +NAP].

        If *h_wgs* is None then *z_nap* will be None too.
    """
    phi,lam=float(latitude),float(longitude)
    if h_wgs == None: h=0.0
    else: h=float(h_wgs)
    x,y,z=_latlongh2xyz(phi,lam,h,1)
    x,y,z=_xyz_etrs2rd(x,y,z)
    phi,lam,h=_xyz2latlongh(x,y,z,0)
    x,y,z=_rd_latlongh2xyz(phi,lam,h)
    if h_wgs == None: z=None
    return x,y,z

def _rd_xyz2latlongh(x,y,z):
    x,y,z=float(x),float(y),float(z)
    ## constants
    e=0.081696831222
    lam0,B0,L0=5.387638889,52.121097249,5.387638889
    n,m,R=1.00047585668,0.003773953832,6382644.571
    k,x0,y0=0.9999079,155000.0,463000.0
    ## calculations
    r=math.sqrt((x-x0)**2+(y-y0)**2)
    sina,cosa=(x-x0)/r,(y-y0)/r
    psi=2*math.degrees(math.atan(r/(2*k*R)))
    sinB0,cosB0=math.sin(math.radians(B0)),math.cos(math.radians(B0))
    sinpsi,cospsi=math.sin(math.radians(psi)),math.cos(math.radians(psi))
    sinB=cosa*cosB0*sinpsi+sinB0*cospsi; B,cosB=math.degrees(math.asin(sinB)),math.cos(math.asin(sinB))
    sindL=(sina*sinpsi)/cosB; dL=math.degrees(math.asin(sindL))
    w=math.log(math.tan(math.radians(0.5*B+45)))
    q=(w-m)/n
    phi1=2*math.degrees(math.atan(math.exp(q)))-90
    for i in range(0,4):
        dq=0.5*e*math.log((1+e*math.sin(math.radians(phi1)))/(1-e*math.sin(math.radians(phi1))))
        phi1=2*math.degrees(math.atan(math.exp(q+dq)))-90
    return phi1,dL/n+lam0,z
def _rd_latlongh2xyz(latitude,longitude,h):
    phi,lam,h=float(latitude),float(longitude),float(h)
    ## constants
    e=0.081696831222
    lam0,B0,L0=5.387638889,52.121097249,5.387638889
    n,m,R=1.00047585668,0.003773953832,6382644.571
    k,x0,y0=0.9999079,155000.0,463000.0
    ## calculations
    q=math.log(math.tan(math.radians(0.5*phi+45)))-0.5*e*math.log((1+e*math.sin(math.radians(phi)))/(1-e*math.sin(math.radians(phi))))
    B=2*math.degrees(math.atan(exp(n*q+m)))-90
    dL=n*(lam-lam0)
    sinB,cosB=math.sin(math.radians(B)),math.cos(math.radians(B))
    sinB0,cosB0=math.sin(math.radians(B0)),math.cos(math.radians(B0))
    sindL=math.sin(math.radians(dL))
    sin2_05psi=math.sin(math.radians(0.5*(B-B0)))**2+math.sin(math.radians(0.5*dL))**2*math.cos(math.radians(B))*math.cos(math.radians(B0))
    sin_05psi,cos_05psi=math.sqrt(sin2_05psi),math.sqrt(1-sin2_05psi)
    tan_05psi=sin_05psi/cos_05psi
    sinpsi,cospsi=2*sin_05psi*cos_05psi,1-2*sin2_05psi
    sina=sindL*(cosB/sinpsi)
    cosa=(sinB-sinB0*cospsi)/(cosB0*sinpsi)
    r=2*k*R*tan_05psi
    return r*sina+x0,r*cosa+y0,h

def _xyz2latlongh(x,y,z,bessel_wgs84=0):
    x,y,z=float(x),float(y),float(z)
    ## constants
    if bessel_wgs84 == 0: a,e=6377397.155,0.081696831222
    else: a,e=6378137,0.081819190903
    phi0=52.156160556
    ## calculations
    N=a/math.sqrt(1-e**2*math.sin(math.radians(phi0))**2)
    r=math.sqrt(x**2+y**2)
    phi=math.degrees(math.asin(z/N))
    for i in range(0,4):
        phi=math.degrees(math.atan((1/r)*(z+e**2*N*math.sin(math.radians(phi)))))
    lam=math.degrees(math.atan(y/x))
    h=r*math.cos(math.radians(phi))+z*math.sin(math.radians(phi))-a*math.sqrt(1-e**2*math.sin(math.radians(phi))**2)
    return phi,lam,h
def _latlongh2xyz(latitude,longitude,h,bessel_wgs84=0):
    phi,lam,h=float(latitude),float(longitude),float(h)
    ## constants
    if bessel_wgs84 == 0: a,e=6377397.155,0.081696831222
    else: a,e=6378137,0.081819190903
    ## calculations
    N=a/math.sqrt(1-e**2*math.sin(math.radians(phi))**2)
    x=(N+h)*math.cos(math.radians(phi))*math.cos(math.radians(lam))
    y=(N+h)*math.cos(math.radians(phi))*math.sin(math.radians(lam))
    z=(N-e**2*N+h)*math.sin(math.radians(phi))
    return x,y,z

def _xyz_rd2etrs(x,y,z):
    X=np.array([[float(x)],[float(y)],[float(z)]],float64)
    T0=np.array([[-593.029],[-26.004],[-478.753]],float64)
    R=np.array([[-4.0812e-6,-9.0677e-6,-1.7004e-6],[9.0677e-6,-4.0812e-6,-1.9725e-6],[1.7004e-6,1.9725e-6,-4.0812e-6]],float64)
    X0=np.array([[3903453.148],[368135.313],[5012970.306]],float64)
    return ravel(X-T0-np.dot(R,X-X0)).tolist()
def _xyz_etrs2rd(x,y,z):
    X=np.array([[float(x)],[float(y)],[float(z)]],float64)
    T0=np.array([[-593.029],[-26.004],[-478.753]],float64)
    R=np.array([[-4.0812e-6,-9.0677e-6,-1.7004e-6],[9.0677e-6,-4.0812e-6,-1.9725e-6],[1.7004e-6,1.9725e-6,-4.0812e-6]],float64)
    X0=np.array([[3904046.180],[368161.313],[5013449.047]],float64)
    return ravel(X+T0+np.dot(R,X-X0)).tolist()


##################################
## POINT/LINE/POLYGON FUNCTIONS ##
##################################

def poly2slopes_intersects(xy_poly,nodata=1.23456789e31):
    """Function to calculate the slopes and y-axis intersects of all line elements of a set of polylines or polygons.

    Parameters
    ----------
    xy_poly : list
        The x,y coordinates of the set of polylines/polygons.

        This should be a list of Nx2 arrays: [[(x1,y1),(x2,y2) .. (xN,yN)], [(x1,y1),(x2,y2) .. (xM,yM)] ...].

        The length of the list is the number of polylines/polygons; N is the number of vertices of the polyline/polygon.

    nodata : int or float (optional)
        Nodata value to be returned for an infinite slope or intersect.

    Returns
    -------
    slopes : list
        The slopes of all line elements of the set of polylines/polygons.

        This is a list of arrays with N values. The length of the list is the number of polylines/polygons; N is the number of line element of the polyline/polygon.

    intersects : list
        The y-axis intersects of all line elements of the set of polylines/polygons.

        This is a list of arrays with N values. The length of the list is the number of polylines/polygons; N is the number of line element of the polyline/polygon.
    """
    l_slope,l_intersect=[],[]
    for i in range(0,len(xy_poly)):
        vertices=np.array(xy_poly[i].copy(),float64)
        x1,x2,y1,y2=vertices[:-1,0].copy(),vertices[1:,0].copy(),vertices[:-1,1].copy(),vertices[1:,1].copy()
        slope=np.where(x1 == x2,-1,x1.copy()-x2.copy())
        slope=np.where(x1 == x2,nodata,(y1.copy()-y2.copy())/slope)
        intersect=np.where(slope == nodata,nodata,y1.copy()-slope.copy()*x1.copy())
        l_slope+=[slope]
        l_intersect+=[intersect]
    return l_slope,l_intersect

def intersect_poly(poly1,poly2):
    """Function to get the intersection points of a set of polylines or polygons with another set of polylines or polygons.

    Parameters
    ----------
    poly1 : list
        The x,y coordinates of the first set of polylines/polygons.

        This should be a list of Nx2 arrays: [[(x1,y1),(x2,y2) .. (xN,yN)], [(x1,y1),(x2,y2) .. (xM,yM)] ...].

        The length of the list is the number of polylines/polygons; N is the number of vertices of the polyline/polygon.

    poly2 : list
        The x,y coordinates of the second set of polylines/polygons.

        This should be a list of Nx2 arrays: [[(x1,y1),(x2,y2) .. (xN,yN)], [(x1,y1),(x2,y2) .. (xM,yM)] ...].

        The length of the list is the number of polylines/polygons; N is the number of vertices of the polyline/polygon.

    Returns
    -------
    xy_intersect : list
        The x,y coordinates of the intersection points.

        This is a NxMxLx2 shaped list. N is the number of polylines/polygons in the first set; M is the number of polylines/polygons in the second set.
        L is the number of intersection points.
    """
    nodata=1.23456789e31

    poly1=[np.array(pol,float64) for pol in poly1]
    poly2=[np.array(pol,float64) for pol in poly2]

    l_slope1,l_intersect1=poly2slopes_intersects(poly1,nodata)
    l_slope2,l_intersect2=poly2slopes_intersects(poly2,nodata)

    l_point=[]
    for p1 in range(0,len(poly1)):
        l_point+=[[]]
        for p2 in range(0,len(poly2)):
            l_point[-1]+=[[]]
            for p in range(0,len(poly1[p1])-1):
                if l_slope1[p1][p] == nodata:
                    xint=np.where(l_slope2[p2] == nodata,np.where(poly2[p2][:-1,0] == poly1[p1][p,0],poly1[p1][p,0],nodata),poly1[p1][p,0])
                    yint=np.where(l_slope2[p2] == nodata,nodata,l_slope2[p2].copy()*poly1[p1][p,0]+l_intersect2[p2].copy())
                elif l_slope1[p1][p] == 0:
                    a2=np.where(l_slope2[p2] == 0,1,l_slope2[p2].copy())
                    xint=np.where(l_slope2[p2] == 0,nodata,np.where(l_slope2[p2] == nodata,poly2[p2][:-1,0],(poly1[p1][p,1]-l_intersect2[p2].copy())/a2.copy()))
                    yint=np.where(l_slope2[p2] == 0,np.where(poly2[p2][:-1,1] == poly1[p1][p,1],poly1[p1][p,1],nodata),poly1[p1][p,1])
                else:
                    adif=l_slope1[p1][p]-l_slope2[p2].copy()
                    adif=np.where(adif == 0,1,adif)
                    xint=np.where(l_slope2[p2] == nodata,poly2[p2][:-1,0].copy(),np.where(l_slope2[p2] == l_slope1[p1][p],nodata,(l_intersect2[p2].copy()-l_intersect1[p1][p])/adif.copy()))
                    yint=np.where(xint == nodata,nodata,xint.copy()*l_slope1[p1][p]+l_intersect1[p1][p])

                cp=(xint != nodata)*(yint != nodata)
                cp*=(np.array([np.abs(poly2[p2][:-1,0].copy()-xint.copy()),np.abs(poly2[p2][1:,0].copy()-xint.copy())]).sum(0) == np.abs(poly2[p2][:-1,0].copy()-poly2[p2][1:,0].copy()))
                cp*=(np.array([np.abs(poly2[p2][:-1,1].copy()-yint.copy()),np.abs(poly2[p2][1:,1].copy()-yint.copy())]).sum(0) == np.abs(poly2[p2][:-1,1].copy()-poly2[p2][1:,1].copy()))
                cp*=(np.array([np.abs(poly1[p1][p,0].copy()-xint.copy()),np.abs(poly1[p1][p+1,0].copy()-xint.copy())]).sum(0) == np.abs(poly1[p1][p,0].copy()-poly1[p1][p+1,0].copy()))
                cp*=(np.array([np.abs(poly1[p1][p,1].copy()-yint.copy()),np.abs(poly1[p1][p+1,1].copy()-yint.copy())]).sum(0) == np.abs(poly1[p1][p,1].copy()-poly1[p1][p+1,1].copy()))

                for i in range(0,len(cp)):
                    if cp[i]:
                        for j in range(0,len(l_point[-1][-1])):
                            if xint[i] == l_point[-1][-1][j][0] and yint[i] == l_point[-1][-1][j][1]:
                                cp[i]=False
                                break
                        if cp[i]:
                            l_point[-1][-1]+=[[xint[i],yint[i]]]

    return l_point

def point_in_polygon(xy_point,xy_poly):
    """Function to perform a point-in-polygon test for a set of points and a set of polygons.

    Parameters
    ----------
    xy_point : array or array_like
        The x,y coordinates of the points.

        This should be a Nx2 array: [(x1,y1), (x2,y2) ... (xN,yN)].

        N is the number of points.

    xy_poly : list
        The x,y coordinates of the set of polygons.

        This should be a list of Nx2 arrays: [[(x1,y1),(x2,y2) .. (xN,yN)], [(x1,y1),(x2,y2) .. (xM,yM)] ...].

        The length of the list is the number of polygons; N is the number of vertices of the polygon.

    Returns
    -------
    pip : numpy ndarray
        This is a NxM array of type 'bool'. N is the number of points; M is the number of polygons.

        True = point in polygon.

        False = point not in polygon.
    """
    nodata=1.23456789e31

    xy_point=np.array(xy_point,float64)
    xy_poly=[np.array(pol,float64) for pol in xy_poly]
    for i in range(0,len(xy_poly)):
        xy_poly[i]=np.insert(xy_poly[i],len(xy_poly[i]),xy_poly[i][-1],0)
    xmax=max([pol[:,0].max() for pol in xy_poly])+1

    xy_line=[np.array([xy_point[i],[xmax,xy_point[i][1]]],float64) for i in range(0,len(xy_point))]

    pip=np.zeros((len(xy_point),len(xy_poly)),bool)

    # list, Npoint x Npoly x Nint x 2
    xy_int=intersect_poly(xy_line,xy_poly)

    # list, Npoint x Npoly x Nint
    pdist=[[np.array([np.abs(xy_point[i,0]-xy_int[i][j][k][0]) for k in range(0,len(xy_int[i][j]))]) for j in range(0,len(xy_int[i]))] for i in range(0,len(xy_int))]

    for i in range(0,len(pdist)):
        for j in range(0,len(pdist[i])):
            try:
                if pdist[i][j].min() <= 1e-7:
                    pip[i,j]=True
            except:
                pass
            if len(xy_int[i][j])%2 != 0:
                pip[i,j]=True

    return pip

def polyline2interval_points(xy_poly,interval,all_vert=True,end_vert=True,startend_shift=0.0):
    """Function to get points at a regular interval along the polylines in a set of polylines.

    Parameters
    ----------
    xy_poly : list
        The x,y coordinates of the set of polylines.

        This should be a list of Nx2 arrays: [[(x1,y1),(x2,y2) .. (xN,yN)], [(x1,y1),(x2,y2) .. (xM,yM)] ...].

        The length of the list is the number of polylines; N is the number of vertices of the polyline.

    interval : float
        Interval distance.

    all_vert : bool (optional)
        True = the vertices are included as points, even if they are not at the specified interval distance.

        False = the vertices are not included, unless they are at the specified interval distance.

    end_vert : bool (optional)
        True = the end vertex is included as point, even if it is not at the specified interval distance.

        False = the end vertex is not included, unless it is at the specified interval distance or *all_vert* is True.

    startend_shift : float (optional)
        If not 0.0 the first point is shifted forward over a distance of *startend_shift* and the last point is shifted backward over a distance of *startend_shift*.

    Returns
    -------
    output : list of numpy recarrays
        Each recarray belongs to a polyline in the set of polylines. It is a table with the fields 'X', 'Y' and 'DIST' being the x coordinates, y coordinates and distances of the points.
    """
    output=[]

    for i_line in range(0,len(xy_poly)):

        l_dist=[0.0]
        for i_vert in range(1,len(xy_poly[i_line])):
            l_dist+=[l_dist[-1]+((xy_poly[i_line][i_vert][0]-xy_poly[i_line][i_vert-1][0])**2+(xy_poly[i_line][i_vert][1]-xy_poly[i_line][i_vert-1][1])**2)**0.5]

        dist=np.arange(0,l_dist[-1],interval)
        dist[0]+=startend_shift
        if all_vert or end_vert:
            if all_vert:
                dist=np.insert(dist,len(dist),l_dist,0)
            elif end_vert:
                dist=np.insert(dist,len(dist),l_dist[-1:],0)
            dist=np.unique(dist)
            dist[-1]-=startend_shift
        elif dist[-1] == l_dist[-1]:
            dist[-1]-=startend_shift
        dist=dist[dist <= dist[-1]]

        arr=np.zeros((len(dist),),dtype=[("X",float64),("Y",float64),("DIST",float64)])

        arr["X"]=np.interp(dist,l_dist,xy_poly[i_line][:,0])
        arr["Y"]=np.interp(dist,l_dist,xy_poly[i_line][:,1])
        arr["DIST"]=dist

        output+=[arr]

    return output

def polyline_idf2val(xy_poly,fl_idf,interval,nodata=None,interpolate=True,all_vert=True):
    """Function to get values of a list of IDF files at a regular interval along the polylines in a set of polylines.

    Parameters
    ----------
    xy_poly : list
        The x,y coordinates of the set of polylines.

        This should be a list of Nx2 arrays: [[(x1,y1),(x2,y2) .. (xN,yN)], [(x1,y1),(x2,y2) .. (xM,yM)] ...].

        The length of the list is the number of polylines; N is the number of vertices of the polyline.

    fl_idf : list
        List of IDF files or rasterArr objects.

    interval : float
        Interval distance.

    interpolate : bool (optional)
        Flag for linear interpolation from cell centers to x,y location.

        True = enable linear interpolation

        False = disable linear interpolation

    all_vert : bool (optional)
        True = the vertices are included as points, even if they are not at the specified interval distance.

        False = the vertices are not included, unless they are at the specified interval distance.

    Returns
    -------
    output : list of numpy recarrays
        Each recarray belongs to a polyline in the set of polylines.
        It is a table; the first 3 fields are 'X', 'Y', 'DIST' being the x coordinates, y coordinates and distances of the points.
        The subsequent fields contain the values of the IDF files. The name of these fields is the basename of the IDF files.
    """
    l_cross=polyline2interval_points(xy_poly,interval,all_vert=all_vert)

    l_fld=[]
    for f in fl_idf:
        if str(type(f)) == "<class 'raster_func.rasterArr'>":
            l_fld+=["raster%d" %(len(l_fld))]
        else:
            l_fld+=[os.path.splitext(os.path.basename(f))[0]]

    for i in range(0,len(l_cross)):
        l_cross[i]=add_to_recarr(l_cross[i],[(fld,float32) for fld in l_fld])

    l_fld=l_cross[0].dtype.names[-len(l_fld):]

    for i in range(0,len(fl_idf)):
        f=fl_idf[i]
        fld=l_fld[i]
        for j in range(0,len(l_cross)):
            if str(type(f)) == "<class 'raster_func.rasterArr'>":
                l_cross[j][fld]=xy_arr2val([l_cross[j]["X"],l_cross[j]["Y"]],f,interpolate=interpolate)
                if nodata != None:
                    l_cross[j][fld]=ma.filled(l_cross[j][fld],nodata)
            else:
                l_cross[j][fld]=xy_idf2val([l_cross[j]["X"],l_cross[j]["Y"]],f,nodata=nodata,interpolate=interpolate)

    return l_cross

def points_polygons2val(xy,f,l_flds=None,nodata=None):
    """Function to extract polygon values of an ESRI shape file using x,y coordinates.

    Parameters
    ----------
    xy : array or array_like (2-D)
        The x,y coordinates of the points: Nx2 array: [(x1,y1), (x2,y2) ... (xN,yN)].

    f : str
        Input polygon shape file.

    l_flds : list or None (optional)
        List of field names to read. If *l_flds* is None all fields are read.

    nodata : float, int or None (optional)
        Nodata value to be applied.

    Returns
    -------
    result : numpy recarray
    """

    #Load the shapefile of polygons and convert it to shapely polygon objects
    shp=shapefile.Reader(f)
    polygon_shapes=shp.shapes()
    polygons=[Polygon(p.points) for p in polygon_shapes]

    #Convert point coordinates to shapely point objects
    points=[Point(xy[i]) for i in range(0,len(xy))]

    #Build a spatial index based on the bounding boxes of the polygons
    idx=index.Index()
    i=0
    for p in polygon_shapes:
        idx.insert(i,p.bbox)
        i+=1

    #Read polygon data array and initialize point data array
    data_polygons=table2arr("%s.dbf" %(f[:-4]),l_flds=l_flds,fld_str=None)
    data_points=np.zeros((len(xy),),dtype=data_polygons.dtype)
    data_points[:]=nodata

    #Iterate through each point
    for i in range(len(points)):

        #Iterate only through the bounding boxes which contain the point
        for j in idx.intersection((xy[i,0],xy[i,1])):

            #Verify that point is within the polygon and assign the polygon data to the point
            ###if points[i].within(polygons[j]):
            ###if polygons[j].contains(points[i]):
            ###if points[i].distance(polygons[j]) == 0:
            if points[i].intersects(polygons[j]):
                data_points[i]=data_polygons[j]
                break

    return data_points

##def dist_point2poly(p,poly):
##    """Function to get the distances from a point to a polyline or polygon.
##    """
##    nodata=1.23456789e31
##
##    from statistic_func import regression
##    poly=np.array(poly,float64)
##    xpoly=poly[:,0].copy(); xpoly=np.array([xpoly,np.concatenate([xpoly[1:],xpoly[:1]])])
##    ypoly=poly[:,1].copy(); ypoly=np.array([ypoly,np.concatenate([ypoly[1:],ypoly[:1]])])
##    apoly,bpoly=regression(xpoly,ypoly,nodata)
##
##    xp1,yp1=float(p[0]),float(p[1])
##    a1=-1.0/np.where(apoly == 0,1,apoly.copy()); b1=yp1-a1.copy()*xp1
##    xp2=np.where(apoly == 0,xp1,xp1+10)
##    yp2=np.where(apoly == 0,yp1+10,np.where(apoly == nodata,yp1,a1.copy()*xp2.copy()+b1.copy()))
##
##    dist1=((xpoly[0].copy()-xp1)**2+(ypoly[0].copy()-yp1)**2)**0.5
##    dist2=((xpoly[1].copy()-xp1)**2+(ypoly[1].copy()-yp1)**2)**0.5
##    dist3=np.ones((len(dist1)),float64)*nodata
##    for i in range(0,len(dist3)):
##        line=[[xp1,yp1],[xp2[i],yp2[i]]]
##        print line
##        xyint=intersect_poly(line,np.swapaxes(np.concatenate([[xpoly[:,i]],[ypoly[:,i]]]),1,0),nodata)
##        xint,yint=xyint[0,0],xyint[0,1]
##        if xint >= xpoly[:,i].min(0) and xint <= xpoly[:,i].max(0) and yint >= ypoly[:,i].min(0) and yint <= ypoly[:,i].max(0):
##            dist3[i]=((xint-xp1)**2+(yint-yp1)**2)**0.5
##    dist=np.ones((len(dist1),4),float64)*nodata
##    dist[:,0]=np.where(dist3 != nodata,dist3.copy(),np.minimum(dist1,dist2))
##    dist[:,1]=dist1.copy(); dist[:,2]=dist2.copy(); dist[:,3]=dist3.copy()
##    return dist


## MISCELLANEOUS FUNCTIONS

def _rounddown(v,rv=1,prec=1e-7):
    """Function rounddown.
    """
    v,rv=np.array(v),np.array(rv)
    v+=prec*rv
    return v-np.mod(v,rv)

def _roundup(v,rv=1,prec=1e-7):
    """Function to roundup.
    """
    v,rv=np.array(v),np.array(rv)
    v-=prec*rv
    return v+rv-np.mod(v,rv)

def _roundoff(v,rv=1,prec=1e-14):
    """Function to roundoff.
    """
    v1,v2=_rounddown(v,rv,prec)-v,_roundup(v,rv,prec)-v
    return np.where(np.abs(v1) < np.abs(v2),v+v1,v+v2)

def _get_prefered_nodata(arr):
    """Function to get a prefered nodata value for an array or rasterArr object.
    """
    try:
        arr.gi()
        arr1=np.compress(np.ravel(arr.arr.mask) == False,np.ravel(arr.arr.data),0)
        nodata=arr.nodata()
    except:
        try:
            arr1=np.compress(np.ravel(arr.mask) == False,np.ravel(arr.data),0)
            nodata=arr.fill_value
        except:
            arr1=np.array(arr)
            nodata=None
    if nodata == None or np.in1d(nodata,arr1)[0]:
        fnd=False
        for i in range(0,len(l_prefered_nodata)):
            if l_prefered_nodata[i][0] == arr1.dtype:
                for nodata in l_prefered_nodata[i][1:]:
                    if not np.in1d(nodata,arr1)[0]:
                        fnd=True
                        break
                break
        if not fnd:
            if arr1.dtype in [bool,bool8]: nodata=False
            elif arr1.dtype in [uint8,uint16,uint32,uint64]: nodata=arr1.max()+1
            else: nodata=arr1.min()-1
    return nodata

def _get_min_dtype(l_val,*args):
    """Function to get the minimal common dtype of a list of values/arrays.
    """
    if type(l_val) != list:
        if type(l_val) == tuple: l_val=list(l_val)
        else: l_val=[l_val]
    for arg in args: l_val.append(arg)
    dt=np.array(1,bool).dtype
    for v in l_val:
        try:
            try: v=v.arr
            except: pass
            if type(v) != type(None):
                dt=np.promote_types(dt,np.min_scalar_type(_value_dtype2type(v)))
        except: pass
    return dt
