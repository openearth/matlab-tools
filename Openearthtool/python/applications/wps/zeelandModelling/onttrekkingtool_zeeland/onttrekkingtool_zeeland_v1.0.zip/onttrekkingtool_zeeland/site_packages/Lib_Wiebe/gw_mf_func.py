## GROUNDWATER AND MODFLOW FUNCTIONS ##


## IMPORTING MODULES ##

try:
    from general_func import *
    from timing_func import *
except:
    pass


## GXG FUNCTIONS ##

def bepaling_gxgi(timearr,interval=14,ndag=20,njaar=8,startmaand=4,gvg=0,ndag2=1,gvgmarge=5,return_hydjaar=0):
    ## maakt een lijst van index nummers van de tijdstappen die gebruikt worden voor GxG bepaling; 0-dimensie = jaren; 1-dimensie = index nummers
    ##
    ## timearr = list of array: 0-dimensie = tijdstappen; 1-dimensie = jaar,maand,dag per tijdstap
    ## interval = interval tussen dagen die meegenomen worden; 14 = dag 14 en 28 van elke maand
    ## ndag = minimum aantal dagen voor een 'geldig' jaar
    ## njaar = aantal 'geldige' jaren dat meegenomen wordt; negatief = vanaf njaar voor laatste jaar (periode waarbinnen ook 'niet-geldige' jaren kunnen liggen)
    ## startmaand = start maand van hydrologisch jaar; 4 = april
    ## gvg = flag om GVG wel/niet te bepalen rond 1 april (=gvg2)
    ## ndag2 = minimum aantal dagen voor een 'geldig' jaar voor GVG_1april
    ## gvgmarge = aantal dagen rond 1 april voor bepaling GVG_1april; 5 = 28-maart t/m 5-april = 9 dagen
    ##
    ## argumenten in realistische waarden omzetten
    if interval == None: interval=14
    if ndag == None: ndag=365
    if njaar == None: njaar=8
    if startmaand == None: startmaand=4
    if gvg == None: gvg=False
    if ndag2 == None: ndag2=1
    if gvgmarge == None: gvgmarge=5
    if return_hydjaar == None: return_hydjaar=False
    interval=max(1,min(interval,28))
    ndag=max(1,min(ndag,(array([31,28,31,30,31,30,31,31,30,31,30,31])/interval).sum()))
    startmaand=max(1,min(startmaand,12))
    ndag2=max(1,min(ndag2,365))
    gvgmarge=max(1,min(gvgmarge,30))
    ilist1,ilist2=[[]],[[]]
    djaar=[0]*12
    for i in range(0,12):
        if i+1 < startmaand:
            djaar[i]=1
    hydjaar_old=timearr[0,0]-djaar[timearr[0,1]-1]-1
    hydjaarlist=[[hydjaar_old],[hydjaar_old]]
    for i in range(0,len(timearr)):
        jaar,maand,dag=timearr[i]; hydjaar=jaar-djaar[maand-1]
        if hydjaar != hydjaar_old:
            if len(ilist1[-1]) < ndag:
                ilist1[-1]=[]; hydjaarlist[0]=hydjaarlist[0][:-1]
            else:
                ilist1.append([])
            if len(ilist2[-1]) < ndag2:
                ilist2[-1]=[]; hydjaarlist[1]=hydjaarlist[1][:-1]
            else:
                ilist2.append([])
            hydjaar_old=hydjaar
            hydjaarlist[0].append(hydjaar); hydjaarlist[1].append(hydjaar)
        if dag in range(0,32,interval)[1:]:
            ilist1[-1].append(i)
        if (maand == 3 and dag in range(32-gvgmarge+1,32)) or (maand == 4 and dag in range(1,1+gvgmarge)):
            ilist2[-1].append(i)
    if len(ilist1[-1]) < ndag:
        ilist1=ilist1[:-1]; hydjaarlist[0]=hydjaarlist[0][:-1]
    if len(ilist2[-1]) < ndag2:
        ilist2=ilist2[:-1]; hydjaarlist[1]=hydjaarlist[1][:-1]
    if njaar > 0:
        ilist1,ilist2=ilist1[-njaar:],ilist2[-njaar:]
    else:
        ilist1b,ilist2b=[],[]
        for i in range(0,len(hydjaarlist[0])):
            if hydjaarlist[0][i] > hydjaar+njaar:
                ilist1b.append(ilist1[i])
        for i in range(0,len(hydjaarlist[1])):
            if hydjaarlist[1][i] > hydjaar+njaar:
                ilist2b.append(ilist2[i])
        ilist1,ilist2=deepcopy(ilist1b),deepcopy(ilist2b)
    if gvg and return_hydjaar: return ilist1,ilist2,hydjaarlist[0],hydjaarlist[1]
    elif gvg and not return_hydjaar: return ilist1,ilist2
    elif not gvg and return_hydjaar: return ilist1,hydjaarlist[0]
    else: return ilist1

def bepaling_gxg(timearr,gwsarr,avg=True,ngem=3,interval=14,ndag=20,njaar=8,startmaand=4,gvg=False,ndag2=1,gvgmarge=5,return_indiv=False,return_hydjaar=False,unit=None):
    ## bepaalt de GxG
    ##
    ## timearr = list of array: 0-dimensie = tijdstappen; 1-dimensie = jaar,maand,dag per tijdstap
    ## gwsarr = array van grondwaterstanden: 0-dimensie = tijdstappen; 1-dimensie en verder = grondwaterstanden
    ## avg = flag om jaarlijkse GxG wel/niet te middelen tot langjarige GxG
    ## ngem = aantal waarden per jaar om jaarlijkse GxG te bepalen; 3 = standaard aantal
    ## interval = interval tussen dagen die meegenomen worden; 14 = dag 14 en 28 van elke maand
    ## ndag = minimum aantal dagen voor een 'geldig' jaar
    ## njaar = aantal 'geldige' jaren dat meegenomen wordt; negatief = vanaf njaar voor laatste jaar (periode waarbinnen ook 'niet-geldige' jaren kunnen liggen)
    ## startmaand = start maand van hydrologisch jaar; 4 = april
    ## gvg = flag om GVG wel/niet te bepalen rond 15 maart (=gvg2)
    ## ndag2 = minimum aantal dagen voor een 'geldig' jaar voor GVG_15maart
    ## gvgmarge = aantal dagen rond 15 maart voor bepaling GVG_15maart; 5 = 11-maart t/m 20-maart = 10 dagen
    ##
    ## zonder avg:
    ##    [{jaren},{glg,ghg,gvg}] , ([{jaren},{gvg2}])
    ## met avg:
    ##    {glg,ghg,gvg,(gvg2)}
    ##
    if avg == None: avg=False
    if ngem == None: ngem=3
    if interval == None: interval=14
    if ndag == None: ndag=365
    if njaar == None: njaar=8
    if startmaand == None: startmaand=4
    if gvg == None: gvg=False
    if ndag2 == None: ndag2=1
    if gvgmarge == None: gvgmarge=5
    if return_indiv == None: return_indiv=False
    if return_hydjaar == None: return_hydjaar=False
    try: unit=string.lower(string.strip(unit))
    except: unit=""
    interval=max(1,min(interval,28))
    ndag=max(1,min(ndag,(array([31,28,31,30,31,30,31,31,30,31,30,31])/interval).sum()))
    startmaand=max(1,min(startmaand,12))
    ndag2=max(1,min(ndag2,365))
    ngem=max(1,min(ngem,(array([31,28,31,30,31,30,31,31,30,31,30,31])/interval).sum()))
    gvgmarge=max(1,min(gvgmarge,182))
    if gvg and return_hydjaar: ilist1,ilist2,hydjaar1,hydjaar2=bepaling_gxgi(timearr,interval,ndag,njaar,startmaand,gvg,ndag2,gvgmarge,return_hydjaar)
    elif gvg and not return_hydjaar: ilist1,ilist2=bepaling_gxgi(timearr,interval,ndag,njaar,startmaand,gvg,ndag2,gvgmarge,return_hydjaar)
    elif not gvg and return_hydjaar: ilist1,hydjaar1=bepaling_gxgi(timearr,interval,ndag,njaar,startmaand,gvg,ndag2,gvgmarge,return_hydjaar)
    else: ilist1=bepaling_gxgi(timearr,interval,ndag,njaar,startmaand,gvg,ndag2,gvgmarge,return_hydjaar)
    if return_indiv:
        gxgarr=ones((len(ilist1),3,ngem)+gwsarr.shape[1:],float64)*-9999
        tarr=zeros((len(ilist1),2,ngem,3)+gwsarr.shape[1:],timearr.dtype.name)
        for i in range(0,len(ilist1)):
            sortarr=argsort(take(gwsarr,ilist1[i]),axis=0)
            gxg=sortarray(take(gwsarr,ilist1[i]),sortarr,0)
            tijd=take(timearr,ilist1[i])
            tijd=reshape(tijd,tijd.shape+(1,)*(len(sortarr.shape)-1))
            for j in range(1,len(sortarr.shape)):
                tijd=repeat(tijd,sortarr.shape[j],j+1)
            sortarrt=repeat(reshape(sortarr,(sortarr.shape[0],1)+sortarr.shape[2:]),3,1)
            tijd=sortarray(tijd,sortarrt,0)
            ##tijd=sortarray(take(timearr,ilist1[i]),sortarr,0)
            gxgarr[i,0,:min((len(ilist1[i])+1)/2,ngem)]=gxg[:min((len(ilist1[i])+1)/2,ngem)]
            gxgarr[i,1,-min((len(ilist1[i])+1)/2,ngem):]=gxg[-min((len(ilist1[i])+1)/2,ngem):]
            tarr[i,0,:min((len(ilist1[i])+1)/2,ngem)]=tijd[:min((len(ilist1[i])+1)/2,ngem)]
            tarr[i,1,-min((len(ilist1[i])+1)/2,ngem):]=tijd[-min((len(ilist1[i])+1)/2,ngem):]
        if unit == "m": gxgarr[:,2]=gxgarr[:,1].copy()+0.05+(gxgarr[:,0].copy()-gxgarr[:,1].copy())/5
        elif unit == "cm": gxgarr[:,2]=gxgarr[:,1].copy()+5+(gxgarr[:,0].copy()-gxgarr[:,1].copy())/5
        else: gxgarr[:,2]=gxgarr[:,1].copy()+(gxgarr[:,0].copy()-gxgarr[:,1].copy())/6
##    if return_indiv:
##        gxgarr=ones((len(ilist1),3,ngem)+gwsarr.shape[1:],float64)*-9999
##        tarr=zeros((len(ilist1),2,ngem,3),timearr.dtype.name)
##        for i in range(0,len(ilist1)):
##            sortarr=argsort(take(gwsarr,ilist1[i]),axis=0)
##            gxg=sortarray(take(gwsarr,ilist1[i]),sortarr,0)
##            tijd=sortarray(take(timearr,ilist1[i]),sortarr,0)
##            gxgarr[i,0,:min((len(ilist1[i])+1)/2,ngem)]=gxg[:min((len(ilist1[i])+1)/2,ngem)]
##            gxgarr[i,1,-min((len(ilist1[i])+1)/2,ngem):]=gxg[-min((len(ilist1[i])+1)/2,ngem):]
##            tarr[i,0,:min((len(ilist1[i])+1)/2,ngem)]=tijd[:min((len(ilist1[i])+1)/2,ngem)]
##            tarr[i,1,-min((len(ilist1[i])+1)/2,ngem):]=tijd[-min((len(ilist1[i])+1)/2,ngem):]
        if gvg:
            gvgarr=ones((len(ilist2),1,gvgmarge*2)+gwsarr.shape[1:],float64)*-9999
            tgvgarr=zeros((len(ilist2),1,gvgmarge*2,3),timearr.dtype.name)
            for i in range(0,len(ilist2)):
                gvgarr[i,0,:len(ilist2[i])]=take(gwsarr,ilist2[i])
                tgvgarr[i,0,:len(ilist2[i])]=take(timearr,ilist2[i])
            return gxgarr,gvgarr,tarr,tgvgarr
        else:
            return gxgarr,tarr
    else:
        gxgarr=zeros((len(ilist1),3)+gwsarr.shape[1:],float64)
        for i in range(0,len(ilist1)):
            gxg=sort(take(gwsarr,ilist1[i],0),axis=0)
            gxgarr[i,0]=average(gxg[:min((len(ilist1[i])+1)/2,ngem)],axis=0)
            gxgarr[i,1]=average(gxg[-min((len(ilist1[i])+1)/2,ngem):],axis=0)
        if unit == "m": gxgarr[:,2]=gxgarr[:,1].copy()+0.05+(gxgarr[:,0].copy()-gxgarr[:,1].copy())/5
        elif unit == "cm": gxgarr[:,2]=gxgarr[:,1].copy()+5+(gxgarr[:,0].copy()-gxgarr[:,1].copy())/5
        else: gxgarr[:,2]=gxgarr[:,1].copy()+(gxgarr[:,0].copy()-gxgarr[:,1].copy())/6
        if gvg:
            gvgarr=zeros((len(ilist2),1)+gwsarr.shape[1:],float64)
            for i in range(0,len(ilist2)):
                gvgarr[i,0]=average(take(gwsarr,ilist2[i]),axis=0)
        if avg:
            if gvg and return_hydjaar: return average(gxgarr,axis=0),average(gvgarr,axis=0),hydjaar1,hydjaar2
            elif gvg and not return_hydjaar: return average(gxgarr,axis=0),average(gvgarr,axis=0)
            elif not gvg and return_hydjaar: return average(gxgarr,axis=0),hydjaar1
            else: return average(gxgarr,axis=0)
        else:
            if gvg and return_hydjaar: return gxgarr,gvgarr,hydjaar1,hydjaar2
            elif gvg and not return_hydjaar: return gxgarr,gvgarr
            elif not gvg and return_hydjaar: return gxgarr,hydjaar1
            else: return gxgarr


## METEO FUNCTIONS ##

def calc_makkink(T,P,SP,date,latitude=52.1):
    # T in [C]; P in [kPa]; SP als fractie; date in [yyyymmdd]; latitude in [degrees north]
    def calc_Delta(T):
        # T in [C]
        return (4098*0.6108*exp((17.27*T)/(T+237.3)))/((T+237.3)**2) # [kPa/C]
    def calc_lambda(T=20):
        # T in [C]
        return 2.501-(0.002361*T) # [MJ/kg]
    def calc_psychro(P,lamb=calc_lambda()):
        # P in [kPa]; lambda in [MJ/kg]
        return (1.013e-3/(0.622*lamb))*P # [kPa/C]
    def calc_J(date):
        # date in format "yyyymmdd"
        return tt2daynum(date2tt(date,"yyyymmdd"),True) # [dagnummer]
    def calc_phi(latitude):
        # latitude in [degrees north]
        return latitude*(2*math.pi/360.0) # [rad]
    def calc_delta(J):
        # J als dagnummer
        return 0.409*sin((2*math.pi*J)/365-1.39) # [rad]
    def calc_dr(J):
        # J als dagnummer
        return 1+0.033*cos((2*math.pi*J)/365) # [rad]
    def calc_omega(phi,delta):
        # phi in [rad]; delta in [rad]
        return arccos(-tan(phi)*tan(delta)) # [rad]
    def calc_Ra(dr,omega,phi,delta):
        # dr, omega, phi en delta in [rad]
        return (24*60/math.pi)*0.082*dr*(omega*sin(phi)*sin(delta)+cos(phi)*cos(delta)*sin(omega)) # [MJ/m2/d]
    def calc_Rs(Ra,SP,a_s=0.25,b_s=0.5):
        # Ra in [MJ/m2/d]; SP als fractie
        return (a_s+b_s*SP)*Ra # [MJ/m2/d]
    if type(T) in [list,tuple]: T=array(T)
    if type(P) in [list,tuple]: P=array(P)
    if type(SP) in [list,tuple]: SP=array(SP)
    if type(date) in [list,tuple]: date=array(date)
    if type(latitude) in [list,tuple]: latitude=array(latitude)
    Delta=calc_Delta(T) # [kPa/C]
    psychro=calc_psychro(P) # [kPa/C]
    J=calc_J(date) # dagnummer
    phi=calc_phi(latitude) # [rad]
    delta=calc_delta(J) # [rad]
    dr=calc_dr(J) # [rad]
    omega=calc_omega(phi,delta) # [rad]
    Ra=calc_Ra(dr,omega,phi,delta) # [MJ/m2/d]
    Rs=calc_Rs(Ra,SP); Rs=(Rs*1e6)/(3600.0*24.0) # [MJ/m2/d] >> [W/m2]
    lamb=calc_lambda(T); lamb=lamb*1e6 # [MJ/kg] >> [J/kg]
    ET0=(0.65*(Delta/(Delta+psychro))*Rs)/lamb # [kg/m2/s]
    return ET0*3600*24 # [mm/d]


## MODFLOW FUNCTIONS ##

def sp2tijdarr(splen,nts,jaarlen,schrikkel,start):
    tijdarr=[start]
    yr,mn,dy=start
    isl=isleap([yr,1,1])
    if isl and not schrikkel: fac=float(366)/float(jaarlen)
    else: fac=float(365)/float(jaarlen)
    md=month2dayduration(yr,mn)
    st=False
    for s in range(0,len(splen)):
        tslen=(float(splen[s])/float(nts[s]))
        for t in range(0,nts[s]):
            if st:
                dy=dy+tslen*fac
                while dy > md+0.5:
                    dy=dy-md
                    if mn == 12:
                        yr,mn=yr+1,1
                        isl=isleap([yr,1,1])
                        if isl and not schrikkel: fac=float(366)/float(jaarlen)
                        else: fac=float(365)/float(jaarlen)

                    else:
                        mn=mn+1
                    md=month2dayduration(yr,mn)
                tijdarr.append([yr,mn,int(around(dy))])
            st=True
    return array(tijdarr,uint16)

def checkohdtype(headfile):
    ohdtype=0
    try:
        inf=open(headfile,"rb")
        x0,x1,kstp,kper,pertim,totim,text,ncol,nrow,ilay,x2,x3,x4,x5,x6=struct.unpack("=2B 2L 2f 16s 3L 5B",inf.read(51))
        if string.find(string.lower(text),"head") != -1: ohdtype=1
        elif x0 == 253 and x1 == 176: ohdtype=1
        else: raise
        inf.close()
    except:
        try: inf.close()
        except: pass
        try:
            inf=open(headfile,"rb")
            nbh1,kstp,kper,pertim,totim,text,ncol,nrow,ilay,nbh2,nb=struct.unpack("3L 2f 16s 5L",inf.read(56))
            if string.find(string.lower(text),"head") != -1: ohdtype=2
            elif nb == ncol*nrow*4 and ncol*nrow != 0: ohdtype=2
            inf.close()
        except:
            try: inf.close()
            except: pass
    return ohdtype

def head2spatial(headfilelist,basfile,ocdfile,clonemap=None,target=0,spsav=None,tssav=None,laysav=None,feedback=0,dateopt=None,gxg=None,clipclone=None,outdir=None):
    if type(headfilelist) not in [list,tuple]: headfilelist=[headfilelist]
    nh,ih=len(headfilelist),0
    headfile=headfilelist[ih]
    maplist=[[],[],[]]
    if target != 0 and spsav != 0 and tssav != 0 and laysav != [0] and \
       os.path.isfile(headfile) and os.path.isfile(basfile) and os.path.isfile(ocdfile):
        if outdir == None: outdir=splitpath(headfile)[0]
        if outdir == "": outdir=os.getcwd()
        #if feedback: print "Reading BAS"
        inf=open(basfile,"r")
        for i in range(0,2):
            inf.readline()
        rec=string.split(inf.readline()); nlay,nrow,ncol,nsp=int(rec[0]),int(rec[1]),int(rec[2]),int(rec[3])
        inf.readline()
        for i in range(0,2):
            if i == 1:
                hnoflo=float(string.split(inf.readline())[0])
            else:
                inf.readline()
            for l in range(0,nlay):
                line1=inf.readline()
                if string.find(string.upper(line1),"FILE") != -1:
                    inf.readline()
                elif string.split(line1)[0] == "0":
                    pass
                else:
                    for r in range(0,nrow):
                        inf.readline()
        splen,nts=[],[]
        for i in range(0,nsp):
            rec=string.split(inf.readline())
            splen.append(float(rec[0])); nts.append(int(rec[1]))
        inf.close()

        #if feedback: print "Reading OCD"
        inf=open(ocdfile,"r")
        inf.readline()
        hdsav,cbcsav=[],[]
        for sp in range(0,nsp):
            hdsav.append([]); cbcsav.append([])
            for ts in range(0,nts[sp]):
                rec=string.split(inf.readline()); rec=rec+[0]*(4-len(rec))
                incode,hd,cbc=int(rec[0]),bool(abs(int(rec[1]))),bool(abs(int(rec[3])))
                hdsav[-1].append([])
                if incode == 0:
                    rec=string.split(inf.readline())
                    for l in range(0,nlay):
                        hdsav[-1][-1].append(hd*bool(abs(int(rec[2]))))
                elif incode > 0:
                    for l in range(0,nlay):
                        rec=string.split(inf.readline())
                        hdsav[-1][-1].append(hd*bool(abs(int(rec[2]))))
                else:
                    hdsav[-1][-1]=hdsav_old
                hdsav_old=deepcopy(hdsav[-1][-1])
        inf.close()

        try:
            clonemap=readclone(clonemap,None)
        except:
            clonemap=None
        if clonemap == None:
            clonemap=[0,0,1,1,1,0.0,nrow,ncol]
            clipclone=None
        if feedback:
            print "Clone: %s" %(clonemap)
            if clipclone != None: print "Clip:  %s" %(clipclone)
            print "\n"

        if (spsav == None or tssav == None or laysav == None) and feedback:
            table=[["SP","NTS","TS saved","LAY saved"]]
            for sp in range(0,nsp):
                table.append([sp+1,nts[sp]])
                ntssav,layssav=[],[]
                for ts in range(0,nts[sp]):
                    for l in range(0,nlay):
                        if hdsav[sp][ts][l]:
                            if ts not in ntssav: ntssav.append(ts)
                            if l not in layssav: layssav.append(l)
                try: tstext=indices2string(ntssav,1)
                except: tstext="-"
                try: laytext=indices2string(layssav,1)
                except: laytext="-"
                table[-1].append(tstext); table[-1].append(laytext)
            print "\n%s\n" %(layouttable(table,-1,["%d","%d","%s","%s"],["r","c","l","l"]," | ","\n"))
            if spsav != None:
                print "SP save option: %s" %(spsav)
            if tssav != None:
                print "TS save option: %s" %(tssav)
            if laysav != None:
                print "LAY save option: %s" %(laysav)
            print
        if spsav == None:
            print "Stress periods? (nsp=%d); e.g. 1-2,4,10-,-10,-8--6,-3-; a=all" %(nsp)
            if nsp > 1:
                spsav=string.lower(raw_input(" > "))
            else:
                print " > a (nsp = 1)"; spsav="a"
        if tssav == None:
            print "Time steps?"
            if max(nts) > 1:
                tssav=string.lower(raw_input(" > "))
            else:
                print " > a (nts = 1)"; tssav="a"
        if laysav == None:
            print "Layers? (nlay=%d)" %(nlay)
            if nlay > 1:
                laysav=string.lower(raw_input(" > "))
            else:
                print " > a (nlay = 1)"; laysav="a"

        try:
            startdate,yrlen,leap=dateopt
        except:
            startdate,yrlen,leap=0,365,True
        if feedback and startdate == 0:
            quit=False
            if not quit:
                print "Start date of model run (YYYYMMDD)? (q=quit)"
                while True:
                    try:
                        x=string.lower(raw_input(" > "))
                        if x in ["q","quit"]:
                            quit=True; break
                        startdate=int(x)
                        break
                    except Exception:
                        if sys.exc_info()[0] == KeyboardInterrupt: raise KeyboardInterrupt
                        else: print "   ERROR"
            if not quit:
                print "Length of year? (q=quit; default=365)"
                while True:
                    try:
                        x=string.lower(raw_input(" > "))
                        if x in ["q","quit"]:
                            quit=True; break
                        if x == "": x=365
                        yrlen=int(x)
                        break
                    except Exception:
                        if sys.exc_info()[0] == KeyboardInterrupt: raise KeyboardInterrupt
                        else: print "   ERROR"
            if not quit:
                print "Leap years applied? (q=quit; default=True)"
                while True:
                    try:
                        x=string.lower(raw_input(" > "))
                        if x in ["q","quit"]:
                            quit=True; break
                        if x in ["false","0","none","no","n"]: leap=False
                        else: leap=True
                        break
                    except Exception:
                        if sys.exc_info()[0] == KeyboardInterrupt: raise KeyboardInterrupt
                        else: print "   ERROR"
        if startdate != 0:
            tijdarr=sp2tijdarr(splen,nts,yrlen,leap,date2tt(startdate))
        else:
            tijdarr=None

        if gxg in [0,False,"0","None","none","No","no","n","False","false"]: gxg=0
        if startdate == 0: gxg=0

        if feedback and gxg == None and startdate != 0:
            print "GxG interval? (0=no GxG; 14=bimonthly; etc.)"
            while True:
                try:
                    x=string.lower(raw_input(" > "))
                    if x in ["q","quit"]:
                        break
                    if x not in ["false","0","none","no","n"]:
                        gxg=int(x)
                    break
                except Exception:
                    if sys.exc_info()[0] == KeyboardInterrupt: raise KeyboardInterrupt
                    else: print "   ERROR"

        spsavneg,tssavneg,laysavneg=[],[],[]
        try:
            if spsav in ["a","all"]:
                spsav=range(0,nsp)
            elif spsav[0] == "t":
                tlen=float(spsav[1:])
                spsav=nsp
                if tlen >= 0:
                    splensum=add.accumulate(splen)
                else:
                    splensum=add.accumulate(splen[::-1])
                for i in range(0,len(splensum)):
                    if splensum[i] > abs(tlen):
                        spsav=i; break
                    elif splensum[i] == abs(tlen):
                        spsav=i+1; break
                if tlen < 0:
                    spsav=range(0,nsp)[:i]
                else: spsav=range(0,nsp)[nsp-i-1:]
            else:
                spsav,spsavneg=string2indices(spsav,[1,nsp],-1,True)
        except:
            spsav=[]
        try:
            if tssav in ["a","all"]:
                tssav=range(0,max(nts))
            else:
                tssav,tssavneg=string2indices(tssav,[1,max(nts)],-1,True)
        except:
            tssav=[]
        try:
            if laysav in ["a","all"]:
                laysav=range(0,nlay)
            else:
                laysav,laysavneg=string2indices(laysav,[1,nlay],-1,True)
        except:
            laysav=[0]

        arrsav,arrstat=[],[]
        for sp in range(0,nsp):
            for ts in range(0,nts[sp]):
                for l in range(0,nlay):
                    if hdsav[sp][ts][l]:
                        if (sp in spsav or sp-nsp in spsavneg)\
                            and (ts in tssav or ts-nts[sp] in tssavneg)\
                            and (l in laysav or l-nlay in laysavneg):
                            arrsav.append(1)
                        else:
                            arrsav.append(0)
                        pertim=(splen[sp]/nts[sp])*(ts+1)
                        totim=sum(splen[:sp+1])-splen[sp]+pertim
                        arrstat.append([ts+1,sp+1,pertim,totim,l+1])

        if feedback: print "Reading Heads"
        i,nsav,totim_old=0,0,0
        while True:
            headfile=headfilelist[ih]
            ohdtype=checkohdtype(headfile)
            if ohdtype != 0:
                hsize=os.path.getsize(headfile)-1
                inf=open(headfile,"rb")
                if ohdtype == 1:
                    inf.read(1)
                while i < len(arrsav) and nsav < sum(arrsav) and hsize > 0:
                    if ohdtype == 1: x1,kstp,kper,pertim,totim,text,ncol,nrow,ilay,x2,x3,x4,x5,x6=struct.unpack("=B 2L 2f 16s 3L 5B",inf.read(50))
                    else: nbh1,kstp,kper,pertim,totim,text,ncol,nrow,ilay,nbh2,nb=struct.unpack("3L 2f 16s 5L",inf.read(56))
                    found=0
                    for j in range(i,len(arrstat)):
                        kstp2,kper2,pertim2,totim2,ilay2=arrstat[j]
                        if kstp == kstp2 and kper == kper2 and ilay == ilay2:
                            i=j
                            if arrsav[i]:
                                harr=reshape(fromstring(inf.read(4*nrow*ncol),float32),(nrow,ncol))
                                if clipclone != None:
                                    harr,clonemap2=array2resample(harr,clonemap,clipclone,True,hnoflo,"avg")
                                    nrow2,ncol2=harr.shape
                                else: nrow2,ncol2,clonemap2=nrow,ncol,deepcopy(clonemap)
                                if gxg not in [None,0]:
                                    if ilay-1 in laysav:
                                        if nsav == 0:
                                            gwsarr=ones((1,len(laysav),nrow2,ncol2),float32)*hnoflo
                                            timarr=array([tijdarr[int(around(totim))-1]],uint16)
                                            totim_old=totim
                                        if totim != totim_old:
                                            gwsarr=concatenate([gwsarr,ones((1,len(laysav),nrow2,ncol2),float32)*hnoflo])
                                            timarr=concatenate([timarr,array([tijdarr[int(around(totim))-1]],uint16)])
                                        gwsarr[-1,laysav.index(ilay-1)]=harr.copy()
                                else:
                                    if tijdarr != None:
                                        outmap="%s/head_%s_l%d.%s" %(outdir,tt2date(tijdarr[int(around(totim))-1]),ilay,source2ext(target))
                                    else:
                                        outmap="%s/h_l%d_s%d_t%d.%s" %(outdir,ilay,kper,kstp,source2ext(target))
                                    array2spatial(target,harr,outmap,clonemap2,hnoflo)
                                    if feedback: print " %s" %(outmap)
                                nsav=nsav+1
                            else:
                                inf.read(4*nrow*ncol)
                            if ohdtype == 1: inf.read(3)
                            else: inf.read(4)
                            found=1; break
                    if not found:
                        if ohdtype == 1: inf.read(4*nrow*ncol+3)
                        else: inf.read(4*nrow*ncol+4)
                    if ohdtype == 1: hsize=hsize-(53+4*nrow*ncol)
                    else: hsize=hsize-(60+4*nrow*ncol)
                    i=i+1
                    totim_old=totim
                inf.close()
            ih=ih+1
            if ih > nh-1: break

        if gxg not in [None,0] and nsav > 0:
            if feedback: print "Calculating GxG"
            gxgtext=["glg","ghg"]
            avg,ngem,ndag,njaar,startmaand,gvg,ndag2,gvgmarge=1,3,1,100,4,0,1,5
            print "%s .. %s" %(tt2date(timarr[0],"yyyy-mm-dd"),tt2date(timarr[-1],"yyyy-mm-dd"))
            for l in range(0,len(laysav)):
                gxgarr=bepaling_gxg(timarr,gwsarr[:,l],avg,ngem,gxg,ndag,njaar,startmaand,gvg,ndag2,gvgmarge)
                for i in range(0,len(gxgtext)):
                    outmap="%s/%s_l%d.%s" %(outdir,gxgtext[i],laysav[l]+1,source2ext(target))
                    array2spatial(target,gxgarr[i],outmap,clonemap2,hnoflo); maplist[target-1].append(outmap)
                    if feedback: print " %s" %(outmap)
    return maplist

def checkbudtype(budgetfile):
    budtype=0
    try:
        inf=open(budgetfile,"rb")
        x0,x1,kstp,kper,text,ncol,nrow,nlay,x2,x3,x4,x5,x6=struct.unpack("=2B 2L 16s 3L 5B",inf.read(43))
        inf.close()
        if x0 == 253 and x1 == 144: budtype=1
        elif x0 == 253 and x1 == 176: budtype=4
        else: raise
    except:
        try: inf.close()
        except: pass
        try:
            inf=open(budgetfile,"rb")
            x0,kstp,kper,text,ncol,nrow,nlay,x1,nb=struct.unpack("=3L 16s 5L",inf.read(48))
            inf.close()
            if nb == nlay*nrow*ncol*4: budtype=2
        except:
            try: inf.close()
            except: pass
            try:
                inf=open(budgetfile,"rb")
                kstp,kper,text,ncol,nrow,nlay=struct.unpack("=2L 16s 3L",inf.read(36))
                inf.close()
                if min(kstp,kper,ncol,nrow,nlay) > 0 and max(kstp,kper,ncol,nrow,nlay) < 1e31: budtype=3
            except:
                try: inf.close()
                except: pass
    return budtype

def budget2array(budgetfile,sp="all",ts="all"):
    maparr,fl=[],[]
    budtype=checkbudtype(budgetfile)
    if sp == "all": sp=["all"]
    elif type(sp) == str: sp=string2ilist(sp)
    else:
        try: sp=list(sp)
        except: sp=ravel(sp).tolist()
    if ts == "all": ts=[["all"]]*len(sp)
    elif type(ts) == str: ts=[string2ilist(ts)]*len(sp)
    else:
        try:
            ts=list(ts)
            for i in range(0,len(ts)):
                if type(ts[i]) == str: ts[i]=string2ilist(ts[i])
        except: ts=ravel(ts).tolist()
    if budtype != 0:
        inf=open(budgetfile,"rb")
        isp,its=0,0
        while True:
            try:
                if budtype == 1:
                    x0,x1,kstp,kper,text,ncol,nrow,nlay,x2,x3,x4,x5,x6=struct.unpack("=2B 2L 16s 3L 5B",inf.read(43))
                elif budtype == 4:
                    x0,x1,kstp,kper,x2,x3,text,ncol,nrow,nlay,x4,x5,x6,x7,x8=struct.unpack("=2B 4L 16s 3L 5B",inf.read(51))
                elif budtype == 2:
                    x0,kstp,kper,text,ncol,nrow,nlay,x1,nb=struct.unpack("=3L 16s 5L",inf.read(48))
                else:
                    kstp,kper,text,ncol,nrow,nlay=struct.unpack("=2L 16s 3L",inf.read(36))
                if sp[0] == "all" or kper in sp:
                    isp=0
                    if sp[0] != "all": isp=sp.index(kper)
                    if ts[isp][0] == "all" or kstp in ts[isp]:
                        if len(fl) == 0:
                            maparr=reshape(fromstring(inf.read(4*ncol*nrow*nlay),float32),(1,nlay,nrow,ncol))
                        else:
                            maparr=concatenate([maparr,reshape(fromstring(inf.read(4*ncol*nrow*nlay),float32),(1,nlay,nrow,ncol))])
                        fl.append([text,kper,kstp,nlay,nrow,ncol])
                    else: inf.read(4*ncol*nrow*nlay)
                else: inf.read(4*ncol*nrow*nlay)
                if budtype == 1 and string.lower(string.strip(text)) in ["constant head","flow right face","flow front face","flow lower face"]: inf.read(3)
                elif budtype in [1,2]: inf.read(4)
                elif budtype == 4: inf.read(3)
            except:
                break
        inf.close()
    return maparr,fl

def array2mfbin(dataarray,mfbinfile,int=None,linux=None):
    nrow,ncol=dataarray.shape
    if linux == None:
        if int == None:
            header,tail=struct.pack("2l 2f 16s 3l",1,1,1,1,"%16s" %("mfbinfile"),ncol,nrow,1),""
        else:
            header,tail="",""
    else:
        header,tail=struct.pack("3l 2f 16s 5l",44,1,1,1,1,"%16s" %("mfbinfile"),ncol,nrow,1,44,nrow*ncol*4),struct.pack("l",nrow*ncol*4)
    if int == None:
        arraystring=array(dataarray,float32).tostring()
    else:
        arraystring=array(dataarray,int32).tostring()
    outf=open(mfbinfile,"wb"); outf.write(header+arraystring+tail); outf.close()

def mfbin2array(mfbinfile,int=None,linux=None):
    inf=open(mfbinfile,"rb")
    if linux == None:
        if int == None:
            header=struct.unpack("2l 2f 16s 3l",inf.read(44))
            ncol,nrow=header[5:7]
        else:
            nrow,ncol=1,os.path.getsize(mfbinfile)/4
    else:
        header=struct.unpack("3l 2f 16s 5l",inf.read(56))
        ncol,nrow=header[6:8]
    if int == None:
        dataarray=reshape(fromstring(inf.read(nrow*ncol*4),float32),(nrow,ncol))
    else:
        dataarray=reshape(fromstring(inf.read(nrow*ncol*4),int32),(nrow,ncol))
    inf.close()
    return dataarray

def budget2array(budgetfile):
    filesize,skip=os.path.getsize(budgetfile),1
    inf=open(budgetfile,"rb")
    n=0
    while 1:
        try:
            header=struct.unpack("2L 16s 3L",inf.read(36)); nc,nr,nl=header[3:]
            if n == 0:
                budgetarray=zeros((3,nl,nr,nc),float32); n=1
                if skip:
                    remain=15*(4*nc*nr*nl+36); skip=filesize-36-remain; perskip=100*1024**2
                    for skipbytes in [perskip]*(skip/perskip)+[skip%perskip]:
                        inf.read(skipbytes)
                    header=struct.unpack("2L 16s 3L",inf.read(36)); skip=0
            if header[2] in ["FLOW RIGHT FACE ","FLOW FRONT FACE ","FLOW LOWER FACE "]:
                if header[2] == "FLOW RIGHT FACE ":
                    budgetarray[0]=reshape(fromstring(inf.read(4*nc*nr*nl),float32),(nl,nr,nc))
                elif header[2] == "FLOW FRONT FACE ":
                    budgetarray[1]=reshape(fromstring(inf.read(4*nc*nr*nl),float32),(nl,nr,nc))
                else:
                    budgetarray[2]=reshape(fromstring(inf.read(4*nc*nr*nl),float32),(nl,nr,nc))
            else:
                inf.read(4*nc*nr*nl)
        except:
            break
    inf.close()
    return budgetarray

def budgetdrain2array(budgetfile,all_layers=1,sp=0):
    inf=open(budgetfile,"rb")
    n=0; budgetarray,splist=[],[]
    while 1:
        try:
            header=struct.unpack("2L 16s 3L",inf.read(36)); nc,nr,nl=header[3:]
            if header[2] == "          DRAINS":
                if not all_layers:
                    budgetarray.append(sum(reshape(fromstring(inf.read(4*nc*nr*nl),float32),(nl,nr,nc))))
                    header=list(header); header[-1]=1
                else:
                    budgetarray.append(reshape(fromstring(inf.read(4*nc*nr*nl),float32),(nl,nr,nc)))
                if sp:
                    splist.append(header)
            else:
                inf.read(4*nc*nr*nl)
        except:
            break
    inf.close()
    if sp:
        return [budgetarray,splist]
    else:
        return budgetarray

def heads2array(headfile,linux=None,saveheads=[]):
    q,hf=1,"3l 2f 16s 4L"
    if linux == None:
        q,hf=0,"2l 2f 16s 3L"
    filesize,skip=os.path.getsize(headfile),1
    inf=open(headfile,"rb")
    n=0; l_old=0; spcount=0
    if saveheads != []:
        headslist=[]
    while 1:
        try:
            header=struct.unpack(hf,inf.read(44+2*q*4)); nc,nr,l=header[5+q:8+q]
            if l <= l_old:
                n=0
                if saveheads != []:
                    try:
                        if saveheads[spcount]:
                            headslist.append(headsarray)
                        else:
                            headslist.append(0)
                    except:
                        headslist.append(0)
                    spcount=spcount+1
                elif skip:
                    nskip=max(filesize/(l_old*(nc*nr*4+44+4*q*4))-2,0)
                    skip=nskip*(l_old*(nc*nr*4+44+4*q*4)); perskip=100*1024**2
                    for skipbytes in [perskip]*(skip/perskip)+[skip%perskip]:
                        inf.read(skipbytes)
                    skip=0
            l_old=l
            inf.read(q*4)
            if n == 0:
                headsarray=array([reshape(fromstring(inf.read(4*nc*nr),float32),(nr,nc))],float32); n=1
            else:
                headsarray=array(concatenate([headsarray,[reshape(fromstring(inf.read(4*nc*nr),float32),(nr,nc))]]),float32)
            inf.read(q*4)
        except:
            if saveheads != []:
                try:
                    if saveheads[spcount]:
                        headslist.append(headsarray)
                    else:
                        headslist.append(0)
                except:
                    headslist.append(0)
            break
    inf.close()
    if saveheads != []:
        return headslist
    else:
        return headsarray

def headspoint2array(headfile,pointlist,mvfloat,sp=0,linux=None):
    headslist,splist=[],[]
    if pointlist != []:
        q,hf=1,"3L 2f 16s 4L"
        if linux == None:
            q,hf=0,"2L 2f 16s 3L"
        inf=open(headfile,"rb")
        n=0; l_old=0
        while 1:
            try:
                header=struct.unpack(hf,inf.read(44+2*q*4)); nc,nr,l=header[5+q:8+q]
                if l <= l_old:
                    n=0
                    headslist.append(headparray)
                l_old=l
                inf.read(q*4)
                if n == 0:
                    headparray=ones((len(pointlist)),float32)*mvfloat; n=1
                    if sp:
                        splist.append(header)
                headsarray=reshape(fromstring(inf.read(4*nc*nr),float32),(nr,nc))
                for p in range(0,len(pointlist)):
                    headp=headsarray[pointlist[p][2],pointlist[p][3]]
                    if headparray[p] == mvfloat:
                        headparray[p]=headp
                inf.read(q*4)
            except:
                headslist.append(headparray)
                break
        inf.close()
    if sp:
        return [headslist,splist]
    else:
        return headslist

def tssbin2array(tssbinfile,agearray=None,top_c_act=[1,1,1]):
    inf=open(tssbinfile,"rb")
    text=struct.unpack("=6s",inf.read(6))[0]
    if text == "tssbin":
        ts,nrow,ncol=struct.unpack("=LLL",inf.read(12))
        if type(top_c_act) not in [list,tuple]:
            top_c_act=[1,1,1]
        elif len(top_c_act) < 3:
            top_c_act=list(top_c_act)
            for n in range(0,3-len(top_c_act)):
                top_c_act.append(1)
        maparraylist=[None,None,None]
        byteslist,typelist=[4,4,1],[float32,float32,uint8]
        for n in range(0,len(byteslist)):
            if top_c_act[n] not in [None,"",0,"0","skip","SKIP"]:
                if top_c_act[n] > 0:
                    maparraylist[n]=zeros((ts,nrow,ncol),typelist[n])
                else:
                    maparraylist[n]=zeros((1,nrow,ncol),typelist[n])
        if agearray not in [None,"",0,"0"]:
            maparraylist.append(zeros((ts),float32))
        for n in range(0,ts):
            if agearray in [None,"",0,"0"]:
                inf.read(4)
            else:
                maparraylist[3][n]=struct.unpack("=f",inf.read(4))[0]
            for m in range(0,len(byteslist)):
                try:
                    if top_c_act[m] in ["skip","SKIP"]:
                        pass
                    elif top_c_act[m] in [None,"",0,"0"]:
                        inf.read(byteslist[m]*nrow*ncol)
                    elif top_c_act[m] > 0:
                        maparraylist[m][n]=reshape(fromstring(inf.read(byteslist[m]*nrow*ncol),typelist[m]),(nrow,ncol))
                    elif n == ts-1:
                        maparraylist[m][-1]=reshape(fromstring(inf.read(byteslist[m]*nrow*ncol),typelist[m]),(nrow,ncol))
                    else:
                        inf.read(byteslist[m]*nrow*ncol)
                except:
                    pass
    else:
        maparraylist=None
    inf.close()
    return maparraylist

def array2tssbin(tssbinfile,toppeatarray,c_accarray,actunitarray,agelist=None):
    if toppeatarray.shape == c_accarray.shape == actunitarray.shape:
        ts,nrow,ncol=toppeatarray.shape
        if agelist == None:
            agelist=range(0,ts)[::-1]
        elif len(agelist) != ts:
            agelist=range(0,ts)[::-1]
        else:
            for n in agelist:
                try:
                    float(n)
                except:
                    agelist=range(0,ts)[::-1]; break
        if toppeatarray.dtype.name != float32:
            toppeatarray=array(toppeatarray,float32)
        if c_accarray.dtype.name != float32:
            c_accarray=array(c_accarray,float32)
        if actunitarray.dtype.name != uint8:
            actunitarray=array(actunitarray,uint8)
        tssbinf=open(tssbinfile,"wb")
        tssbinf.write(struct.pack("=6sLLL","tssbin",ts,nrow,ncol))
        for n in range(0,ts):
            tssbinf.write(struct.pack("=f",agelist[n]))
            tssbinf.write(toppeatarray[n].tostring()+c_accarray[n].tostring()+actunitarray[n].tostring())
        tssbinf.close()
    else:
        raise Exception,"arrays don't match"

def profilebin2array(profilebinfile):
    inf=open(profilebinfile,"rb")
    text=struct.unpack("=10s",inf.read(10))[0]
    if text == "profilebin":
        nlay,nrow,ncol=struct.unpack("=LLL",inf.read(12))
        maparraylist=[reshape(fromstring(inf.read(4*nlay*nrow*ncol),float32),(nlay,nrow,ncol)),reshape(fromstring(inf.read(nlay*nrow*ncol),uint8),(nlay,nrow,ncol))]
    else:
        maparraylist=None
    inf.close()
    return maparraylist

def array2profilebin(profilebinfile,toparray,unitarray):
    if toparray.shape == unitarray.shape:
        nlay,nrow,ncol=toparray.shape
        if toparray.dtype.name != float32:
            toparray=array(toparray,float32)
        if unitarray.dtype.name != uint8:
            unitarray=array(unitarray,uint8)
        profilebinf=open(profilebinfile,"wb")
        profilebinf.write(struct.pack("=10sLLL","profilebin",nlay,nrow,ncol)+toparray.tostring()+unitarray.tostring())
        profilebinf.close()
    else:
        raise Exception,"arrays don't match"
