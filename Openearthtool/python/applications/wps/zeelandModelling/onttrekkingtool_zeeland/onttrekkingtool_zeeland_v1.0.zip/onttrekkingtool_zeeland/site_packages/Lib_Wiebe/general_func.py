## GENERAL FUNCTIONS ##

## IMPORTING MODULES ##

try:
    import string, os.path, os, filecmp, zipfile, cPickle, pickle, mmap, struct, tempfile, zlib
    import time
    from copy import deepcopy
    from numpy import *
    import numpy as np
    import win32api
except:
    pass


## FUNCTIONS TO GET PROPERTIES/ATTRIBUTES OF VARIABLES ##

def get_power10(n):
    return int(string.split("%E" %(n),"E")[1])

def get_uintbits(n):
    n=int(abs(n))
    if n < 256: return 8
    elif n < 65536: return 16
    else: return 32

def get_intbits(n):
    n=int(n)
    if n >= 0:
        if n < 128: return 8
        elif n < 32768: return 16
        else: return 32
    else:
        if n >= -128: return 8
        elif n >= -32768: return 16
        else: return 32

def get_arrtype(x,at0=None):
    at=None
    tx=type(x)
    if tx not in [bool,int,long,float,complex,str,type(None)]:
        try:
            a=array(x)
            at=a.dtype
            if at in [int8,uint16,int16,uint32,int32,uint64,int64]:
                minval,maxval=a.min(),a.max()
                if minval >= 0:
                    at=uint8
                    for n in [4,2,1,0]:
                        if maxval > 256**n-1:
                            at=lookup(max(8,8*n*2),[[8,uint8],[16,uint16],[32,uint32],[64,uint64]],at); break
                else:
                    at=int8
                    for n in [4,2,1,0]:
                        if minval < -(256**n)/2 or maxval > (256**n)/2-1:
                            at=lookup(max(8,8*n*2),[[8,int8],[16,int16],[32,int32],[64,int64]],at); break
            elif at == float64 and tx in [list,tuple]: at=float32
        except: pass
    elif tx in [bool,bool_]: at=bool
    elif tx in [int,long,uint8,uint16,uint32,uint64,int8,int16,int32,int64]:
        if x >= 0:
            at=uint8
            for n in [4,2,1,0]:
                if x > 256**n-1:
                    at=lookup(max(8,8*n*2),[[8,uint8],[16,uint16],[32,uint32],[64,uint64]],at); break
        else:
            at=int8
            for n in [4,2,1,0]:
                if x < -(256**n)/2:
                    at=lookup(max(8,8*n*2),[[8,int8],[16,int16],[32,int32],[64,int64]],at); break
    elif tx == float: at=float32
    elif tx == complex: at=complex32
    at=dtype(at).name
    if at != None and at0 != None:
        if at == bool: at=at0
        elif at == uint8 and at0 in [int8,uint16,int16,uint32,int32,uint64,int64,float32,float64]: at=at0
        elif at == uint16 and at0 in [int16,uint32,int32,uint64,int64,float32,float64]: at=at0
        elif at == uint32 and at0 in [int32,uint64,int64]: at=at0
        elif at == uint32 and at0 in [float32,float64]: at=float64
        elif at == uint64 and at0 in [int64,float64]: at=at0
        elif at == uint64 and at0 in [float32]: at=float64
        elif at == int8 and at0 in [int16,int32,int64,float32,float64]: at=at0
        elif at == int8 and at0 in [uint16]: at=int16
        elif at == int8 and at0 in [uint32]: at=int32
        elif at == int8 and at0 in [uint64]: at=int64
        elif at == int16 and at0 in [int32,int64,float32,float64]: at=at0
        elif at == int16 and at0 in [uint32]: at=int32
        elif at == int16 and at0 in [uint64]: at=int64
        elif at == int32 and at0 in [int64,float64]: at=at0
        elif at == int32 and at0 in [float32]: at=float64
        elif at == int64 and at0 in [float32,float64]: at=float64
        elif at == float32 and at0 in [uint32,int32,uint64,int64,float64]: at=float64
        at=dtype(at).name
    return at

def get_shape(l,get_tuple=False):
    if get_tuple: return tuple(get_shape_minmax(l)[1])
    else: return list(get_shape_minmax(l)[1])
def get_shape_minmax(l):
    try:
        l0=array(l); return l0.shape,l0.shape
    except: pass
    shmin,shmax=[],[]
    try: l0=[deepcopy(l)]
    except: l0=[l]
    i,imax=[],[]
    if type(l) not in [type(None),complex,str,bool,int,long,float,string_,bool_,uint8,uint16,uint32,uint64,int8,int16,int32,int64,float16,float32,float64]:
        shmin,shmax=[],[]
        while True:
            if type(l0[-1]) not in [type(None),complex,str,bool,int,long,float,string_,bool_,uint8,uint16,uint32,uint64,int8,int16,int32,int64,float16,float32,float64]:
                if len(l0[-1]) == 0: l0[-1]=[None]
                i.append(0); imax.append(len(l0[-1])-1); l0.append(l0[-1][0])
                if len(i) > len(shmin):
                    shmin.append(imax[-1]+1)
                    shmax.append(imax[-1]+1)
                shmin[len(i)-1]=min(shmin[len(i)-1],imax[-1]+1)
                shmax[len(i)-1]=max(shmax[len(i)-1],imax[-1]+1)
            else:
                while True:
                    if type(l0[-1]) in [type(None),complex,str,bool,int,long,float,string_,bool_,uint8,uint16,uint32,uint64,int8,int16,int32,int64,float16,float32,float64]:
                        for j in range(len(i),len(shmin)): shmin[j]=min(shmin[j],0)
                    l0=l0[:-1]
                    if i[-1] != imax[-1]:
                        i[-1]=i[-1]+1
                        l0.append(l0[-1][i[-1]])
                        break
                    else:
                        i,imax=i[:-1],imax[:-1]
                        if len(i) == 0: break
            if len(i) == 0: break
    return tuple(shmin),tuple(shmax)

# Get variable type
def get_vartype(x0):
    try: x=deepcopy(x0)
    except: x=x0
    tx=None
    try:
        tx=type(x)
        if tx not in [bool,int,long,float,complex,str,list,tuple,type(None)]: tx="array"
        else:
            for s_old,s_new in [["<type '",""],["'>",""]]: tx=string.replace(str(tx),s_old,s_new)
    except: pass
    return tx

# Get variable type, shape, dimension/rank and data type of sequence/array
def get_varspecs(x0):
    try: x=deepcopy(x0)
    except: x=x0
    tx,sx,dx,atx=None,None,None,None
    try:
        tx=get_vartype(x0)
        if tx == "array":
            sx,atx=x.shape,x.dtype.name
            dx=len(sx)
            if dx == 0: sx=(0,)
        elif tx in ["list","tuple"]:
            x0=deepcopy(x)
            arr=False
            try:
                ax=array(x0)
                sx,atx=ax.shape,ax.dtype.name
                arr=True
            except:
                try:
                    sx=get_shape_minmax(x0)
                    dx=len(sx[0])
                    if sx[0] == sx[1]: sx=sx[0]
                    else: sx=list(sx)
                    atx0,atx1=walklist(x0,"get_vartype(sub)",flatoutput=True),[]
                    atx0.sort()
                    for i in range(0,len(atx0)):
                        if type(atx0[i]) != str:
                            try: atx0[i]=get_vartype(atx0[i])
                            except: atx0[i]="?"
                        if atx0[i] not in atx1: atx1.append(atx0[i])
                    if len(atx1) == 1: atx=atx1[0]
                    else: atx="mixed:%s" %(string.join(atx1,"/"))
                except: pass
            if arr:
                dx=len(sx)
                if string.find(atx,"float") != -1: atx="float"
                elif string.find(atx,"complex") != -1: atx="complex"
                elif string.find(atx,"int") != -1:
                    minval,maxval=ax.min(),ax.max()
                    if minval < -2147483648 or maxval > 2147483647: atx="long"
                    else: atx="int"
        else: sx,dx=(0,),0
    except: pass
    return tx,sx,dx,atx

def get_lower_nodata(x,n_digit_min=6,base_val=9):
    x=array(x).min()
    n_digit_min=max(1,int(abs(n_digit_min)))
    base_val=str(int(base_val))
    if x > 0: nodata=-int(base_val*n_digit_min)
    else: nodata=-int(base_val*(max(n_digit_min,get_power10(x)+1)))
    if nodata == x: nodata=nodata*10+int(base_val)
    return nodata

  # get dtype for cast between array and other array/value(s)
def get_casttype(arr,cast_arr=None):
    try: mn,mx,fv=cast_arr.min(),cast_arr.max(),cast_arr.fill_value
    except:
        try:
            mn,mx=cast_arr.min(),cast_arr.max(); fv=mn
        except:
            try:
                a=np.array(cast_arr); mn,mx=a.min(),a.max(); fv=mn
            except: return arr.dtype
    dt=np.promote_types(np.promote_types(np.min_scalar_type(mn),np.min_scalar_type(mx)),np.min_scalar_type(fv))
    if not np.can_cast(dt,arr.dtype):
        return np.promote_types(dt,arr.dtype)
    else:
        return arr.dtype

  # convert value from numpy dtype to bool/int/float
def value_dtype2type(v):
    try:
        if v.dtype in [bool,bool8]: return bool(v)
        elif v.dtype in [float16,float32,float64]: return float(v)
        else: return int(v)
    except: return v


## REFERENCE AND LOOKUP FUNCTIONS ##

def lookup(val,lookupl,mv=None):
    result=mv
    for n in lookupl:
        if n[0] == val:
            result=n[1]; break
    return result

def lookuplist(l,lookupl,mv=None):
    l2=[]
    for val in l: l2.append(lookup(val,lookupl,mv))
    return l2

def lookupinter(val,lookupl,slope=False):
    val=float(val); l2=lookupl[:]; listsort(l2,1); lower=l2[0]
    for n in range(0,len(l2)):
        upper=l2[n]
        if val < upper[0]: break
        else: lower=upper
    if upper == lower: a=0.0
    else: a=(float(upper[1])-lower[1])/(upper[0]-lower[0])
    if slope in [False,None,0,"0",""]: return val*a+(upper[1]-a*upper[0])
    else: return a

def lookupcoverarray(inputarray,lookupl,mv=None):
    newtype=str(inputarray.dtype.name)
    if string.find(newtype,"int") != -1:
        if type(mv) in [float,float16,float32,float64]: newtype="float32"
        else:
            minval,maxval=inputarray.min(),inputarray.max()
            if mv != None: minval,maxval=min(mv,minval),max(mv,maxval)
            for old,new in lookupl:
                if type(new) in [float,float16,float32,float64]:
                    newtype="float32"; break
                minval,maxval=min(new,minval),max(new,maxval)
        if newtype != "float32":
            if string.find(newtype,"uint") != -1 and minval >= 0:
                newtype="uint8"
                for n in [4,2,1]:
                    if maxval > 256**n-1:
                        newtype="uint"+str(8*n*2); break
            else:
                newtype="int8"
                for n in [4,2,1]:
                    if maxval > ((256**n)/2)-1 or minval < -(256**n)/2:
                        newtype="int"+str(8*n*2); break
    else:
        newtype="float32"
    newarray=array(inputarray.copy(),newtype); boolean=ones(newarray.shape,uint8)
    for old,new in lookupl:
        newarray=where(where(inputarray == old,where(boolean == 1,1,0),0) == 1,new,newarray); boolean=where(inputarray == old,0,boolean)
    if mv != None: newarray=where(boolean==1,mv,newarray)
    return newarray


## PATH FUNCTIONS ##

def splitpath(path):
    base=os.path.splitext(os.path.basename(path))
    return [os.path.dirname(path),base[0],base[1][1:]]

def joinpath(l):
    s="/"
    if string.find(l[0],"\\") != -1: l[0],s=os.path.normpath(l[0]),"\\"
    if l[0] != "":
        if l[0][-1] != s: l[0]=l[0]+s
    if len(l) == 3:
        if l[-1] != "":
            if l[-1][0] != ".": l[-1]="."+l[-1]
    return string.join(l,"")

def dir_file(path):
    sp=splitpath(path)
    return sp[0],joinpath([""]+sp[1:])

def path2newdir(path,newdir):
    return joinpath([newdir]+splitpath(path)[1:])

def add2filename(path,s):
    sp=splitpath(path)
    return joinpath([sp[0],sp[1]+s,sp[2]])

def winpath(path,short_long=0,rel_abs=0,dir_src=None,dir_trg=None):
    path=os.path.normpath(path)
    dir_old=os.getcwd()
    try:
        if os.path.isfile(dir_src): dir_src=os.path.dirname(os.path.abspath(dir_src))
        else: dir_src=os.path.abspath(dir_src)
        os.chdir(dir_src)
    except: dir_src=None
    try:
        if os.path.isfile(dir_trg): dir_trg=os.path.dirname(os.path.abspath(dir_trg))
        else: dir_trg=os.path.abspath(dir_trg)
    except: dir_trg=None
    if rel_abs != 0:
        path=os.path.abspath(path)
        if rel_abs == 1:
            if dir_trg != None:
                path=os.path.relpath(path,dir_trg)
            else:
                path=os.path.relpath(path)
    if short_long != 0:
        try:
            if short_long == 1: path=win32api.GetShortPathName(path)
            else:  path=win32api.GetLongPathName(path)
        except: pass
    os.chdir(dir_old)
    return path

def pypath(path,short_long=0,rel_abs=0,dir_src=None,dir_trg=None):
    path=winpath(path,short_long,rel_abs,dir_src,dir_trg)
    l=[["\a","/a"],["\b","/b"],["\f","/f"],["\n","/n"],["\r","/r"],["\t","/t"],["\v","/v"],["\\","/"]]
    for n in l: path=string.replace(path,n[0],n[1])
    return path
##def pypath(path,short_long=0,rel_abs=0,srcdir=None):
##    olddir=os.getcwd()
##    try: os.chdir(srcdir)
##    except:
##        try:
##            if os.path.isfile(srcdir):
##                os.chdir(splitpath(srcdir)[0])
##        except: pass
##    l=[["\a","/a"],["\b","/b"],["\f","/f"],["\n","/n"],["\r","/r"],["\t","/t"],["\v","/v"],["\\","/"]]
##    for n in l: path=string.replace(path,n[0],n[1])
##    if rel_abs == 1:
##        path0=os.path.normpath(os.path.abspath(path))
##        dir0=os.path.normpath(os.getcwd())
##        try:
##            path0=win32api.GetLongPathName(path0)
##            dir0=win32api.GetLongPathName(dir0)
##        except: pass
##        cp=path0[:len(os.path.commonprefix([string.lower(dir0),string.lower(path0)]))]
##        cpl=string.split(cp,"\\")
##        if cpl[-1] == "": cpl=cpl[:-1]
##        if len(cpl) != 0:
##            pathl=string.split(path0,"\\")[len(cpl):]
##            dirl=string.split(dir0,"\\")[len(cpl):]
##            for i in range(0,len(dirl)): pathl=[".."]+pathl
##            path=string.join(pathl,"/")
##    elif rel_abs == 2:
##        path=os.path.abspath(path)
##    if short_long == 1:
##        try: path=win32api.GetShortPathName(path)
##        except: pass
##    elif short_long == 2:
##        try: path=win32api.GetLongPathName(path)
##        except: pass
##    path=string.strip(string.replace(path,"\\","/"))
##    os.chdir(olddir)
##    return path
##def winpath(path,short_long=0,rel_abs=0,srcdir=None):
##    return os.path.normpath(pypath(path,short_long,rel_abs,srcdir))
def fullpath(path,checkdir=False,srcdir=None):
    path0=pypath(path,0,2,srcdir)
    if os.path.exists(path0) or checkdir: return path0
    else: return path
def win2pypath(path):
    return pypath(path,0,0)
def py2winpath(path):
    return winpath(path,1,0)

def ispath(path):
    return os.path.exists(path)

def newfile(path):
    if os.path.exists(path):
        sp=splitpath(path)
        x1,x2,name,count=string.find(sp[1],"("),string.find(sp[1],")"),sp[1],1
        if x1 != -1 and x2 != -1 and x2 == len(sp[1])-1:
            try:
                count=int(sp[1][x1+1,x2])+1; name=sp[1][:x1]
            except: pass
        while 1:
            newpath=joinpath([sp[0],"%s(%s)" %(name,count),sp[2]])
            if not os.path.isfile(newpath) and not os.path.isdir(newpath):
                path=newpath; break
            else: count=count+1
    return path

def setnewpath(outpath,autofile=0,checkwrite=0,keep=0,ind="",return_keepall=False):
    drives,d=["d:/","c:/","m:/","q:/","h:/","e:/","f:/","g:/"],0
    outpath,keepall=fullpath(outpath),False
    while 1:
        sp=splitpath(outpath)
        if checkwrite:
            try:
                tempfile=newfile(joinpath([sp[0],"checkwrite"]))
                outf=open(tempfile,"w"); outf.close()
                os.remove(tempfile)
                checkwrite=0
            except:
                if checkwrite == 2:
                    while d < len(drives):
                        if os.path.isdir(drives[d]): break
                        d=d+1
                    sp[0]=drives[d]; outpath=joinpath(sp)
                else:
                    print "%sNo write permission on %s\n%sEnter new path (ENTER=keep):" %(ind,sp[0],ind)
                    x=raw_input("%s> " %(ind))
                    if string.strip(x) == "": checkwrite=0
                    else: outpath=fullpath(x,True)
        elif keep: break
        elif autofile:
            outpath=newfile(outpath); break
        elif os.path.isdir(outpath) or os.path.isfile(outpath):
            print "%sPath exists: %s\n%sEnter new (ENTER=keep):" %(ind,outpath,ind)
            x=raw_input("%s> " %(ind))
            if string.strip(x) == "@": keepall,keep=True,1
            elif string.strip(x) == "": keep=1
            else:
                spnew=splitpath(win2pypath(x))
                if spnew[0] == "": spnew[0]=sp[0]
                sp=deepcopy(spnew); outpath=joinpath(sp)
        else: break
    if return_keepall: return outpath,keepall
    else: return outpath

def makedir(outpath,checkwrite=0,ind="",omit_ext=False):
    while 1:
        outpath=win2pypath(outpath)
        sp=splitpath(outpath)
        if sp[0] == "":
            sp[0]=os.getcwd()
            outpath=joinpath(sp)
        if omit_ext or sp[2] == "": pl=[outpath]
        else: pl=[sp[0]]
        while 1:
            if len(pl[0]) <= 3: break
            pl=[splitpath(pl[0])[0]]+pl
        for p in range(1,len(pl)):
            outpath=pl[p]
            if not os.path.isdir(outpath):
                try: os.mkdir(outpath)
                except:
                    if checkwrite:
                        print "%sNo write permission on %s\n%sEnter new path:" %(ind,sp[0],ind)
                        x=raw_input("%s> " %(ind))
                        outpath=win2pypath(x); break
                    else:
                        outpath=None; break
        if outpath == None: break
        if os.path.isdir(outpath): break
    return outpath

#### FILE/DIR FUNCTIONS ####

def listfiles(textlist,directory,full=False,case_sensitive=True):
    indir=string.replace(directory+"/","//","/")
    dirpath=""
    if full not in [False,0,"0",None,""]: dirpath=indir
    if type(textlist) == str: textlist=[textlist]
    for i in range(0,len(textlist)):
        if type(textlist[i]) == str: textlist[i]=[textlist[i]]
    files0,l=os.listdir(directory),[]
    if not case_sensitive:
        files=[string.lower(f) for f in files0]
        for i in range(0,len(textlist)):
            for j in range(0,len(textlist[i])):
                textlist[i][j]=string.lower(textlist[i][j])
    else: files=deepcopy(files0)
    for i in range(0,len(files)):
        for jl in textlist:
            found=True
            for k in jl:
                if k != "":
                    k1=k
                    if k[0] in ["|",":"]: k1=k[1:]
                    if k[0] == "|" and files[i][:len(k1)] != k1:
                        found=False; break
                    if k[0] == ":":
                        if string.find(files[i],k1) != -1:
                            found=False; break
                    elif string.find(files[i],k1) == -1:
                        found=False; break
            if found:
                if os.path.isfile(indir+files[i]): l.append(dirpath+files0[i])
    return l

def getfilestree(root,topdown=True):
    if root[-1] == ":": root=root+"/"
    olddir=os.getcwd(); os.chdir(root); root=win2pypath(os.getcwd()); os.chdir(olddir); rootshort=splitpath(root)[0]
    fl,dl=[],[]
    for dirroot,dirs,files in os.walk(root,topdown):
        dl.append([win2pypath(dirroot)]); dl[-1]=dl[-1]+[string.replace(dl[-1][0],rootshort,""),string.replace(dl[-1][0],root,""),len(dirs),len(files)]
        try:
            if dl[-1][1][0] == "/": dl[-1][1]=dl[-1][1][1:]
            if dl[-1][2][0] == "/": dl[-1][2]=dl[-1][2][1:]
        except: pass
        for f in files:
            fl.append([f,dl[-1][0],dl[-1][1],dl[-1][2]])
    return fl,dl

def listfilestree(root,return_dirs=False,short=0):
    fl,dl=getfilestree(root,True)
    if return_dirs:
        if short < 0: dl2=sublist(dl,1)
        if short == 0: dl=sublist(dl,1)
        elif short in [1,-1]: dl=sublist(dl,2)
        else: dl=sublist(dl,3)
        if short < 0: dl=sublist([dl2,dl])
        return dl
    else:
        if short < 0: fl2=sublist(sublist(fl,[2,1]))
        if short == 0: fl=sublist(sublist(fl,[2,1]))
        elif short in [1,-1]: fl=sublist(sublist(fl,[3,1]))
        else: fl=sublist(sublist(fl,[4,1]))
        for i in range(0,len(fl)):
            fl[i]=fl[i][0]+"/"+fl[i][1]
            if fl[i][0] == "/": fl[i]=fl[i][1:]
        if short < 0:
            for i in range(0,len(fl)):
                fl[i]=[fl2[i][0]+"/"+fl2[i][1],fl[i]]
                if fl[i][0][0] == "/": fl[i][0]=fl[i][0][1:]
        return fl

def emptydir(directory,include_dirs=False):
    for root, dirs, files in os.walk(directory, topdown=False):
        for name in files: os.remove(os.path.join(root,name))
        if include_dirs:
            for name in dirs: os.rmdir(os.path.join(root,name))

def deletefilelist(filelist,ind=""):
    from geo_func import readsource
    delfiles=[[],[],[],[],[],[]] # invalid,file,grid,dir,info,file_in_info
    for i in range(0,len(filelist)):
        f=string.lower(win2pypath(string.strip(filelist[i])))
        if os.path.isfile(f):
            delfiles[1].append(f)
        elif readsource(f) == 4:
            delfiles[2].append(f)
        elif os.path.isdir(f):
            delfiles[3].append(f)
        else:
            delfiles[0].append(f)
    delfiles[3].sort(); delfiles[3]=delfiles[3][::-1]
    filelist=deepcopy(delfiles[:4])

    dl=[]
    for i in range(0,len(delfiles[3])):
        d=delfiles[3][i]; sp=splitpath(d)
        if sp[0] in delfiles[3]:
            dl=dl+listfilestree(d,1,0)
        elif sp[1] == "info" and os.path.isfile("%s/arc.dir" %(d)):
            for d2 in listfilestree(d,1,0)[1:]:
                dl=dl+listfilestree(d2,1,0)
            delfiles[4].append(d)
        else:
            dl=dl+listfilestree(d,1,0)
    delfiles[3]=deepcopy(dl)

    gl=[]
    for i in range(0,len(delfiles[2])):
        g=delfiles[2][i]; sp=splitpath(g)
        if sp[0] in delfiles[3]:
            delfiles[3]=delfiles[3]+listfilestree(d,1,0)
        else:
            gl.append(g)
    delfiles[2]=deepcopy(gl)

    if len(delfiles[2]) > 0:
        try:
            from win32com.client import Dispatch
            print "\nDeleting %d ESRI Grid(s)..." %(len(delfiles[2]))
            gp=Dispatch("esriGeoprocessing.GpDispatch.1")
            for f in delfiles[2]:
                try:
                    gp.delete(f)
                except:
                    pass
        except: pass

    dl=[]
    for i in range(0,len(delfiles[4])):
        d=delfiles[4][i]; fl=listfilestree(d,0,0)
        if len(fl) <= 1:
            delfiles[3].append(d)
        else:
            dl.append(d)
    delfiles[4]=deepcopy(dl)

    fl=[]
    for i in range(0,len(delfiles[1])):
        f=delfiles[1][i]
        if os.path.isfile(f):
            sp=splitpath(f)
            if sp[0] in delfiles[3]:
                fl.append(f)
            elif splitpath(sp[0])[1] == "info" and os.path.isfile("%s/arc.dir" %(sp[0])):
                delfiles[5].append(f)
            else:
                fl.append(f)
    delfiles[1]=deepcopy(fl)

    delfiles[3].sort(); delfiles[3]=delfiles[3][::-1]
    for d in delfiles[3]:
        if os.path.isdir(d):
            try:
                emptydir(d)
            except:
                pass
            for d2 in listfilestree(d,1,0)[::-1]:
                try:
                    os.rmdir(d2)
                except:
                    pass
    for f in delfiles[1]:
        if os.path.isfile(f):
            try:
                os.remove(f)
            except:
                pass

    noremove=[]
    for f in filelist[0]:
        noremove.append(f+" (invalid)")
    for f in filelist[1]:
        if os.path.isfile(f):
            noremove.append(f)
    for f in filelist[2]:
        if os.path.isdir(f):
            noremove.append(f+" (ESRI Grid)")
    for f in filelist[3]:
        if os.path.isdir(f):
            if f in delfiles[4]:
                noremove.append(f+" (ArcInfo dir; %d files; %d subdirs)" %(len(listfilestree(f,0,0)),len(listfilestree(f,1,0))-1))
            else:
                noremove.append(f+" (dir; %d files; %d subdirs)" %(len(listfilestree(f,0,0)),len(listfilestree(f,1,0))-1))

    if len(noremove) > 0:
        print "\n%sNot all files removed:" %(ind)
        for i in range(0,len(noremove)):
            print "%s %s" %(ind,text2width(noremove[i],70,ind+" "*2))

def isequalfile(file1,file2):
    return filecmp.cmp(file1,file2,False)
def isequaldir(dir1,dir2):
    cp=filecmp.dircmp(dir1,dir2)
    return len(cp.left_only) == 0 and len(cp.right_only) == 0 and len(cp.diff_files) == 0

def issamefile(file1,file2):
    issame=False
    if os.path.isfile(file1) and os.path.isfile(file2):
        issame=string.upper(pypath(file1,1,2)) == string.upper(pypath(file2,1,2))
    return issame
def issamedir(dir1,dir2):
    issame=False
    if os.path.isdir(dir1) and os.path.isdir(dir2):
        issame=string.upper(pypath(dir1,1,2)) == string.upper(pypath(dir2,1,2))
    return issame


## FUNCTIONS ON STRINGS, INTEGERS AND FLOATING POINTS ##

def rounddown(v,rv=1):
    v,rv=array(v),array(rv)
    return v-mod(v,rv)
def roundup(v,rv=1):
    v,rv=array(v),array(rv)
    return v+rv-mod(v,rv)
def roundoff(v,rv=1):
    v1,v2=rounddown(v,rv)-v,roundup(v,rv)-v
    return where(abs(v1) < abs(v2),v+v1,v+v2)
def roundinner(v,rv=1):
    v1,v2=rounddown(v,rv),roundup(v,rv)
    return where(v >= 0,v1,v2)
def roundouter(v,rv=1):
    v1,v2=rounddown(v,rv),roundup(v,rv)
    return where(v >= 0,v2,v1)

def splitmultiple(s,l,whitespace=False):
    if type(l) not in [list,tuple]: l=[l]
    l0=[]
    for n in l:
        if n not in ["",None]: l0.append(n)
    if len(l0) > 0:
        for n in range(0,len(l0)-1): s=string.replace(s,l0[n],l0[n+1])
        if whitespace: return string.split(string.replace(s,l0[-1]," "))
        else: return string.split(s,l0[-1])
    elif whitespace: return string.split(s)
    else: return s
def multiplesplit(s,l,whitespace=False): return splitmultiple(s,l,whitespace)

def splitmultiple2(s,l,whitespace=False,autostrip=False,keep_together=[]):
    if type(l) not in [list,tuple]: l=[l]
    l0=[]
    for n in l:
        if n not in ["",None]: l0.append(n)
    if len(l0) == 0 and not whitespace: return s
    rep_lut=[]
    for s1 in keep_together:
        s3=1
        if type(s1) == str: s1,s2=s1,s1
        elif type(s1) in [list,tuple]:
            try: s3=int(not bool(s1[2]))
            except: pass
            s1,s2=s1[:2]
        i=0
        while True:
            i1=string.find(s[i:],s1)
            if i1 == -1: break
            else:
                i1+=i
                i2=string.find(s[i1+1:],s2)
                if i2 == -1: break
                else:
                    i2+=i1+1
                    if len(l0) > 0:
                        rep_lut.append([s[i1:i2+s3],s[i1+s3:i2],replacemultiple(string.join(string.split(s[i1:i2+s3]),""),list(l0))])
                    else: rep_lut.append([s[i1:i2+s3],s[i1+s3:i2],string.join(string.split(s[i1:i2+s3]),"")])
                    i=i2+1
    for i in range(0,len(rep_lut)):
        s=string.replace(s,rep_lut[i][0],rep_lut[i][2])
    if len(l0) > 0:
        for n in range(0,len(l0)-1): s=string.replace(s,l0[n],l0[n+1])
        if whitespace: srec=string.split(string.replace(s,l0[-1]," "))
        else: srec=string.split(s,l0[-1])
    else: srec=string.split(s)
    if autostrip:
        for i in range(0,len(srec)): srec[i]=string.strip(srec[i])
    for i in range(0,len(rep_lut)):
        for j in range(0,len(srec)):
            srec[j]=string.replace(srec[j],rep_lut[i][2],rep_lut[i][1])
    return srec
def multiplesplit2(s,l,whitespace=False,autostrip=False,keep_together=[]): return splitmultiple2(s,l,whitespace,autostrip,keep_together)

def replacemultiple(s,l1,l2=None):
    if l2 == None: l2=[""]*len(l1)
    if len(l2) < len(l1):
        for n in range(len(l2),len(l1)): l2.append("")
    for n in range(0,len(l1)): s=string.replace(s,l1[n],l2[n])
    return s
def multiplereplace(s,l1,l2=None): return replacemultiple(s,l1,l2)

def get_windowsize():
    import win32console
    height,width=None,None
    try:
        window_size=win32console.CreateConsoleScreenBuffer().GetConsoleScreenBufferInfo()['Window']
        width,height=window_size.Right-window_size.Left+1,window_size.Bottom-window_size.Top+1
    except: pass
    return height,width


## CONVERSION FUNCTIONS ##

# Converts a floating point to a string with fixed length and maximum number of significant digits
#   val = floating point
#   strlen = fixed length (in some cases the minimum length is 3 or 4); default: 10
def float2str(val,strlen=10,autostrip=True):
    valstr,dec="%s" %(val),strlen-2
    if valstr[-2:] == ".0": valstr=valstr[:-2]
    while len(valstr) > strlen and dec >= 0:
        valstr="%%.%dE" %(dec) %(val)
        for t1,t2 in [["E+000",""],["E-000",""],["E+00","E+"],["E-00","E-"],["E+0","E+"],["E-0","E-"]]:
            valstr=string.replace(valstr,t1,t2)
        if valstr[-2:] == ".0": valstr=valstr[:-2]
        dec=dec-1
    if autostrip: return string.strip("%%%ss" %(strlen) %(valstr))
    else: return "%%%ss" %(strlen) %(valstr)

def int2hex(i,n_digit=0):
    h=hex(i)[2:]
    if n_digit in [None,0]:
        if i < 256: n_digit=2
        elif i < 256*256: n_digit=4
        else: n_digit=6
    return "0"*(n_digit-len(h))+h
def hex2int(h):
    l=["0","1","2","3","4","5","6","7","8","9","a","b","c","d","e","f"]
    h=string.lower(h)
    i=0
    for j in range(0,len(h)):
        i+=(l.index(h[j])*(16**(len(h)-j-1)))
    return i

def rgb2hex(r_rgb,g=0,b=0):
    if type(r_rgb) in [list,tuple]: r_rgb,g,b=r_rgb[:3]
    return int2hex(r_rgb,2)+int2hex(g,2)+int2hex(b,2)
def rgb2hexa(r_rgb,g=0,b=0,a=255):
    if type(r_rgb) in [list,tuple]:
        if len(r_rgb) > 3: a=r_rgb[3]
        r_rgb,g,b=r_rgb[:3]
    return int2hex(r_rgb,2)+int2hex(g,2)+int2hex(b,2)+int2hex(a,2)

def hex2rgb(h):
    h="%s%s" %("0"*(6-len(h)),h)
    return (hex2int(h[-6:-4]),hex2int(h[-4:-2]),hex2int(h[-2:]))
def hex2rgba(h):
    if len(h) <= 6:
        h="%s%s" %("0"*(6-len(h)),h)
        return (hex2int(h[-6:-4]),hex2int(h[-4:-2]),hex2int(h[-2:]),255)
    else:
        h="%s%s" %("0"*(8-len(h)),h)
        return (hex2int(h[-8:-6]),hex2int(h[-6:-4]),hex2int(h[-4:-2]),hex2int(h[-2:]))

def var2list(x0):
    try: x=deepcopy(x0)
    except: x=x0
    tx=get_vartype(x)
    if tx == "array": return x.tolist()
    elif tx in ["list","tuple"]:
        if len(x) == 0: return []
        for i in range(0,len(get_shape(x))):
            x=walklist(x,None,None,"list(seq)",False)
        return x
    else: return [x]

def list_ct(x0):
    try: x=deepcopy(x0)
    except: x=x0
    if type(x) == tuple:
        if len(x) == 3:
            if type(x[0]) in [bool,int,long,float,bool_,uint8,uint16,uint32,uint64,int8,int16,int32,int64,float16,float32,float64]\
                and type(x[1]) in [bool,int,long,float,bool_,uint8,uint16,uint32,uint64,int8,int16,int32,int64,float16,float32,float64]\
                and type(x[2]) in [bool,int,long,float,bool_,uint8,uint16,uint32,uint64,int8,int16,int32,int64,float16,float32,float64]:
                return x
            else: return list(x)
        else: return list(x)
    else:
        try: return list(x)
        except: return x
def var2list_ct(x0):
    try: x=deepcopy(x0)
    except: x=x0
    tx=get_vartype(x)
    if tx == "array": return x.tolist()
    elif tx in ["list","tuple"]:
        if len(x) == 0: return []
        for i in range(0,len(get_shape(x))):
            x=walklist(x,None,None,"list_ct(seq)",False)
        return x
    else: return [x]

def string2indices(text,minmax=[None,None],shift=0,neg=False):
    try:
        minval,maxval=minmax
        try:
            maxval=int(maxval)
        except:
            maxval=int(1000)
            for i in splitmultiple(text,[",","-"]):
                try: maxval=max(maxval,int(i)+100)
                except: pass
        try:
            minval=int(minval)
        except:
            minval=0
    except:
        minval,maxval=0,int(255**2)
    try:
        if shift < 0:
            shift=-1
        elif shift > 0:
            shift=1
        else:
            shift=0
    except:
        shift=0
    il,ilneg=[],[]
    rec0=string.split(text,",")
    for r0 in rec0:
        rec=string.split(r0,"-")
        negfound=False
        if neg and rec[0] == "":
            try:
                i1=i2=-int(rec[1])
                if len(rec) == 4:
                    try: i2=-int(rec[3])
                    except: pass
                elif len(rec) == 3: i2=-1
                ilneg=ilneg+range(i1,i2+1)
                negfound=True
            except: pass
        if not negfound:
            try:
                i1=rec[0]
                if i1 == "":
                    i1=minval
                i1=int(i1)
            except:
                i1=None
            try:
                i2=rec[1]
                if i2 == "":
                    i2=maxval
                i2=int(i2)
            except:
                i2=None
            if i1 != None and i2 != None:
                if i1 <= maxval and i2 >= minval:
                    il=il+range(max(i1,minval),min(i2,maxval)+1)
            elif i1 != None:
                if i1 <= maxval and i1 >= minval: il=il+[i1]
            elif i2 != None:
                if i2 <= maxval and i2 >= minval: il=il+[i2]
    il2=[]
    for i in il:
        if i+shift not in il2:
            il2.append(i+shift)
    if neg: return il2,ilneg
    else: return il2

def indices2string(indices,shift=0):
    try:
        if shift < 0:
            shift=-1
        elif shift > 0:
            shift=1
        else:
            shift=0
    except:
        shift=0
    indices.sort()
    for i in range(0,len(indices)):
        indices[i]=indices[i]+shift
    iold,groups=indices[0]-2,[]
    for i in range(0,len(indices)):
        if indices[i] > iold+1 or (indices[i] >= 0 and iold < 0):
            groups.append([indices[i]])
        else: groups[-1].append(indices[i])
        iold=indices[i]
    s=""
    for g in groups:
        if len(g) > 2 and g[0] >= 0:
            s=s+",%d-%d" %(g[0],g[-1])
        else: s=s+",%s" %(joinlist(g,","))
    s=s[1:]
    return s

def byte2bits(byte):
    bits=[]; byte=byte%256; remain=byte
    for n in [128,64,32,16,8,4,2,1]:
        bits.append(int(remain/n)); remain=remain-bits[-1]*n
    return bits

def bits2byte(bits,sig=None):
    if sig == None or sig == 0:
        return 128*bits[0]+64*bits[1]+32*bits[2]+16*bits[3]+8*bits[4]+4*bits[5]+2*bits[6]+bits[7]
    else:
        add=0
        if bits[0] == 1:
            add=-256
        return add+128*bits[0]+64*bits[1]+32*bits[2]+16*bits[3]+8*bits[4]+4*bits[5]+2*bits[6]+bits[7]

def text2linewidth(text,linewidth="get",ind="",lenfirstind=0):
    tl,tl2=string.split(text,"\n"),[]
    if linewidth == "get":
        try: linewidth=get_windowsize()[1]
        except: linewidth=50
    width=max(linewidth-len(ind)-1,1)
    if lenfirstind == None: lfi=len(ind)
    else: lfi=min(width-1,lenfirstind-len(ind))
    for t in tl:
        w,ind1=width,ind
        for i in range(0,min(width-1,len(t))):
            if t[i] == " ":
                w,ind1=w-1,ind1+" "
            else:
                break
        i=width
        s=t[:i-lfi]
        while i <= len(t):
            s=s+"\n%s%s" %(ind1,t[i:min(len(t),i+w)])
            i=i+w
        tl2.append(s)
    return string.join(tl2,"\n%s" %(ind))

def text2width(text,width=50,ind=""):
    tl,tl2=string.split(text,"\n"),[]
    for t in tl:
        w,ind1=width,ind
        for i in range(0,min(width-1,len(t))):
            if t[i] == " ":
                w,ind1=w-1,ind1+" "
            else:
                break
        i=width
        s=t[:i]
        while i <= len(t):
            s=s+"\n%s%s" %(ind1,t[i:min(len(t),i+w)])
            i=i+w
        tl2.append(s)
    return string.join(tl2,"\n%s" %(ind))


## FUNCTIONS ON SEQUENCES (LISTS, TUPLES) AND ARRAYS ##

def formatlist(l,format,mv=None):
    if format == None: return l
    newl=[]
    tx=get_vartype(format)
    if tx != "list":
        if tx == "tuple": format=list(format)
        elif tx == "array": format=format.tolist()
        else: format=[format]
    for i in range(len(format),len(l)): format.append(format[-1])
    tx=get_vartype(mv)
    if tx != "list":
        if tx == "tuple": mv=list(mv)
        elif tx == "array": mv=mv.tolist()
        else: mv=[mv]
    for i in range(len(mv),len(l)): mv.append(mv[-1])
    for i in range(0,len(l)):
        if string.lower(format[i]) in ["eval","e","ev"]:
            try: newl.append(eval(l[i]))
            except: newl.append(l[i])
        elif string.lower(format[i]) in ["float","f","fl"]:
            try: newl.append(float(l[i]))
            except:
                try: newl.append(float(mv[i]))
                except: newl.append(mv[i])
        elif string.lower(format[i]) in ["integer","i","int"]:
            try: newl.append(int(l[i]))
            except:
                try: newl.append(int(mv[i]))
                except: newl.append(mv[i])
        elif string.lower(format[i]) in ["string","s","str"]:
            try: newl.append(str(l[i]))
            except:
                try: newl.append(str(mv[i]))
                except: newl.append(mv[i])
        elif string.find(format[i],"%") != -1:
                try: newl.append(format[i] %(l[i]))
                except:
                    try: newl.append(format[i] %(mv[i]))
                    except: newl.append(mv[i])
        else:
            newl.append(l[i])
    return newl

def l2int(l,arrtype=None):
    if arrtype != None:
        try: return array(formatlist(l,"i"),arrtype)
        except: return array(formatlist(l,"i"),int32)
    else: return formatlist(l,"i")
def l2float(l,arrtype=None):
    if arrtype != None:
        try: return array(formatlist(l,"f"),arrtype)
        except: return array(formatlist(l,"f"),float64)
    else: return formatlist(l,"f")
def l2eval(l,arrtype=None):
    if arrtype != None:
        try: return array(formatlist(l,"eval"),arrtype)
        except: return array(formatlist(l,"eval"))
    else: return formatlist(l,"eval")

def joinlist(l,sep="",format="%s"):
    l1=[]
    format=var2list(format)
    for i in range(len(format),len(l)): format.append(format[-1])
    for i in range(0,len(l)):
        try: l1.append(format[i] %(l[i]))
        except: l1.append(str(l[i]))
    return string.join(l1,sep)

def listsort(l,Nl=1,descend=False):
    islist,diml=False,1
    try: diml=int(bool(len(l.shape)-1))
    except:
        islist=True
        if l == []: return []
        elif type(l[0]) not in [list,tuple]: diml=0
    if islist: newlist=deepcopy(l)
    else: newlist=l.copy()
    if type(descend) not in [list,tuple]:
        try: descend=ravel(descend).tolist()
        except:
            try: descend=[int(descend)]
            except: descend=[False]
    if diml == 0:
        if islist: newlist.sort()
        else: newlist=sort(newlist)
        if descend[0]: newlist=newlist[::-1]
        return newlist
    if type(Nl) not in [list,tuple]:
        try: Nl=ravel(Nl).tolist()
        except:
            try: Nl=[int(Nl)]
            except: Nl=range(1,len(newlist[0])+1)
    for i in range(0,len(Nl)):
        if Nl[i] < 0: Nl[i]=len(newlist[0])+Nl[i]+1
    for i in range(len(descend),len(Nl)): descend.append(descend[i-1])
    if not islist: newlist=newlist.tolist()
    for i in range(0,len(Nl))[::-1]:
        n=Nl[i]
        if descend[i]:
            def sortcmp(a,b):
                if n <= 0: return cmp(b[n],a[n])
                else: return cmp(b[n-1],a[n-1])
        else:
            def sortcmp(a,b):
                if n <= 0: return cmp(a[n],b[n])
                else: return cmp(a[n-1],b[n-1])
        newlist.sort(sortcmp)
    if not islist: newlist=array(newlist)
    return newlist
def sortlist(l,Nl=1,descend=False): return listsort(l,Nl,descend)

def listargsort(l,Nl=1,descend=False):
    islist,diml=False,1
    try: diml=int(bool(len(l.shape)-1))
    except:
        islist=True
        if l == []: return []
        elif type(l[0]) not in [list,tuple]: diml=0
    if type(descend) not in [list,tuple]:
        try: descend=ravel(descend).tolist()
        except:
            try: descend=[int(descend)]
            except: descend=[False]
    if diml == 0:
        if islist: return sublist(listsort(sublist([l,range(0,len(l))]),1,descend),2)
        else:
            if descend[0]: return argsort(l)[::-1]
            else: return argsort(l)
    if type(Nl) not in [list,tuple]:
        try: Nl=ravel(Nl).tolist()
        except:
            try: Nl=[int(Nl)]
            except: Nl=range(1,len(l[0])+1)
    for i in range(0,len(Nl)):
        if Nl[i] < 0: Nl[i]=len(l[0])+Nl[i]+1
    if not islist: newlist=l.tolist()
    else: newlist=deepcopy(l)
    newlist=sublist(sublist(newlist)+[range(0,len(newlist))])
    newlist=sublist(listsort(newlist,Nl,descend),len(newlist[0]))
    if not islist: newlist=array(newlist)
    return newlist
def argsortlist(l,Nl=1,descend=False): return listargsort(l,Nl,descend)

def replacelist(l,l1,l2=None):
    if l2 == None: l2=[]
    for n in range(len(l2),len(l1)): l2.append("")
    lnew=deepcopy(l)
    for i in range(0,len(lnew)):
        for n in range(0,len(l1)):
            if lnew[i] == l1[n]: lnew[i]=l2[n]
    return lnew

def walklist(l,func_on_sub=None,func_on_output=None,func_on_seq=None,flatoutput=True):
    l0=[l]
    i,imax,output=[],[],deepcopy(l0)[0]
    if type(l) not in [type(None),complex,str,bool,int,long,float,string_,bool_,uint8,uint16,uint32,uint64,int8,int16,int32,int64,float16,float32,float64]:
        if len(l) != 0:
            output=[]
            while True:
                if type(l0[-1]) not in [type(None),complex,str,bool,int,long,float,string_,bool_,uint8,uint16,uint32,uint64,int8,int16,int32,int64,float16,float32,float64] and len(l0[-1]) > 0:
                    i.append(0); imax.append(len(l0[-1])-1); l0.append(l0[-1][0])
                else:
                    while True:
                        if type(l0[-1]) in [type(None),complex,str,bool,int,long,float,string_,bool_,uint8,uint16,uint32,uint64,int8,int16,int32,int64,float16,float32,float64]:
                            if func_on_sub != None:
                                sub=l0[-1]
                                exec("l0[-1]=%s" %(func_on_sub))
                            if flatoutput: output.append(l0[-1])
                        elif len(l0[-1]) == 0:
                            if func_on_seq != None:
                                try:
                                    seq=l0[-1]
                                    exec("l0[-1]=%s" %(func_on_seq))
                                except: pass
                            if flatoutput: output.append(l0[-1])
                        if func_on_seq == "tuple(seq)": l0[-2]=list(l0[-2])
                        try: l0[-2][i[-1]]=l0[-1]
                        except: pass
                        if func_on_seq == "tuple(seq)": l0[-2]=tuple(l0[-2])
                        elif func_on_seq != None:
                            seq=l0[-2]
                            exec("l0[-2]=%s" %(func_on_seq))
                        l0=l0[:-1]
                        if i[-1] != imax[-1]:
                            i[-1]=i[-1]+1
                            l0.append(l0[-1][i[-1]])
                            break
                        else:
                            i,imax=i[:-1],imax[:-1]
                            if len(i) == 0: break
                if len(i) == 0: break
    l0=l0[0]
    if flatoutput: l0=output
    if func_on_seq != None:
        seq=l0
        exec("l0=%s" %(func_on_seq))
    if func_on_output != None:
        output=l0
        exec("l0=%s" %(func_on_output))
    return l0

def listorder(l,order):
    newl=[]
    for n in order:
        if n < len(l) and n >= -len(l): newl.append(l[n])
    return newl
def orderlist(l,order): return listorder(l,n)

def add2lists(addlist,lists):
    for i in range(0,len(addlist)-len(lists)): lists.append([])
    for i in range(0,len(addlist)): lists[i].append(addlist[i])
    return lists

def fnc_on_list(l,fnc_str):
    # fnc_str: e.g. 'string.lower(subsub)'
    l0=[]
    for x in l:
        try:
            exec("x0=%s" %(string.replace(fnc_str,"subsub","x")))
            l0.append(x0)
        except: l0.append(x)
    return l0

def findindex(x,l,exact=None):
    if type(l) is str:
        parheader=string.split(l)
    if exact == None:
        x,newlist=string.lower(str(x)),[]
        for i in l:
            newlist.append(string.lower(str(i)))
    else:
        newlist=l[:]
    try:
        index=newlist.index(x)
    except:
        index=None
    return index

# Sorts an array according to the order in the array 'sortarr' and along a specified axis
#   arr = array to be sorted
#   sortarr = array giving the sorting order along the specified axis (same shape as arr)
#   axis = axis along which to sort
def sortarray(arr,sortarr,axis):
    arr,sortarr=swapaxes(arr,0,axis),swapaxes(sortarr,0,axis)
    ash=arr.shape; ind=indices(ash)
    for i in range(1,len(ash)):
        sortarr=sortarr*ash[i]+ind[i]
    return swapaxes(reshape(ravel(arr)[ravel(sortarr)],ash),0,axis)

def compressarrays(arrlist,nodata=-9999):
    islist=1
    if type(arrlist) not in [list,tuple]:
        arrlist=[arrlist]; islist=0
    comparr=where(arrlist[0] == nodata,0,1)
    arrlist0=[]
    for arr in arrlist:
        arrlist0.append(compress(comparr,arr,0))
    if not islist:
        arrlist0=arrlist0[0]
    return arrlist0

def uniquenumbers(inputarray):
    inputarray=sort(ravel(inputarray))
    return compress(concatenate([where(inputarray[:-1]-inputarray[1:] == 0,0,1),[1]]),inputarray,0)
def uniquevals(inputlist):
    try: return uniquenumbers(array(inputlist))
    except:
        un=[]
        for v in inputlist:
            if v not in un: un.append(v)
            un.sort()
        return un


## TABLE FUNCTIONS ##

def transposetable(l):
    l2=[]
    for r in range(0,len(l[0])):
        rec=[]
        for c in range(0,len(l)):
            rec.append(l[c][r])
        l2.append(rec)
    return l2

def layouttable(l,headrows=0,cformats=["%s"],calign=["l"],div=" ",recdiv=None):
    headline=False
    if headrows < 0:
        headline=True
    headrows=abs(headrows)
    cformats=cformats + max(0,len(l[0])-len(cformats))*[cformats[-1]]
    calign=calign + max(0,len(l[0])-len(calign))*[calign[-1]]
    l2,l3,cwidth=[],[],len(l[0])*[0]
    for c in range(0,len(calign)):
        if calign[c] in ["d","D"]:
            cwidth[c]=[0,0,0]
    for r in range(0,len(l)):
        rec=[]
        for c in range(0,len(l[0])):
            if r < headrows:
                s="%s" %(l[r][c])
                if calign[c] in ["d","D"]:
                    if len(s) > cwidth[c][2]:
                        cwidth[c][2]=len(s)
                else:
                    if len(s) > cwidth[c]:
                        cwidth[c]=len(s)
            else:
                s="%s" %(l[r][c])
                if string.find(cformats[c],"s") == -1:
                    try:
                        s=cformats[c] %(float(l[r][c]))
                    except:
                        try:
                            s=cformats[c] %(l[r][c])
                        except:
                            pass
                if calign[c] in ["d","D"]:
                    sd=string.split(s,"."); sd=sd+[""]
                    if len(sd[0]) > cwidth[c][0]:
                        cwidth[c][0]=len(sd[0])
                    if len(sd[1]) > cwidth[c][1]:
                        cwidth[c][1]=len(sd[1])
                elif len(s) > cwidth[c]:
                    cwidth[c]=len(s)
            rec.append(s)
        l2.append(rec)
    for c in range(0,len(calign)):
        if calign[c] in ["d","D"]:
            w1,w2,w3=cwidth[c]
            if w1+w2+1 < w3:
                w1=w1+(w3-w1-w2-1)/2; w2=w3-w1-1
            elif w1+w2+1 > w3:
                w3=w1+w2+1
            cwidth[c]=[w1,w2,w3]
    headlinerec=[]
    for r in range(0,len(l)):
        rec=[]
        for c in range(0,len(l[0])):
            s=l2[r][c]
            if s == "":
                d1,d2=cwidth[c],0; t1,t2,t3="","",""
                if calign[c] in ["d","D"]:
                    d1=cwidth[c][2]
            elif calign[c] in ["r","R"]:
                d1,d2=cwidth[c]-len(s),0; t1,t2,t3=s,"",""
            elif calign[c] in ["c","C"]:
                d=cwidth[c]-len(s); d1=d/2; d2=d-d1; t1,t2,t3=s,"",""
            elif calign[c] in ["d","D"]:
                if r < headrows:
                    d=cwidth[c][2]-len(s); d1=d/2; d2=d-d1; t1,t2,t3=s,"",""
                else:
                    sd=string.split(s,"."); sd=sd+[""]; d1,d2=cwidth[c][0]-len(sd[0]),cwidth[c][1]-len(sd[1]); t1,t2,t3=sd[0],".",sd[1]
            else:
                d1,d2=0,cwidth[c]-len(s); t1,t2,t3=s,"",""
            rec.append(d1*" " + t1 + t2 + t3 + d2*" ")
            if r == headrows and headline:
                d=cwidth[c]
                if calign[c] in ["d","D"]:
                    d=cwidth[c][2]
                headlinerec.append(d*"-")
        l3.append(string.join(rec,div))
    if headline:
        l3[headrows:headrows]=[string.join(headlinerec,div)]
    if recdiv != None:
        l3=string.join(l3,recdiv)
    return l3

def file2reclist(infile,splitl=[","],whitespace=True,format="%s"):
    l=[]
    if os.path.isfile(infile):
        inf=open(infile,"r"); data=inf.readlines(); inf.close()
        for line in data:
            #if line[-1] == "\n": line0=line[:-1]
            #else: line0=line
            line0=line
            if len(line0) > 0:
                if line0[-1] == "\n": line0=line0[:-1]
            if type(splitl) not in [list,tuple]: splitl=[]
            if len(splitl) == 0 and not whitespace:
                try: l.append(format %(line0))
                except: l.append(line0)
            else:
                rec=splitmultiple(line0,splitl,whitespace)
                if format in [None,"%s",string_,bool_,uint8,uint16,uint32,uint64,int8,int16,int32,int64,float16,float32,float64]: l.append(rec)
                else: l.append(formatlist(rec,format,rec))
        if format in [string_,bool_,uint8,uint16,uint32,uint64,int8,int16,int32,int64,float16,float32,float64]:
            l=array(l,format)
    return l

def reclist2file(reclist,outfile,div=",",recdiv="\n",format="%s"):
    outf=open(outfile,"w")
    for rec in reclist:
        outf.write(joinlist(rec,div,format)+recdiv)
    outf.close()

def join_flds(l_arr,joinstring="_",formats=["%s"]):
    for i in range(len(formats),len(l_arr)): formats.append("%s")
    l=[]
    for i in range(0,len(l_arr[0])):
        s=""
        for j in range(0,len(l_arr)):
            s+="%s%s" %(joinstring,formats[j] %(l_arr[j][i]))
        l.append(s[len(joinstring):])
    return l


def in2d(arrs_1D,arr_2D,tol=1e-7):
    if arr_2D.dtype.name[:4] == "void":
        dim=2
        if type(arrs_1D) in [list,tuple]:
            arrs_1D0=zeros((len(arrs_1D)),dtype=arrs_1D[0].dtype)
            arrs_1D0[:]=arrs_1D
            arrs_1D=arrs_1D0.copy()
            del arrs_1D0
        if len(arrs_1D.shape) == 0: dim,arrs_1D=1,reshape(arrs_1D,(1,))
        ind=[None]*len(arrs_1D)
        flds1,dt1=arrs_1D[0].dtype.names,[]
        for f in flds1: dt1.append(arrs_1D[0][f].dtype.name)
        flds2,dt2=arr_2D.dtype.names,[]
        for f in flds2: dt2.append(arr_2D[f].dtype.name)
        if len(dt1) == len(dt2):
            valid=True
            for i in range(0,len(dt1)):
                if dt1[i][:3] != dt2[i][:3]:
                    valid=False; break
            if valid:
                for r in range(0,len(arrs_1D)):
                    arr=ones((len(arr_2D)),dtype=bool)
                    for i in range(0,len(dt1)):
                        if dt1[i][:3] == "flo":
                            arr*=array(where(abs(arr_2D[flds2[i]]-arrs_1D[flds1[i]][r]) <= tol,1,0),bool)
                        else:
                            arr*=in1d(arr_2D[flds2[i]],arrs_1D[flds1[i]][r])
                    ind[r]=compress(arr,arange(0,len(arr_2D)))
        if dim == 1: return ind[0]
        else: return ind
    else:
        dim=2
        if type(arrs_1D) in [list,tuple]: arrs_1D=array(arrs_1D)
        if arrs_1D.ndim == 1: dim,arrs_1D=1,reshape(arrs_1D,(1,len(arrs_1D)))
        ind=[None]*len(arrs_1D)
        if len(arrs_1D[0]) == len(arr_2D[0]):
            for r in range(0,len(arrs_1D)):
                arr=array(where((abs(arr_2D-arrs_1D[r])).max(1) <= tol,1,0),bool)
                ind[r]=compress(arr,arange(0,len(arr_2D)))
        if dim == 1: return ind[0]
        else: return ind

def sublist(l,Nl="all"):
    islist,diml=False,1
    try: diml=int(bool(len(l.shape)-1))
    except:
        islist=True
        if l == []: return []
        elif type(l[0]) not in [list,tuple]: diml=0
    if diml == 0: l=[l]
    if not islist: l=array(l)
    dimNl=1
    if type(Nl) in [int,long,uint8,uint16,uint32,uint64,int8,int16,int32,int64]:
        dimNl=0; Nl=[Nl]
    elif type(Nl) == str:
        Nl=range(1,len(l[0])+1)
    if type(Nl) not in [list,tuple]:
        try: Nl=ravel(Nl).tolist()
        except:
            try: Nl=[int(Nl)]
            except: Nl=range(1,len(l[0])+1)
    for i in range(0,len(Nl)):
        if Nl[i] < 0: Nl[i]=len(l[0])+Nl[i]+1
    if not islist:
        Nl=(array(Nl)-1).tolist()
        newlist=swapaxes(take(l,Nl,1),0,1)
        if diml == 0: newlist=newlist[:,0]
    else:
        newlist=[]
        for i in Nl:
            newlist0=[]
            for j in l:
                try: newlist0.append(j[i-1])
                except: newlist0.append(None)
            if diml == 0: newlist.append(newlist0[0])
            else: newlist.append(newlist0)
    if len(newlist) == 1 and dimNl == 0: newlist=newlist[0]
    return newlist


def read_inpfile(inpfile,str_comment=["#","!"],str_delim=[",",";"],whitespace_delim=True,autostrip=False,keep_together=['"'],str_var=["{","}"]):
    inf=open(inpfile,"r"); s=inf.read(); inf.close()
    if type(str_comment) == str:
        str_comment=[str_comment]
    for i in range(1,len(str_comment)):
        s=s.replace(str_comment[i],str_comment[0])
    str_comment=str_comment[0]
    lines=[line.strip() for line in s.split("\n")]

    inpdata,nosplit=[],False
    for line in lines:
        if line != "":
            if string.lower(replacemultiple(line,[" ","_"],["",""])[1:10]) == "startloop":
                l=[[],[]]
                for s1,s2 in [string.split(s,",",1) for s in string.split(string.split(line,",",1)[1],"|")]:
                    l[0]+=[string.strip(s1)]; l[1]+=[string.strip(s2)]
                inpdata+=[["{startloop}"]+l]
            elif string.lower(replacemultiple(line,[" ","_"],["",""])[1:8]) == "endloop":
                inpdata+=[["{endloop}"]]
            else:
                if type(str_delim) == str: str_delim=[str_delim]
                if type(str_delim) not in [list,tuple]: str_delim=[]
                rec=splitmultiple2(line,str_delim,whitespace_delim,autostrip,keep_together)
                if type(rec) not in [list,tuple]:
                    nosplit=True
                    rec=[rec]
                inpdata+=[rec]
    i=0
    while True:
        if i >= len(inpdata): break
        if inpdata[i][0] == "{startloop}":
            i1=i; l_t1=inpdata[i][1]; l_l1=inpdata[i][2]
        if inpdata[i][0] == "{endloop}":
            i2=i
            for j in range(0,len(l_t1)):
                #if l_l1[j][0] in ["[","("] and l_l1[j][-1] in ["]",")"] and string.find(l_l1[j],",") != -1: l_l1[j]=string.split(l_l1[j][1:-1],",")
                if l_l1[j][0] in ["[","("] and l_l1[j][-1] in ["]",")"]: l_l1[j]=string.split(l_l1[j][1:-1],",")
                else:
                    try: l_l1[j]=eval(l_l1[j])
                    except: l_l1[j]=[l_t1[j]]
                if j > 0:
                    for n in range(len(l_l1[j]),len(l_l1[0])): l_l1[j]+=[l_l1[j][-1]]
            inpdata2=[]
            for n in range(0,len(l_l1[0])):
                for j in range(i1+1,i2):
                    inpdata2+=[deepcopy(inpdata[j])]
                    for k in range(0,len(inpdata2[-1])):
                        for m in range(0,len(l_t1)):
                            inpdata2[-1][k]=string.replace(inpdata2[-1][k],l_t1[m],str(l_l1[m][n]))
            inpdata=inpdata[:i1]+inpdata2+inpdata[i2+1:]
            i=-1
        i+=1
    if str_var not in [[],None,False]:
        if type(str_var) == str: str_var=[str_var]
        if type(str_var) in [list,tuple]:
            str_var=list(str_var)[:2]
            if len(str_var) == 1: str_var=[str_var[0],str_var[0]]
            l_vars,inpdata1=[[],[]],[]
            for rec in inpdata:
                if len(rec[0]) > 0:
                    if rec[0][0] == str_var[0] and string.find(rec[0],str_var[1]) != -1 and string.find(rec[0],"=") != -1:
                        var_name,var_value=string.split(rec[0],"=")
                        l_vars[0]+=[string.strip(var_name)]
                        if autostrip: var_value=string.strip(var_value)
                        for s in str_var: var_value=string.replace(var_value,s,"")
                        l_vars[1]+=[var_value]
                    else:
                        inpdata1+=[rec]
                else:
                    inpdata1+=[rec]
            if len(l_vars[0]) > 0:
                for i in range(0,len(inpdata1)):
                    for j in range(0,len(inpdata1[i])):
                        for k in range(0,len(l_vars[0])):
                            inpdata1[i][j]=string.replace(inpdata1[i][j],l_vars[0][k],l_vars[1][k])
                inpdata=deepcopy(inpdata1)
    inpdata1=[]

    for rec in inpdata:
        line=string.join(rec,"__QqQqQqQq__").split(str_comment,1)[0].strip()
        if line[-len("__QqQqQqQq__"):] == "__QqQqQqQq__":
            line=line[:-len("__QqQqQqQq__")]
        if len(line) > 0:
            rec=line.split("__QqQqQqQq__")
            if autostrip:
                rec=[v.strip() for v in rec]
            inpdata1+=[rec]
    if nosplit:
        for i in range(0,len(inpdata1)):
            inpdata1[i]=inpdata1[i][0]
    return inpdata1

def writelogf(logf,s):
    if logf != None:
        logf.write(s)
    print "\b%s" %(s),

def aggregate_reduce(arr,agg_arr_1D,func="add",axis=-2,nodata=-9999):
    func=string.lower(func)
    ii=sort(agg_arr_1D); ii=insert(ii[1:]-ii[:-1],0,1); ii=compress(ii != 0,arange(0,len(ii)))
    if func in ["n","num","number","mean","avg","average"]:
        arr0=add.reduceat(ones(arr.shape),ii,axis)
        arr0=array(arr0,min_scalar_type(int(arr0.max())))
        if func in ["mean","avg","average"]:
            arr=array(arr,float64)
            arr0=add.reduceat(take(arr,argsort(agg_arr_1D),axis),ii,axis)/arr0
    else:
        func=lookup(func,[["sum","add"],["min","minimum"],["max","maximum"]],func)
        exec("arr0=%s.reduceat(take(arr,argsort(agg_arr_1D),%d),ii,%d)" %(func,axis,axis))
    return arr0,agg_arr_1D[ii]

def aggregate(arr,agg_arr_1D,func="sum",axis=-2,nodata=-9999):
    func=string.lower(func)
    lut_func=[\
        ["add","sum"],["avg","mean"],["average","mean"],["stdev","std"],["variance","var"],["hmean","harm_mean"],["harm","harm_mean"],["harmonic","harm_mean"],["harmonic_mean","harm_mean"],\
        ["min","amin"],["minimum","amin"],["max","amax"],["maximum","amax"],["num","n"],["number","n"],\
        ]
    func=lookup(func,lut_func,func)
    p,ot=None,False
    if func == "n":
        outtype,ot=min_scalar_type(arr.shape[axis]),True
        arr=ones(arr.shape); func="sum"
    elif func == "sum":
        outtype=arr.dtype
    else:
        outtype=float64
        if func[0] == "p":
            for x in ["p","perc","percentile"]:
                try:
                    p=int(func[len(x):])
                    if p<0 or p>100: p=None
                    else: break
                except: pass
    arr=swapaxes(arr,0,axis)
    un=unique(agg_arr_1D)
    arr0=zeros((len(un),)+arr.shape[1:],outtype)
    if p != None:
        for i in range(0,len(un)):
            exec("arr0[i]=percentile(compress(agg_arr_1D == un[i],arr,0),%s,0)" %(p))
    elif func == "harm_mean":
        for i in range(0,len(un)):
            exec("arr0[i]=harm_mean(compress(agg_arr_1D == un[i],arr,0),0,nodata)")
    else:
        for i in range(0,len(un)):
            exec("arr0[i]=%s(compress(agg_arr_1D == un[i],arr,0),0)" %(func))
    arr0=swapaxes(arr0,0,axis)
    if ot:
        arr0=array(arr0,min_scalar_type(arr0.max()))
    return arr0,un

def listtree(root,topdown=True):
    if root[-1] == ":": root=root+"/"
    root=os.path.abspath(root)
    root_base=os.path.basename(root)
    fl,dl=[],[[root,root_base,"",root_base]]
    for dirroot,dirs,files in os.walk(root,topdown):
        for f in files:
            f0=winpath(f,0,2,dirroot)
            f1=winpath(f0,0,1,root)
            fl.append([f0,"%s\\%s" %(root_base,f1),f1,f])
        for d in dirs:
            d0=winpath(d,0,2,dirroot)
            d1=winpath(d0,0,1,root)
            dl.append([d0,"%s\\%s" %(root_base,d1),d1,d])
    return fl,dl

def get_filelist(l_sel,dir_in=None,case_sensitive=False,all_depth=False):
    fl,fl2=[],[]
    dir_old=os.getcwd()
    if dir_in == None: dir_in=os.getcwd()
    if dir_in[-1] == "\\": dir_in=dir_in[:-1]
    dir_in=os.path.normpath(dir_in)
    if os.path.isdir(dir_in):
        os.chdir("%s\\" %(dir_in))
        if type(l_sel) == type(None):
            l_sel=[[""]]
        if type(l_sel) not in [list,tuple]:
            l_sel=[[l_sel]]
        for sel in l_sel:
            if type(sel) not in [list,tuple]:
                sel=[sel]
            fl1=[]
            for i in range(0,1):
                if all_depth:
                    fl2=string.split(string.strip(os.popen('dir /B /S /A-D *%s*' %(sel[i])).read()),"\n")
                else:
                    fl2=["%s\\%s" %(dir_in,f) for f in string.split(string.strip(os.popen('dir /B /A-D *%s*' %(sel[i])).read()),"\n")]
                if fl2[-1] in ["","%s\\" %(dir_in)]: fl2=fl2[:-1]
                if case_sensitive:
                    fl0=[]
                    for f in fl2:
                        if string.find(os.path.basename(f),sel[i]) != -1:
                            fl0+=[f]
                    fl2=deepcopy(fl0)
                fl1+=fl2
            for i in range(1,len(sel)):
                if all_depth:
                    fl2=string.split(string.strip(os.popen('dir /B /S /A-D *%s*' %(sel[i])).read()),"\n")
                else:
                    fl2=["%s\\%s" %(dir_in,f) for f in string.split(string.strip(os.popen('dir /B /A-D *%s*' %(sel[i])).read()),"\n")]
                if fl2[-1] == "": fl2=fl2[:-1]
                if case_sensitive:
                    fl0=[]
                    for f in fl2:
                        if string.find(os.path.basename(f),sel[i]) != -1:
                            fl0+=[f]
                    fl2=deepcopy(fl0)
                fl1=np.compress(np.in1d(fl1,fl2),fl1).tolist()
            fl+=fl1
        fl2=[string.replace(f,os.getcwd(),".") for f in fl]
        os.chdir(dir_old)
    return fl,fl2

def get_dirlist(l_sel,dir_in=None,case_sensitive=False,all_depth=False):
    fl,fl2=[],[]
    dir_old=os.getcwd()
    if dir_in == None: dir_in=os.getcwd()
    if dir_in[-1] == "\\": dir_in=dir_in[:-1]
    dir_in=os.path.normpath(dir_in)
    if os.path.isdir(dir_in):
        os.chdir("%s\\" %(dir_in))
        if type(l_sel) == type(None):
            l_sel=[[""]]
        if type(l_sel) not in [list,tuple]:
            l_sel=[[l_sel]]
        for sel in l_sel:
            if type(sel) not in [list,tuple]:
                sel=[sel]
            fl1=[]
            for i in range(0,1):
                if all_depth:
                    fl2=string.split(string.strip(os.popen('dir /B /S /AD *%s*' %(sel[i])).read()),"\n")
                else:
                    fl2=["%s\\%s" %(dir_in,f) for f in string.split(string.strip(os.popen('dir /B /AD *%s*' %(sel[i])).read()),"\n")]
                if fl2[-1] in ["","%s\\" %(dir_in)]: fl2=fl2[:-1]
                if case_sensitive:
                    fl0=[]
                    for f in fl2:
                        if string.find(os.path.basename(f),sel[i]) != -1:
                            fl0+=[f]
                    fl2=deepcopy(fl0)
                fl1+=fl2
            for i in range(1,len(sel)):
                if all_depth:
                    fl2=string.split(string.strip(os.popen('dir /B /S /AD *%s*' %(sel[i])).read()),"\n")
                else:
                    fl2=["%s\\%s" %(dir_in,f) for f in string.split(string.strip(os.popen('dir /B /AD *%s*' %(sel[i])).read()),"\n")]
                if fl2[-1] == "": fl2=fl2[:-1]
                if case_sensitive:
                    fl0=[]
                    for f in fl2:
                        if string.find(os.path.basename(f),sel[i]) != -1:
                            fl0+=[f]
                    fl2=deepcopy(fl0)
                fl1=np.compress(np.in1d(fl1,fl2),fl1).tolist()
            fl+=fl1
        fl2=[string.replace(f,os.getcwd(),".") for f in fl]
        os.chdir(dir_old)
    return fl,fl2

def zip_tree(root,f_zip,append=True,include_root_name=True):
    if append and zipfile.is_zipfile(f_zip):
        outf=zipfile.ZipFile(f_zip,"a",zipfile.ZIP_DEFLATED)
        l=[]
        for inf in outf.infolist():
            if inf.CRC != 0: l+=[string.lower(os.path.normpath(inf.filename))]
    else:
        outf=zipfile.ZipFile(newfile(f_zip),"w",zipfile.ZIP_DEFLATED)
        l=[]

    fl1,fl2=get_filelist(None,dir_in=root,case_sensitive=False,all_depth=True)
    dl1,dl2=get_dirlist(None,dir_in=root,case_sensitive=False,all_depth=True)

    if type(include_root_name) == str:
        d_base=include_root_name
        fl2=[string.replace("%s\\%s" %(d_base,f),"\\.\\","\\") for f in fl2]
        dl2=[string.replace("%s\\%s" %(d_base,d),"\\.\\","\\") for d in dl2]

    elif include_root_name:
        d_base=os.path.basename(root)
        fl2=[string.replace("%s\\%s" %(d_base,f),"\\.\\","\\") for f in fl2]
        dl2=[string.replace("%s\\%s" %(d_base,d),"\\.\\","\\") for d in dl2]

    for i in range(0,len(dl1)):
        outf.write(dl1[i],dl2[i])
    for i in range(0,len(fl1)):
        if fl2[i] not in l:
            outf.write(fl1[i],fl2[i])

    outf.close()

def extract_from_zipfile(zipFile,targetDir=None,checkList=[],extractAll=False):
    """Function to extract files from a zipfile.

    Parameters
    ----------
    zipFile : str
        File name of the zipfile.

    targetDir : str or None (optional)
        Directory name to which the files/directories should be extracted.

        If *targetDir* is None then the directory name of the zipfile is used.

    checkList : list or str (optional)
        List containing the files/directories which should be checked for existence. Existence means that the file/directory is exactly equal (CRC check).

        If *checkList* is an empty list then all files/directories are checked.

        *checkList* could be the string 'no_check' which has a special meaning in combination with *extractAll*.
        If *extractAll* is True then all files/directories are extracted without checking the existence of any file/directory.
        If *extractAll* is False then no files/directories are extracted.

    extractAll : bool (optional)
        True = all files/directories are extracted if any of the checked files/directories does not exist.

        False = only files/directories which do not exist are extracted.

    Returns
    -------
    l_unzipped : list
        The extracted files and/or directories.

    l_total : list
        All files, including the files which were not extracted because they already exist (CRC checked).
    """
    if targetDir == None:
        targetDir=os.path.dirname(zipFile)
    targetDir=string.replace(os.path.abspath(targetDir),"\\","/")
    if targetDir[-1] == "/":
        targetDir=targetDir[:-1]

    inf=zipfile.ZipFile(zipFile,"r")

    if checkList == "no_check" and extractAll:
        inf.extractall(targetDir)
        l_unzipped=["%s/%s" %(targetDir,f) for f in inf.namelist()]
        inf.close()
        return l_unzipped
    elif checkList == "no_check":
        inf.close()
        return []

    nameList=[string.lower(f) for f in inf.namelist()]

    if len(checkList) == 0:
        i_check=range(0,len(nameList))
    else:
        checkList=[string.replace(string.lower(f),"\\","/") for f in checkList]
        i_check=[]
        for f in checkList:
            if f in nameList:
                i_check+=[nameList.index(f)]

    l_unzipped=[]
    l_total=[]

    for i in i_check:

        x=inf.infolist()[i]

        f2="%s/%s" %(targetDir,x.filename)
        equal=False

        ## File or directory?
        if x.file_size > 0:

            ## File exists?
            if os.path.isfile(f2):

                ## File size?
                s1,s2=x.file_size,os.path.getsize(f2)
                if s1 == s2:

                    ## CRC?
                    crc1,crc2=x.CRC  & 0xFFFFFFFF,zlib.crc32(open(f2,"rb").read()) & 0xFFFFFFFF
                    if crc1 == crc2:
                        equal=True
        else:

            ## Directory exists?
            if os.path.isdir(f2):
                equal=True

        ## Equal?
        if not equal:

            ## Unzip
            if extractAll:
                inf.extractall(targetDir)
                l_unzipped=["%s/%s" %(targetDir,f) for f in inf.namelist()]
                l_total=["%s/%s" %(targetDir,f) for f in inf.namelist()]
                break
            else:
                inf.extract(x.filename,targetDir)
                l_unzipped+=[f2]

        if f2 not in l_total:
            l_total+=[f2]

    inf.close()
    return l_unzipped,l_total

def add_to_zipfile(fileList,zipFile,relativeDir=None,archiveList=[],completeUpdate=False):
    """Function to add files from a zipfile. If a file already exists in the zipfile then the file is updated if the CRC-32 is different.

    Parameters
    ----------
    fileList : list
        List of file names to be zipped.

    zipFile : str
        File name of the zipfile. If the zipfile already exists then the files are appended or updated.

    relativeDir : str or None (optional)
        Directory name to be used as source directory to get the relative names of the files.

        If *relativeDir* is None then the directory name of the zipfile is used.

        This will be overruled by *archiveList* if this list is not empty.

    archiveList : list (optional)
        List containing the relative names of the files, i.e. the archive names. If *archiveList* is not empty it will overrule *relativeDir*.

    completeUpdate : bool (optional)
        True = complete update of the zipfile: existing files which are not in *fileList* are removed.

        False = not complete update: existing files which are not in *fileList* are not removed.

    Returns
    -------
    l_zipped : list
        The added files and/or directories.

    l_total : list
        All files, including the files which were not added because they already exist in the zipfile (CRC checked).
    """
    fileList=[os.path.abspath(f) for f in fileList]

    zipFile=os.path.abspath(zipFile)

    if len(archiveList) == 0:
        if relativeDir == None:
            relativeDir=os.path.dirname(zipFile)
        if os.path.isdir(relativeDir):
            archiveList=[os.path.relpath(f,relativeDir) for f in fileList]
        else:
            archiveList=fileList[:]

    archiveList=[string.replace(os.path.splitdrive(f)[1],"\\","/") for f in archiveList]
    for i in range(0,len(archiveList)):
        if archiveList[i][0] == "/":
            archiveList[i]=archiveList[i][1:]

    l_zipped=[]
    l_total=fileList[:]

    if os.path.isfile(zipFile):

        inf=zipfile.ZipFile(zipFile,"r",zipfile.ZIP_DEFLATED)
        len_comment=len(inf.comment)
        l_rec=[]
        for x in inf.infolist():
            l_rec+=[[[x.filename,x.CRC & 0xFFFFFFFF],[x.header_offset,30,len(x.filename),len(x.extra),x.compress_size],[0,46,len(x.filename),len(x.extra),len(x.comment)]]]
        inf.close()

        nameListLower=[string.lower(rec[0][0]) for rec in l_rec]
        archiveListLower=[string.lower(f) for f in archiveList]

        ii_append,ii_update,ii_keep=[],[],[]
        for i in range(0,len(archiveListLower)):
            if archiveListLower[i] in nameListLower:
                j=nameListLower.index(archiveListLower[i])
                crc1,crc2=l_rec[j][0][1],zlib.crc32(open(fileList[i],"rb").read()) & 0xFFFFFFFF
                if crc1 != crc2:
                    ii_append+=[i]
                    ii_update+=[j]
                else:
                    ii_keep+=[j]
            else:
                ii_append+=[i]

        if completeUpdate:
            for j in range(0,len(nameListLower)):
                if j not in ii_keep and j not in ii_update:
                    ii_update+=[j]
        if len(nameListLower) > 0:
            if min([i in ii_update for i in range(0,len(nameListLower))]):
                os.remove(zipFile)

    if not os.path.isfile(zipFile):

        outf=zipfile.ZipFile(zipFile,"w",zipfile.ZIP_DEFLATED)
        for i in range(0,len(fileList)):
            outf.write(fileList[i],archiveList[i])
        outf.close()
        l_zipped=fileList[:]

    else:

        if len(ii_update) != 0:
            n=0
            for i in range(0,len(l_rec)):
                n+=sum(l_rec[i][1][1:])
            for i in range(0,len(l_rec)):
                l_rec[i][2][0]=n
                n+=sum(l_rec[i][2][1:])

            outf=tempfile.NamedTemporaryFile(mode="wb",delete=False)
            zipFile2=outf.name

            inf=open(zipFile,"rb")

            mm=mmap.mmap(inf.fileno(),0,access=mmap.ACCESS_READ)
            n1,n2=0,0
            for i in range(0,len(l_rec)):
                if i not in ii_update:
                    mm.seek(l_rec[i][1][0])
                    n=sum(l_rec[i][1][1:])
                    outf.write(mm.read(n))
                    n1+=n
            for i in range(0,len(l_rec)):
                if i not in ii_update:
                    mm.seek(l_rec[i][2][0])
                    n=sum(l_rec[i][2][1:])
                    outf.write(mm.read(n))
                    n2+=n

            mm.seek(os.path.getsize(zipFile)-22-len_comment)
            outf.write(mm.read(8))
            outf.write(struct.pack("=2H2L",len(l_rec)-len(ii_update),len(l_rec)-len(ii_update),n2,n1))
            outf.write(mm.read(2+len_comment))

            mm.close()
            inf.close()
            outf.close()

            os.remove(zipFile)
            os.rename(zipFile2,zipFile)

        if len(ii_append) != 0:
            outf=zipfile.ZipFile(zipFile,"a",zipfile.ZIP_DEFLATED)
            for i in ii_append:
                outf.write(fileList[i],archiveList[i])
            outf.close()

            l_zipped=[fileList[i] for i in ii_append]

    return l_zipped,l_total

def get_task_pid(task=None):
    recs=[string.split(p,",") for p in string.split(string.replace(string.strip(os.popen('TASKLIST /FO CSV').read()),'"',""),"\n")[1:]]
    l_task=np.array([rec[0] for rec in recs])
    l_pid=np.array([int(rec[1]) for rec in recs],np.int32)
    if task != None:
        cp=(l_task == task)
        l_task=np.compress(cp,l_task)
        l_pid=np.compress(cp,l_pid)
    arr=np.zeros((len(l_task),),dtype=[("Image Name",l_task.dtype),("PID",l_pid.dtype)])
    arr["Image Name"]=l_task
    arr["PID"]=l_pid
    return arr

def get_dif_pid(arr_pid1,arr_pid2):
    dif1=np.compress(np.in1d(arr_pid1["PID"],arr_pid2["PID"]) == False,arr_pid1)
    dif2=np.compress(np.in1d(arr_pid2["PID"],arr_pid1["PID"]) == False,arr_pid2)
    return dif1,dif2

def start_cmd(f_exe,s_args=None,label=None,timeout_sec=0,minimized=True):
    if s_args == None:
        s_args=""
    else:
        s_args=" %s" %(string.strip(s_args))
    if label == None:
        label=f_exe
    else:
        label=string.strip(label)
    s_min=" /MIN"
    if not minimized:
        s_min=""

    pid1=get_task_pid(os.path.basename(f_exe))

    os.system('start "%s"%s %s%s' %(label,s_min,f_exe,s_args))
    t=time.time()

    pid2=get_task_pid(os.path.basename(f_exe))
    pid=get_dif_pid(pid1,pid2)[1]["PID"][0]

    if timeout_sec == 0:
        return pid
    else:
        while True:
            time.sleep(1)
            if pid not in get_task_pid(os.path.basename(f_exe))["PID"]:
                break
            if time.time()-t >= timeout_sec:
                end_process(pid)
                break
        return None

def end_process(pid):
    try: os.system('taskkill /f /t /pid %d' %(pid))
    except: pass

def cUnpickle(f):
    return cPickle.loads(open(f,"r").read())

def unpickle(f):
    return pickle.loads(open(f,"r").read())

def indices1d(arr1,arr2,missing=None):
    ## return index numbers for elements of arr1 in arr2
    arr1=np.array(arr1)
    cp=np.in1d(arr1,arr2)
    if missing != None:
        arr1[cp == False]=arr2[0]
    else:
        arr1=arr1[cp]
    v=np.searchsorted(np.sort(arr2),arr1)
    v=np.argsort(arr2)[v]
    if missing != None:
        v[cp == False]=missing
    return v
