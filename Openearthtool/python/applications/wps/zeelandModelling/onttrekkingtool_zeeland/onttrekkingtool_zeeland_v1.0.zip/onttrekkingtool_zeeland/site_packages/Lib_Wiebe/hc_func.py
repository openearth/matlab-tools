import sys, cPickle, os.path, os, string, zipfile, collections, subprocess, time, shutil
from copy import deepcopy
from raster_func import *
from table_func import table2arr, arr2table
from general_func import extract_from_zipfile, add_to_zipfile


def getPort(portDict,key,optional=False,asList=False,asSingle=False,singleFS=True):
    if key not in portDict.keys():
        if not optional:
            raise Exception, "Input port '%s' not specified" %(key)
        else:
            v=None
    else:
        v=portDict[key]
    try:
        v=cPickle.loads(v)
    except:
        pass
    mult=False
    if type(v) == dict:
        l_key=v.keys()
        l_val=v.values()
        if singleFS != False:
            if type(singleFS) == bool:
                ii=0
            else:
                try:
                    ii=l_key.index(singleFS)
                except:
                    try:
                        ii=int(singleFS)
                    except:
                        ii=0

            l_key=l_key[ii]
            l_val=l_val[ii]
        else:
            mult=True
    else:
        l_key=None
        l_val=v
    try:
        l_val=cPickle.loads(l_val)
    except:
        pass
    try:
        for i in range(0,len(l_val)):
            try:
                l_val[i]=cPickle.loads(l_val[i])
            except:
                pass
    except:
        pass
    if asList:
        if mult:
            for i in range(0,len(l_val)):
                if type(l_val[i]) == tuple:
                    l_val[i]=list(l_val[i])
                if type(l_val[i]) != list:
                    l_val[i]=[l_val[i]]
        else:
            if type(l_val) == tuple:
                l_val=list(l_val)
            if type(l_val) != list:
                l_val=[l_val]
    if asSingle:
        if mult:
            for i in range(0,len(l_val)):
                if type(l_val[i]) in [list,tuple]:
                    l_val[i]=l_val[i][0]
        else:
            if type(l_val) in [list,tuple]:
                l_val=l_val[0]

    return l_key,l_val

def picklePorts(portDict,if_needed=True):
    for key in portDict.keys():
        if if_needed:
            if type(portDict[key]) == dict:
                for key2 in portDict[key].keys():
                    if type(portDict[key][key2]) in [list,tuple]:
                        for i in range(0,len(portDict[key][key2])):
                            if type(portDict[key][key2][i]) not in [bool,int,long,float,complex,str,type(None)]:
                                portDict[key][key2][i]=cPickle.dumps(portDict[key][key2][i])
                    else:
                        if type(portDict[key][key2]) not in [bool,int,long,float,complex,str,type(None)]:
                            portDict[key][key2]=cPickle.dumps(portDict[key][key2])
            else:
                if type(portDict[key]) in [list,tuple]:
                    for i in range(0,len(portDict[key])):
                        if type(portDict[key][i]) not in [bool,int,long,float,complex,str,type(None)]:
                            portDict[key][i]=cPickle.dumps(portDict[key][i])
                else:
                    if type(portDict[key]) not in [bool,int,long,float,complex,str,type(None)]:
                        portDict[key]=cPickle.dumps(portDict[key])
        else:
            portDict[key]=cPickle.dumps(outputPorts[key])

def keys_values2dict(l_keys,l_values=None):
    if l_values == None:
        l_keys,l_values=l_keys
    d={}
    for i in range(0,len(l_keys)):
        d[l_keys[i]]=deepcopy(l_values[i])
    return d

def relpath2abspath(path,src_path):
    if path.strip() == "":
        path="."
    dir_old=os.getcwd()
    src_path=os.path.abspath(src_path)
    if not os.path.isdir(src_path):
        src_path=os.path.dirname(src_path)
    if os.path.isdir(src_path):
        os.chdir(src_path)
    for i in range(0,2):
        if path[0]=='\\':
            path=path[1:]
    path=os.path.abspath(path)
    os.chdir(dir_old)
    return path

def check_dir_zip(path,cwd,logf=None,alt_path=None,no_zip=False):
    """Function to check existence of directory or zipfile.

    Parameters
    ----------
    path : str
        Path name of directory or zipfile (relative or absolute).

    cwd : str
        Directory representing the 'current working directory' to be convert path name to absolute path name.

    logf : open file instance
        Log file to which the logging will be written. If None the logging is not written to file.

    alt_path : str
        Alternative path name if path does not exist.

    no_zip : bool
        True = path should be directory, no zipfile

        False = path may be directory or zipfile

    Returns
    -------
    path : str
        Checked absolute path name.
    """
    err=False
    if type(path) != str:
        path=alt_path
    if type(path) != str:
        err=True
    else:
        path=relpath2abspath(path,cwd)
        if no_zip:
            if not os.path.isdir(path):
                err=True
        else:
            if not os.path.isdir(path) and not zipfile.is_zipfile(path):
                err=True
    if err:
        if no_zip:
            err="no valid directory specified"
        else:
            err="no valid directory or zipfile specified"
        try: logf.write("\nERROR: %s\n" %(err))
        except: pass
        raise Exception, "  %s" %(err)
    else:
        return path

def check_file(path,cwd,logf=None,alt_path=None):
    """Function to check existence of file.

    Parameters
    ----------
    path : str
        Path name of file (relative or absolute).

    cwd : str
        Directory representing the 'current working directory' to be convert path name to absolute path name.

    logf : open file instance
        Log file to which the logging will be written. If None the logging is not written to file.

    alt_path : str
        Alternative path name if path does not exist.

    Returns
    -------
    path : str
        Checked absolute path name.
    """
    err=False
    if type(path) != str:
        path=alt_path
    if type(path) != str:
        err=True
    else:
        path=relpath2abspath(path,cwd)
        if not os.path.isfile(path):
                err=True
    if err:
        err="no valid file specified"
        try: logf.write("\nERROR: %s\n" %(err))
        except: pass
        raise Exception, "  %s" %(err)
    else:
        return path

def checkFileExistence(fileList,dirOrZip=None,ext=None,skipUnzip=False,logf=None,raiseError=False):
    """Function to check existence of file(s) in directory or zipfile and unzip if necessary.

    Parameters
    ----------
    fileList : str or list
        Filename or list of filenames (relative or absolute).

    dirOrZip : str
        Path name of directory or zipfile.

    ext : str
        File name extension. Will be added to file name if the file name has no extension yet.

    skipUnzip : bool
       True = skip unzipping of files if they already exist

       False = do not skip unzipping of files

    logf : open file instance
        Log file to which the logString will be written. If None the logString is not written to file.

    raiseError : bool
        True = raise error if one or more files not exist.

        False = do not raise error.

    Returns
    -------
    fileList : list
        File name list with absolute path names.

    fileListShort : list
        File name list with short (relative) path names.

    existList : list
        List with True of False if files exist or not.

    logString : str
        Log string to be printed or logged.
    """
    if type(fileList) == str:
        fileList=[fileList]
    fileList=[f for f in fileList]

    if type(ext) == str:
        ext=ext.strip()
        if ext[0] == ".":
            ext=ext[1:]
        for i in range(0,len(fileList)):
            if os.path.splitext(fileList[i])[1] == "":
                fileList[i]="%s.%s" %(fileList[i],ext)

    fileListShort=[os.path.basename(f) for f in fileList]

    if type(dirOrZip) == str:
        if zipfile.is_zipfile(dirOrZip):
            zipFile=dirOrZip
            dirOrZip=os.path.dirname(dirOrZip)

            if not skipUnzip:
                checkList=fileListShort[:]
            else:
                checkList=[]
                for f in fileListShort:
                    if not os.path.isfile("%s\\%s" %(dirOrZip,f)):
                        checkList+=[f]

            if len(checkList) > 0:
                extract_from_zipfile(zipFile,targetDir=None,checkList=checkList,extractAll=False)

    fileList=["%s\\%s" %(dirOrZip,f) for f in fileListShort]

    existList=[]
    for f in fileList:
        existList+=[os.path.isfile(f)]

    if False in existList:
        logString="Not all files exist:"
        for i in range(0,len(existList)):
            if not existList[i]:
                logString+="\n  %s" %(fileListShort[i])
        if raiseError:
            err="Error: not all files exist"
            try:
                logf.write("%s\n  %s\n" %(logString,err))
            except:
                pass
            print logString
            raise Exception, err

    else:
        logString="All files exist"

    try:
        logf.write("%s\n" %(logString))
    except:
        pass

    return fileList,fileListShort,existList,logString

def checkInput(inputValue,valueType=None,altValue=None,cwd=None,portDesc=None,portName=None,logf=None,printLog=True):
    """Function to check parameter value and convert to the specified type.

    Parameters
    ----------
    inputValue : any type
        Input parameter value.

    valueType : str
        Type of the parameter to which the value will be converted.

        Possible types: None (no conversion), 'str', 'bool', 'int', 'float', 'intOrFloat', 'file', 'dir', 'zip', 'dirOrZip', 'makedir', 'list,..,..'.

        'file', 'dir', 'zip', 'dirOrZip' = path reference (str) which will be checked for existence with the function 'check_file' or 'check_dir_zip'.

        'makedir' = path reference (str) which will be created if it doesn't exist.

        'list,3,float' = list with 3 values of type 'float'

        'list,-1,file' = list with values of type 'file'; number of values is ignored

    altValue : any type
        Alternative value in case the inputValue is not correct.

        None is ignored (no alternative value used), "None" is interpreted as None (None is used as alternative value).

    cwd : str
        Directory representing the 'current working directory' to convert path names to absolute path names.

    portDesc : str
        Description of the parameter (input port) to be used in the logString. If None the description is not used in the logString.

    portName : str
        Name of the input port to be used in the logString. If None the portName is not used in the logString.

    logf : open file instance
        Log file to which the logString will be written. If None the logString is not written to file.

    printLog : bool
        True = print logString to screen; logString is not returned.

        False = do not print logString; logString is returned.

    Returns
    -------
    inputValue : any type
        Checked and converted parameter value.

    logString : str
        Log string to be printed or logged. Only returned if printLog is False.
    """
    def convertValue(inputValue,valueType):

        try:

            if valueType == None:
                pass
            elif valueType == "str":
                if inputValue == None:
                    raise TypeError, "str(None) is invalid"
                inputValue="%s" %(inputValue)
            elif valueType == "bool":
                if inputValue == None:
                    raise TypeError, "bool(None) is invalid"
                inputValue=bool(inputValue)
            elif valueType == "int":
                inputValue=int(inputValue)
            elif valueType == "float":
                inputValue=float(inputValue)
            elif valueType == "intOrFloat":
                if type(inputValue) not in [int,float]:
                    if type(inputValue) == str:
                        if inputValue.find(".") != -1:
                            inputValue=float(inputValue)
                        else:
                            inputValue=int(inputValue)
                    else:
                        inputValue=float(inputValue)
                        if abs(inputValue-int(inputValue)) < 1e-7:
                            inputValue=int(inputValue)
            elif valueType == "file":
                if inputValue.lower().find(".zip\\") != -1:
                    zipFile,inputValue=inputValue.split(".zip\\",1)
                    zipFile="%s.zip" %(zipFile)
                    inputValue=relpath2abspath(inputValue,os.path.dirname(zipFile))
                    if not os.path.isfile(inputValue):
                        extract_from_zipfile(zipFile,targetDir=None,checkList=[inputValue],extractAll=False)
                inputValue=check_file(inputValue,cwd=cwd,logf=None,alt_path=altValue)
                valueString="%s" %(inputValue)
            elif valueType == "dir":
                inputValue=check_dir_zip(inputValue,cwd=cwd,logf=None,alt_path=altValue,no_zip=True)
                valueString="%s" %(inputValue)
            elif valueType == "zip":
                inputValue=check_file(inputValue,cwd=cwd,logf=None,alt_path=altValue)
                if not zipfile.is_zipfile(inputValue):
                    raise Exception, "no valid zipfile specified"
                valueString="%s" %(inputValue)
            elif valueType == "dirOrZip":
                inputValue=check_dir_zip(inputValue,cwd=cwd,logf=None,alt_path=altValue,no_zip=False)
                valueString="%s" %(inputValue)
            elif valueType == "makedir":
                inputValue=relpath2abspath(inputValue,src_path=cwd)
                makedir(inputValue)
                inputValue=check_dir_zip(inputValue,cwd=cwd,logf=None,alt_path=altValue,no_zip=True)
                valueString="%s" %(inputValue)
            elif valueType[:4] == "list":
                x,lenList,valueType=[v.strip() for v in valueType.split(",")][:3]
                lenList=int(lenList)
                if lenList < 0:
                    lenList=len(inputValue)
                if len(inputValue) < lenList:
                    raise Exception, "not enough values in list (%d < %d)" %(len(inputValue),lenList)
                inputValue=list(inputValue)[:lenList]
                for i in range(0,len(inputValue)):
                    inputValue[i]=convertValue(inputValue[i],valueType)

            return inputValue

        except Exception, err:

            raise Exception, err

    logString=""
    if portDesc != None:
        logString+="%s" %(portDesc)
    if portName != None:
        logString+=" (port %s)" %(portName)
    logString=logString.strip()
    if len(logString) > 0:
        logString+=":"

    if inputValue == None:
        inputValue=altValue
        if inputValue in ["None","NONE","none"]:
            inputValue=None

    try:

            inputValue=convertValue(inputValue,valueType)

    except Exception, err:

        if altValue != None:
            if altValue.lower() == "none":
                inputValue=None
            else:
                inputValue=altValue
        else:
            err="ERROR: %s" %(str(err).strip())
            logString+="\n  %s" %(inputValue)
            try:
                logf.write("%s\n  %s\n" %(logString,err))
            except:
                pass
            print logString
            raise Exception, err

    if type(inputValue) == list:
        valueString=string.join([str(v) for v in inputValue],", ")
    else:
        valueString="%s" %(inputValue)

    if len(logString) > 0:
        logString+="\n  %s" %(valueString)
    else:
        logString=valueString

    try:
        logf.write("%s\n" %(logString))
    except:
        pass

    if printLog:
        print logString
        return inputValue
    else:
        return inputValue,logString

def writelogf(logf,s):
    logf.write(s)
    print "\b%s" %(s),

def makedir(dir):
    if not os.path.isdir(dir):
        os.makedirs(dir)

def renameFile(fileList,fileListNew):
    if type(fileList) == str:
        fileList=[fileList]
    fileList=[f for f in fileList]
    if type(fileListNew) == str:
        fileListNew=[fileListNew]
    fileListNew=[f for f in fileListNew]

    for i in range(0,len(fileList)):
        if os.path.isfile(fileList[i]):
            if os.path.isfile(fileListNew[i]):
                os.remove(fileListNew[i])
            os.rename(fileList[i],fileListNew[i])

def copyFile(fileList,fileListNew):
    if type(fileList) == str:
        fileList=[fileList]
    fileList=[f for f in fileList]
    if type(fileListNew) == str:
        fileListNew=[fileListNew]
    fileListNew=[f for f in fileListNew]

    for i in range(0,len(fileList)):
        if os.path.isfile(fileList[i]):
            if os.path.isfile(fileListNew[i]):
                os.remove(fileListNew[i])
            makedir(os.path.dirname(fileListNew[i]))
            shutil.copy(fileList[i],fileListNew[i])

def shortFileName(fileList,level=0):
    dim=1
    if type(fileList) == str:
        fileList=[fileList]
        dim=0
    fileList=[f for f in fileList]
    for i in range(0,len(fileList)):
        rec=[os.path.basename(fileList[i])]
        d=os.path.dirname(fileList[i])
        for j in range(0,level):
            b=os.path.basename(d)
            if b == "":
                break
            rec+=[b]
            d=os.path.dirname(d)
        fileList[i]=string.join(rec[::-1],"\\")
    if dim == 0:
        return fileList[0]
    else:
        return fileList

def idf_put_nodata(f_idf,nodata):
    inf=open(f_idf,"r+b")
    mm=mmap.mmap(inf.fileno(),0,access=mmap.ACCESS_WRITE)
    mm.seek(9*4)
    mm.write(struct.pack("=f",nodata))
    mm.close()
    inf.close()

def idf_put_yllyur(f_idf,yll,yur):
    inf=open(f_idf,"r+b")
    mm=mmap.mmap(inf.fileno(),0,access=mmap.ACCESS_WRITE)
    mm.seek(5*4)
    mm.write(struct.pack("=ff",yll,yur))
    mm.close()
    inf.close()

def idf_put_minmax(f_idf,l_minmax):
    inf=open(f_idf,"r+b")
    mm=mmap.mmap(inf.fileno(),0,access=mmap.ACCESS_WRITE)
    mm.seek(7*4)
    mm.write(struct.pack("=ff",l_minmax[0],l_minmax[1]))
    mm.close()
    inf.close()

def idf_get_minmax(f_idf):
    inf=open(f_idf,"rb")
    mm=mmap.mmap(inf.fileno(),0,access=mmap.ACCESS_READ)
    mm.seek(7*4)
    minval,maxval=struct.unpack("=ff",mm.read(8))
    mm.close()
    inf.close()
    return minval,maxval

def idf_put_data(f_idf,data,rc,consecutive,nodata,l_minmax):
    rc_val2idf(rc,data,f_idf,consecutive=consecutive)
    if data.min() != nodata or data.max() != nodata:
        minval=np.array(ma.masked_values(data,nodata).min(),float32)
        if l_minmax[0] == nodata: l_minmax[0]=minval
        else: l_minmax[0]=min(l_minmax[0],minval)
        maxval=np.array(ma.masked_values(data,nodata).max(),float32)
        if l_minmax[1] == nodata: l_minmax[1]=maxval
        else: l_minmax[1]=max(l_minmax[1],maxval)
    idf_put_minmax(f_idf,l_minmax)
    return l_minmax

def call_system(*args):

    ## Argument list
    argList=[]
    for arg in args:
        if type(arg) in [list,tuple]:
            argList+=list(arg)
        else:
            argList+=[arg]

    ## Run subprocess
    subProc=subprocess.Popen(argList)
    returnMessage=subProc.communicate()[1]
    returnCode=subProc.returncode

    ## Raise exception if not run successfully
    if type(returnMessage) == str:
        if returnMessage[:9] == "Traceback":
            raise Exception, "Error running:\n  Args = %s\n  Return message =\n%s" %(args,returnCode,returnMessage.strip())
    if returnCode != 0:
        raise Exception, "Error running:\n  Args = %s\n  Return code = %s" %(args,returnCode)

def call_HC_script(f_script,exe_python=None,inputPorts=None,**kwargs):

    if os.path.splitext(f_script)[1].lower() in [".py",".pyw",".pyc"]:

        ## Python exe
        if exe_python == None:
            exe_python=sys.executable

        args=[exe_python,f_script]

    else:
        args=[f_script]

    ## Input ports
    if type(inputPorts) != dict:
        inputPorts={}

    ## Keyword arguments: add to input ports
    for key in kwargs:
        inputPorts[key]=kwargs[key]

    ## Run script as subprocess
    subProc=subprocess.Popen(args,stdin=subprocess.PIPE,stderr=subprocess.PIPE,universal_newlines=True)
    subProc.stdin.write(cPickle.dumps(inputPorts))
    subProc.stdin.close()
    returnMessage=subProc.communicate()[1]
    returnCode=subProc.returncode
    if returnMessage[:9] == "Traceback":
        returnCode=1

    ## Raise exception if the scripts is not run successfully
    if returnCode != 0:
        raise Exception, "Error running %s:\n%s" %(f_script,returnMessage.strip())

    ## Get output ports
    elif len(returnMessage) > 12:
        outputPorts=cPickle.loads(returnMessage.split("outputPorts=",1)[-1])

    else:
        outputPorts={}

    return outputPorts
