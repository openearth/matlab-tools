"""
    This module contains table (file) functions.

    It comprises reading, writing and a limited number of manipulations.

    The data is stored in numpy recarrays.

    The main purpose of the module is to make it easier to read and write
    different formats of table files.
"""

__author__  = "Wiebe Borren <Wiebe.Borren@deltares.nl>"
__version__ = "1.0"
__date__    = "Jan 2014"


import string, os.path, os, itertools, decimal, datetime, struct, sys, traceback, re, xlrd
from copy import deepcopy
import numpy as np
from numpy import bool,bool8,uint8,uint16,uint32,uint64,int8,int16,int32,int64,float16,float32,float64

def table2arr(f_table,l_flds=None,n_header=1,fld_str=None,abspath=False,sheet=0):
    """Function to read a table file and create a numpy recarray (structured array).

    The table file could be a comma-separated file (\*.csv), DBF file (\*.dbf), Excel file (\*.xls, \*.xlsx), iMOD IPF file (\*.ipf) or space-separated file.
    The first three file types are recognized by the file extension.

    It is not necessary to read the entire table file, but a selection of fields could be made.
    This is useful for large table files if not all fields are to be usued.

    There are also separate readers for the various file formats, but this overall reader is suitable for most cases.

    Parameters
    ----------
    f_table : str
        Table file name.

    l_flds : list or None (optional)
        List of field names to read. If *l_flds* is None all fields are read.

    n_header : int (optional)
        Number of header lines. Only relevant for comma- and space-separated files and Excel files.
        The field names are expected to be in the last line of the header.

    fld_str : str or None (optional)
        An arbitrary string which is scanned for occurences of field names.
        Occuring field names will be included in the list of fields to be read.

        Such a string could originate from user input, e.g. a condition string which is specified in an input file for a tool.

    abspath : bool (optional)
        Only relevant for iMOD IPF files.

        True = convert references to iMOD timeseries files (if existing) to absolute path names.

        False = do not convert references to iMOD timeseries files (if existing) to absolute path names.

    sheet : int or str (optional)
        Sheet index number or sheet name. Only relevant for Excel files.

    Returns
    -------
    result : numpy recarray

    See Also
    --------
    :ref:`reading_tables`
    :ref:`table_formats`
    """
    if not os.path.isfile(f_table): raise Exception, "File (%s) not valid" %(f_table)
    ext=string.lower(os.path.splitext(f_table)[-1])
    if ext == ".ipf": arr=ipf2arr(f_table,l_flds=l_flds,fld_str=fld_str,abspath=abspath)
    elif ext == ".csv": arr=csv2arr(f_table,n_header=n_header,l_flds=l_flds,fld_str=fld_str)
    elif ext == ".dbf": arr=dbf2arr(f_table,l_flds=l_flds,fld_str=fld_str)
    elif ext in [".xls",".xlsx"]: arr=xls2arr(f_table,sheet=sheet,n_header=n_header,l_flds=l_flds,fld_str=fld_str)
    else: arr=dat2arr(f_table,n_header=n_header,l_flds=l_flds,fld_str=fld_str)
    return arr

def table2fields(f_table,n_header=1,sheet=0):
    """Function to get the field names of a table file.

    Parameters
    ----------
    f_table : str
        Table file name.

    n_header : int (optional)
        Number of header lines. Only relevant for comma- and space-separated files and Excel files.
        The field names are expected to be in the last line of the header.

    sheet : int or str (optional)
        Sheet index number or sheet name. Onley relevant for Excel files.

    Returns
    -------
    result : list
        List of the field names.

    See Also
    --------
    :ref:`reading_tables`
    :ref:`table_formats`
    """
    if not os.path.isfile(f_table): raise Exception, "File (%s) not valid" %(f_table)
    ext=string.lower(os.path.splitext(f_table)[-1])
    if ext == ".ipf": return ipf2fields(f_table)
    elif ext == ".csv": return csv2fields(f_table,n_header)
    elif ext == ".dbf": return dbf2fields(f_table)
    elif ext in ["xls","xlsx"]: return xls2fields(f_table,sheet=sheet,n_header=n_header)
    else: return get_fields(f_table,None,True,n_header)

def ipf2fields(f_ipf):
    """Function to get the field names of an iMOD IPF file.

    Parameters
    ----------
    f_ipf : str
        iMOD IPF file.

    Returns
    -------
    result : list
        List of the field names.

    See Also
    --------
    :ref:`reading_tables`
    :ref:`imod_file`
    """
    if not os.path.isfile(f_ipf): raise Exception, "File (%s) not valid" %(f_ipf)
    dbflds=[]
    inf=open(f_ipf,"r")
    inf.readline(); ncol=int(inf.readline())
    for i in range(0,ncol): dbflds.append(string.strip(inf.readline()))
    inf.close()
    return dbflds

def ipf2iext(f_ipf):
    """Function to get the field number of the iMOD timeseries file references (IEXT) and the extension (EXT) from an iMOD IPF file.

    Parameters
    ----------
    f_ipf : str
        iMOD IPF file.

    Returns
    -------
    iext : int
        Field number of timeseries file references. The values in this field refer to iMOD timeseries files.

        0 = no timeseries file references specified.

        1 = first field

        etc.

    ext : str
        Extension of timeseries files.

    See Also
    --------
    :ref:`reading_tables`
    :ref:`imod_file`
    """
    if not os.path.isfile(f_ipf): raise Exception, "File (%s) not valid" %(f_ipf)
    inf=open(f_ipf,"r")
    inf.readline(); ncol=int(inf.readline())
    for i in range(0,ncol): inf.readline()
    iext,ext=string.split(string.replace(string.strip(inf.readline()),","," "))[:2]
    inf.close()
    iext=int(iext)
    return iext,ext

def csv2fields(f_csv,n_header=1):
    """Function to get the field names of a comma-separated file.

    Parameters
    ----------
    f_csv : str
        Comma-separated file.

    n_header : int (optional)
        Number of header lines. The field names are expected to be in the last line of the header.

    Returns
    -------
    result : list
        List of the field names.

    See Also
    --------
    :ref:`reading_tables`
    :ref:`csv_file`
    """
    if not os.path.isfile(f_csv): raise Exception, "File (%s) not valid" %(f_csv)
    return get_fields(f_csv,",",True,n_header)

def dbf2fields(f_dbf):
    """Function to get the field names of a DBF file.

    Parameters
    ----------
    f_dbf : str
        DBF file.

    Returns
    -------
    result : list
        List of the field names.

    See Also
    --------
    :ref:`reading_tables`
    :ref:`dbf_file`
    """
    if not os.path.isfile(f_dbf): raise Exception, "File (%s) not valid" %(f_dbf)
    return dbf2fields_specs(f_dbf)[0]

def dbf2fields_specs(f_dbf):
    """Function to get the field names and field specs of a DBF file.

    Parameters
    ----------

    Returns
    -------
    result : list
        The returned list contains:

        List with field names.

        List with field specs in the form (type, size, deci).

    See Also
    --------
    :ref:`reading_tables`
    :ref:`dbf_file`
    """
    if not os.path.isfile(f_dbf): raise Exception, "File (%s) not valid" %(f_dbf)
    inf=open(f_dbf,"rb")
    dbdata=list(dbfreader(inf,True))
    inf.close()
    return dbdata

def dat2fields(f_dat,n_header=1):
    """Function to get the field names of a space-separated file.

    Parameters
    ----------
    f_dat : str
        Space-separated file.

    n_header : int (optional)
        Number of header lines. The field names are expected to be in the last line of the header.

    Returns
    -------
    result : list
        List of the field names.

    See Also
    --------
    :ref:`reading_tables`
    :ref:`dat_file`
    """
    if not os.path.isfile(f_dat): raise Exception, "File (%s) not valid" %(f_dat)
    return get_fields(f_dat,None,True,n_header)

def xls2fields(f_xls,sheet=0,n_header=1,return_irowcol=False,datablock=None):
    """Function to get the field names of a table in a worksheet in an Excel workbook.

    Parameters
    ----------
    f_xls : str
        Excel file name.

    sheet : int or str (optional)
        Sheet index number or sheet name.

    n_header : int (optional)
        Number of header lines. The field names are expected to be in the last line of the header.

        Note that empty rows are always ignored; n_header is counted from the first non-empty row.

    return_irowcol : bool (optional)
        Option to return the row and column indices of the table.

    datablock : list or None (optional)
        Data block: [irow_start,irow_end,icol_start,icol_end].

        The indices may be None, which means that default values are used: 0 for *irow_start* and *icol_start*, nrow and ncol for *irow_end* and *icol_end*.

        The indices *irow_end* and *icol_end* may be negative, which means that they are counted backward from nrow and ncol.

    Returns
    -------
    fields : list
        List of field names.

    irow : list
        List of row indices.

        Only return if *return_irowcol* is True. *irow* includes the header of the table.

    icol : list
        List of column indices.

        Only return if *return_irowcol* is True.
    """
    book=xlrd.open_workbook(f_xls)
    if type(sheet) == str:
        sheet=[s.lower() for s in book.sheet_names()].index(sheet.lower())
    sheet=book.sheet_by_index(sheet)

    dbflds,icol,irow=[],[],0
    if sheet.nrows > 0:
        if datablock != None:
            irow_start,irow_end,icol_start,icol_end=datablock
            if irow_start == None: irow_start=0
            if irow_end == None: irow_end=sheet.nrows
            elif irow_end < 0: irow_end=sheet.nrows+irow_end+1
            else: irow_end=min(sheet.nrows,int(irow_end)+1)
            if icol_start == None: icol_start=0
            if icol_end == None: icol_end=sheet.ncols
            elif icol_end < 0: icol_end=sheet.ncols+icol_end+1
            else: icol_end=min(sheet.ncols,int(icol_end)+1)
        else:
            irow_start,irow_end,icol_start,icol_end=0,sheet.nrows,0,sheet.ncols
        if irow_end >= irow_start and icol_end >= icol_start:
            for irow in range(irow_start,irow_end):
                try:
                    if string.join(sheet.row_values(irow,start_colx=icol_start,end_colx=icol_end),"").strip() != "":
                        raise
                except:
                    break

            irow_start=irow

            if n_header == 0:
                dbflds=["f%d" %(i) for i in range(0,icol_end-icol_start)]
            else:
                dbflds=[str(fld).strip() for fld in sheet.row_values(irow_start+n_header-1,start_colx=icol_start,end_colx=icol_end)]
            icol=range(icol_start,icol_end)
            for i in range(0,len(dbflds)):
                if dbflds[i] != "":
                    dbflds=dbflds[i:]
                    icol=icol[i:]
                    break
            for i in range(0,len(dbflds))[::-1]:
                if dbflds[i] != "":
                    dbflds=dbflds[:i+1]
                    icol=icol[:i+1]
                    break
    if return_irowcol:
        return dbflds,[irow_start,irow_end],icol
    else:
        return dbflds

def xls2sheets(f_xls):
    """Function to get the worksheet names of an Excel workbook.

    Parameters
    ----------
    f_xls : str
        Excel file name.

    Returns
    -------
    sheets : list
        List of sheet names
    """
    return [str(s) for s in xlrd.open_workbook(f_xls).sheet_names()]

def _xls2datemode(f_xls):
    """Function to get the datemode of an Excel workbook: 0=1900, 1=1904.

    Parameters
    ----------
    f_xls : str
        Excel file name.

    Returns
    -------
    datemode : int
        Datemode: 0=1900, 1=1904.
    """
    return xlrd.open_workbook(f_xls).datemode

def get_fields(f_table,delimiter=",",autostrip=False,n_header=1):
    """Function to get the field names of a text-formatted table file.

    Parameters
    ----------
    f_table : str
        Text-formatted table file.

        It is assumed that the field names are on one header line (in contrast to the text-formatted iMOD IPF file).

    delimiter : str or None
        The delimiter/separator used to separate values.

        If *delimiter* is None it is assumed that the file is space-separated.

    Returns
    -------
    result : list
        List of the field names.

    See Also
    --------
    :ref:`reading_tables`
    :ref:`txt_file`
    :func:`table_func.csv2fields`
    :func:`table_func.dat2fields`
    """
    if not os.path.isfile(f_table): raise Exception, "File (%s) not valid" %(f_table)
    inf=open(f_table,"r")
    if n_header <= 0:
        headline=inf.readline()
    else:
        for i in range(0,n_header): headline=inf.readline()
    inf.close()
    if headline[-1] == "\n": headline=headline[:-1]
    if delimiter in ["",None]:
        dbflds=string.split(headline)
    elif delimiter == '"':
        dbflds=string.split(headline,delimiter)
    else:
        dbflds=split_string(headline,splitList=[delimiter],whitespace=False,autostrip=False,keeptogether=['"'],removekeepChars=['"'],double2one=False,multiLines=False)
    if n_header <= 0:
        dbflds=["f%d" %(i) for i in range(0,len(dbflds))]
    if autostrip:
        dbflds=[string.strip(fld) for fld in dbflds]
    return dbflds

def _genfromtxt0(f_table,delimiter,autostrip,usecols,dtype,names,skip_header):
    """Function to read a text-formatted table file and create a numpy recarray.

    Parameters
    ----------
    f_table : str
    delimiter : str, int or sequence
    autostrip : bool
    usecols : sequence
    dtype : dtype
    names : list
    skip_header : int

    Returns
    -------
    result : numpy recarray
    """
    try:
        istmp=False
        f_tmp,rep=_replace_delimiter(f_table,delimiter)
        if f_tmp != f_table:
            f_table=f_tmp
            istmp=True
        arr=np.genfromtxt(f_table,delimiter=delimiter,autostrip=autostrip,usecols=usecols,dtype=dtype,names=names,skip_header=skip_header)
        if arr.ndim == 0:
            arr=np.array([arr],dtype=arr.dtype)
        if istmp:
            os.remove(f_table)
            arr,rep=_replace_delimiter(arr,rep,delimiter)
        if istmp or rep not in [None,delimiter]:
            for fld in arr.dtype.names:
                try:
                    arr[fld]=[s[s[0] == '"':len(s)-(s[-1] == '"')] for s in arr[fld]]
                except:
                    pass
        return arr
    except Exception:
        ex1=(sys.exc_info()[1],traceback.format_exc())
        if string.find(str(ex1[0]),"End-of-file reached before encountering data") != -1:
            try:
                if names not in [[],None]: flds=deepcopy(names)
                else: flds=get_fields(f_table,delimiter=delimiter,autostrip=autostrip)
                if dtype == None:
                    dt=[]
                    for fld in flds:
                        dt.append((fld,float64))
                else: dt=dtype
                return np.zeros((0,),dtype=dt)
            except:
                print ex1[1]; raise ex1[0]
        else:
            print ex1[1]; raise ex1[0]

def txt2arr(f_table,delimiter=",",autostrip=False,i_flds=None,formats=None,n_header=0,recarr2ndarr=False):
    """Function to read a text-formatted table file and create a numpy recarray or ndarray.

    Parameters
    ----------
    f_table : str
        Text-formatted table file.

    delimiter : str or None (optional)
        The delimiter/separator used to separate values.

        If *delimiter* is None it is assumed that the file is space-separated.

    autostrip : bool (optional)
        True = field names and string values are stripped.

        False = field names and string values are not stripped.

    i_flds : list, int or None (optional)
        The index number(s) of the field(s) to be read.

        If *i_flds* is None or an empty list all fields are read.

    formats : list/tuple, dtype or None (optional)
        The formats (dtypes) used for the fields. These overrule the dtypes automatically applied by numpy.

        If *formats* is a list containing less dtypes than the number of fields the last dtype is repeated for the remaining fields.

        If *formats* is a single dtype this is used for all fields.

    n_header : int (optional)
        Number of header lines.
        The field names are expected to be in the last line of the header.

    recarr2ndarr : bool (optional)
        True = the result is returned as a numpy ndarray instead of a numpy recarray.
        If *i_flds* is a single integer the result will be 1-dimensional instead of 2-dimensional.

        False = the result is returned as numpy recarray.

    Returns
    -------
    result : numpy recarray or ndarray
        If *recarr2ndarr* is False the data is returned as numpy recarray.

        If *recarr2ndarr* is True the data is returned as numpy ndarray.
        If *i_flds* is specified as a single integer the resulting ndarray is 1-dimensional; otherwise it is 2-dimensional.

    See Also
    --------
    :ref:`reading_tables`
    :func:`table_func.table2arr`
    :func:`table_func.get_fields`
    """
    if formats == None: dtNone=True
    else: dtNone=False
    fields0=get_fields(f_table,delimiter,False,n_header=abs(n_header))
    dim=2
    if i_flds == None or i_flds == []: i_flds=range(0,len(fields0))
    elif type(i_flds) not in [list,tuple]: dim,i_flds=1,[i_flds]
    i_flds1=[]
    for i in i_flds:
        if i >= 0 and i < len(fields0): i_flds1.append(i)
    i_flds0=deepcopy(i_flds1)
#    i_flds1=np.unique(i_flds1).tolist()
    fields,nfields=[],[]
    if n_header < 0:
        for i in i_flds1:
            if autostrip != None: fields.append(string.strip(fields0[i]))
            else: fields.append(fields0[i])
        n_header=-n_header
    else:
        for i in i_flds1: fields.append("f%d" %(i))
    for i in range(0,len(fields)):
        nfields.append(0)
        if fields[i] in fields[:i]:
            inf=fields[:i].index(fields[i])
            nfields[inf]+=1
            fields[i]="%s_%d" %(fields[i],nfields[inf])
    if type(formats) not in [list,tuple]: formats=[formats]
    formats=list(formats)
    for i in range(len(formats),len(fields)): formats.append(formats[-1])
    dt=[]
    for i in range(0,len(fields)): dt.append((fields[i],formats[i]))
#    if autostrip or dtNone:
    if dtNone:
        arr=_genfromtxt0(f_table,delimiter=delimiter,autostrip=autostrip,usecols=i_flds1,dtype=None,names=fields,skip_header=n_header)
    else: arr=_genfromtxt0(f_table,delimiter=delimiter,autostrip=autostrip,usecols=i_flds1,dtype=dt,names=fields,skip_header=n_header)
    arr.dtype.names=fields
#    else:
#        istmp=False
#        f_tmp,rep=_replace_delimiter(f_table,delimiter)
#        if f_tmp != f_table:
#            f_table=f_tmp
#            istmp=True
#        arr=np.loadtxt(f_table,delimiter=delimiter,usecols=i_flds1,dtype=dt,skiprows=n_header)
#        if istmp:
#            os.remove(f_table)
#            arr,rep=_replace_delimiter(arr,rep,delimiter)
    if np.abs(np.array(i_flds1)-np.array(i_flds0)).sum() != 0:
        arr=take_from_recarr(arr,np.take(fields,np.argsort(i_flds0)))
    if len(arr.shape) == 0:
        arr=np.reshape(arr,(1,))
    if delimiter != '"':
        for i in range(0,len(arr.dtype)):
            dt_name=arr[arr.dtype.names[i]].dtype.name
            if string.find(dt_name,"string") != -1:
                for j in range(0,len(arr)):
                    try:
                        if arr[arr.dtype.names[i]][j][0] == '"':
                            arr[arr.dtype.names[i]][j]=arr[arr.dtype.names[i]][j][1:]
                        if arr[arr.dtype.names[i]][j][-1] == '"':
                            arr[arr.dtype.names[i]][j]=arr[arr.dtype.names[i]][j][:-1]
                    except: pass
    if recarr2ndarr:
        if dim == 1: arr=recarray2ndarray(arr,0)
        else: arr=recarray2ndarray(arr)
    return arr

def recarray2ndarray(arr,i_flds=None,format=None):
    """Function to convert a numpy recarray to a regular numpy ndarray.

    Parameters
    ----------
    arr : numpy recarray

    i_flds : list, int or None (optional)
        The index number(s) of the field(s) to be converted.

        If *i_flds* is None all fields are read.

    format : dtype or None (optional)
        The dtype to convert the data to.

        If *format* is None the dtype is taken from the first field to be converted.

    Returns
    -------
    result : numpy ndarray
    """
    dim=2
    if i_flds == None: i_flds=range(0,len(arr[0]))
    elif type(i_flds) not in [list,tuple]: dim,i_flds=1,[i_flds]
    i_flds1=[]
    for i in i_flds:
        if i >= 0 and i < len(arr[0]): i_flds1.append(i)
    if format == None: format=arr[arr.dtype.names[i_flds[0]]].dtype.name
    arr1=np.zeros((len(arr),len(i_flds1)),format)
    for i in range(0,len(i_flds)):
        arr1[:,i]=np.array(arr[arr.dtype.names[i_flds[i]]],format)
    if dim == 1: return arr1[:,0]
    else: return arr1

def _str2flds(dbflds,flds=None,fld_str=None,i_or_fldname=0): # returns the fields (indices or names) that are in the string
    """Function to extract occuring field names or indices from an arbitrary string.
    """
    fnd=[]
    if flds == None: flds=[]
    if type(fld_str) in [list,tuple]: fld_str=string.join([str(v) for v in fld_str],"|")
    if type(fld_str) == str:
        for i in np.argsort([len(s) for s in dbflds])[::-1]:
            if string.find(fld_str,dbflds[i]) != -1:
                fld_str=string.replace(fld_str,dbflds[i],"")
                fnd.append(i)
    if len(fnd) > 0:
        if len(flds) == 0: flds=deepcopy(fnd)
        else:
            if type(flds) not in [list,tuple]: flds=[flds]
            flds=list(flds)
            for i in np.sort(fnd):
                if i not in flds and dbflds[i] not in flds: flds.append(i)
    if i_or_fldname == 0:
        for i in range(0,len(flds)):
            try: flds[i]=dbflds.index(flds[i])
            except: pass
    else:
        for i in range(0,len(flds)):
            try: flds[i]=dbflds[flds[i]]
            except: pass
    return flds

def _str2arrflds(s,dbflds,arrname="arr"): # returns the string with the field names replaced by structured array references
    """Function to extract occuring field names from an arbitrary string and return these as recarray references.
    """
    lut_t1t2=[]
    for i in np.argsort([len(f) for f in dbflds])[::-1]:
        t0=dbflds[i]
        if string.find(s,t0) != -1:
            t1,t2="qQq[%d]" %(i),"%s['%s']" %(arrname,t0)
            s=string.replace(s,t0,t1)
            lut_t1t2.append([t1,t2])
    for t1,t2 in lut_t1t2: s=string.replace(s,t1,t2)
    return s

def _str2regarrflds(s,dbflds,arrname="arr"): # returns the string with the field names replaced by regular array references
    """Function to extract occuring field names from an arbitrary string and return these as regular ndarray references.
    """
    lut_t1t2=[]
    dbflds0=[]
    for i in range(0,len(dbflds)): dbflds0.append(dbflds[i])
    for i in np.argsort([len(f) for f in dbflds])[::-1]:
        t0=dbflds[i]
        if string.find(s,t0) != -1:
            t1,t2="qQq[%d]" %(i),"%s[%d]" %(arrname,dbflds0.index(t0))
            s=string.replace(s,t0,t1)
            lut_t1t2.append([t1,t2])
    for t1,t2 in lut_t1t2: s=string.replace(s,t1,t2)
    return s


def _dt2unique_names(dt):
    """Function to change dtype-names if they appear more than once in a dtype-list.
    """
    dt_new=deepcopy(dt)
    for i in range(1,len(dt_new)):
        for j in range(0,i):
            if dt_new[i][0] == dt_new[j][0]:
                ii=1
                while True:
                    new_name="%s_%d" %(dt_new[i][0],ii)
                    fnd=False
                    for k in range(i+1,len(dt_new)):
                        if dt_new[k][0] == new_name:
                            fnd=True; break
                    if not fnd:
                        dt_new[i]=(new_name,dt_new[i][1])
                        break
                    ii+=1
    return dt_new

def ipf2arr(f_ipf,l_flds=None,fld_str=None,abspath=False):
    """Function to read an iMOD IPF file and create a numpy recarray.

    It is not necessary to read the entire table file, but a selection of fields could be made.
    This is useful for large table files if not all fields are to be usued.

    Parameters
    ----------
    f_ipf : str
        iMOD IPF file.

    l_flds : list or None (optional)
        List of field names to read. If *l_flds* is None all fields are read.

    fld_str : str or None (optional)
        An arbitrary string which is scanned for occurences of field names.
        Occuring field names will be included in the list of fields to be read.

        Such a string could originate from user input, e.g. a condition string which is specified in an input file for a tool.

    abspath : bool (optional)
        True = convert references to iMOD timeseries files (if existing) to absolute path names.

        False = do not convert references to iMOD timeseries files (if existing) to absolute path names.

    Returns
    -------
    result : numpy recarray

    See Also
    --------
    :ref:`reading_tables`
    :ref:`imod_file`
    :func:`table_func.table2arr`
    """
    inf=open(f_ipf,"r")
    nrec=int(inf.readline().replace(","," ").split()[0])
    ncol=int(inf.readline().replace(","," ").split()[0])
    dbflds=[inf.readline().replace('"',"").replace(","," ").split()[0].strip() for i in range(0,ncol)]
    i_ext,ext=[v.strip() for v in inf.readline().replace(","," ").split()[:2]]
    i_ext=int(i_ext)-1

    if nrec == 0:
        arr=np.array([],dtype=[(fld,"?") for fld in dbflds])
        inf.close()

    else:
        rec=re.findall(r'".+?"|[^ \t\r\f\v"]+',string.join(["%s\n" %(line.strip()) for line in inf.readlines()],"").replace("'",'"'))
        inf.close()
        s=rec[0]
        for i in range(1,len(rec)):
            s+=","*(s[-1] != "," and rec[i][0] != ",")+rec[i]

        f_ipf_new=f_ipf+"_newipffile.csv.tmp"
        outf=open(f_ipf_new,"w")
        outf.write("%s\n%s\n" %(string.join(dbflds,","),s))
        outf.close()

        flds0=deepcopy(l_flds)
        flds=[]
        if type(flds0) in [list,tuple]:
            for i in range(0,len(flds0)):
                try: flds+=[dbflds.index(flds0[i])]
                except: pass
        else: flds=range(0,len(dbflds))
        flds=_str2flds(dbflds,flds,fld_str)
        arr=_genfromtxt0(f_ipf_new,delimiter=",",autostrip=True,usecols=flds,dtype=None,names=[dbflds[i] for i in flds],skip_header=1)
        arr.dtype.names=[dbflds[i] for i in flds]
        os.remove(f_ipf_new)
        try:
            if arr.shape == (): arr=np.reshape(arr,(1,))
        except: pass
        if i_ext in flds and len(arr) != 0:
            if str(arr[dbflds[i_ext]][0])[-len(ext):].lower() != ext.lower():
                l=["%s.%s" %(s,ext) for s in arr[dbflds[i_ext]]]
                if abspath:
                    dir_old=os.getcwd()
                    os.chdir(os.path.dirname(f_ipf))
                    l=[os.path.abspath(s) for s in l]
                    os.chdir(dir_old)
                arr=change_dtype(arr,[dbflds[i_ext]],["a%d" %(max([len(s) for s in l]))])
                arr[dbflds[i_ext]]=l

    return arr

def imodtss2arr(f_tss,l_flds=None,fld_str=None):
    """Function to read an iMOD timeseries file and create a numpy recarray.

    It is not necessary to read the entire table file, but a selection of fields could be made.
    This is useful for large table files if not all fields are to be usued.

    Parameters
    ----------
    f_tss : str
        iMOD timeseries file.

    l_flds : list or None (optional)
        List of field names to read. If *l_flds* is None all fields are read.

    fld_str : str or None (optional)
        An arbitrary string which is scanned for occurences of field names.
        Occuring field names will be included in the list of fields to be read.

        Such a string could originate from user input, e.g. a condition string which is specified in an input file for a tool.

    Returns
    -------
    data : numpy recarray

    nodata : dict
        The returned dict contains the nodata values of the fields in the numpy recarray.

    See Also
    --------
    :ref:`reading_tables`
    :ref:`imod_file`
    """
    inf=open(f_tss,"r")
    nrec,nfld=int(inf.readline().replace(","," ").split()[0]),int(inf.readline().replace(","," ").split()[0])
    dbflds=[split_string(string.strip(inf.readline().replace("'",'"')),splitList=[","],whitespace=True,autostrip=False,keeptogether=['"'],removekeepChars=['"'],double2one=False,multiLines=False)[:2] for i in range(0,nfld)]
    dbflds,l_nodata=[rec[0] for rec in dbflds],[rec[1] for rec in dbflds]

    flds0=deepcopy(l_flds)
    flds=[]
    if type(flds0) in [list,tuple]:
        for i in range(0,len(flds0)):
            try: flds+=[dbflds.index(flds0[i])]
            except: pass
    else: flds=range(0,len(dbflds))
    flds=_str2flds(dbflds,flds,fld_str)

    line=inf.readline()
    if string.find(line," ") != -1:
        recs=[split_string(string.strip(line).replace("'",'"'),splitList=[","],whitespace=True,autostrip=False,keeptogether=['"'],removekeepChars=['"'],double2one=False,multiLines=False)]
        recs[0][0]=recs[0][0][:8]
        recs+=[split_string(string.strip((inf.readline()).replace("'",'"')).replace("000000",''),splitList=[","],whitespace=True,autostrip=False,keeptogether=['"'],removekeepChars=['"'],double2one=False,multiLines=False) for i in range(0,nrec)]
        inf.close()
        f_tss_new=f_tss+"_newtssfile.csv.tmp"
        outf=open(f_tss_new,"w")
        outf.write(string.join(dbflds,",")+"\n")
        outf.write(string.join([string.join(rec,",") for rec in recs],"\n")+"\n")
        outf.close()
        arr=table2arr(f_tss_new)
        arr=_genfromtxt0(f_tss_new,delimiter=",",autostrip=True,usecols=flds,dtype=None,names=[dbflds[i] for i in flds],skip_header=1)
        arr.dtype.names=[dbflds[i] for i in flds]
        os.remove(f_tss_new)
    else:
        inf.close()
        arr=_genfromtxt0(f_tss,delimiter=",",autostrip=True,usecols=flds,dtype=None,names=[dbflds[i] for i in flds],skip_header=nfld+2)
        arr.dtype.names=[dbflds[i] for i in flds]

    for i in range(0,len(arr.dtype)):
        if arr.dtype[i].name[:3] == "int":
            if -1e-7 < float(l_nodata[i])-int(float(l_nodata[i])) < 1e-7:
                l_nodata[i]=int(float(l_nodata[i]))
            else:
                arr=change_dtype(arr,[arr.dtype.names[i]],[float64])

    nodata=dict([(dbflds[i],_value_dtype2type(np.array(l_nodata[i],arr.dtype[i]))) for i in flds])

    return arr,nodata

def csv2arr(f_csv,n_header=1,l_flds=None,fld_str=None):
    """Function to read a comma-separated file and create a numpy recarray.

    It is not necessary to read the entire table file, but a selection of fields could be made.
    This is useful for large table files if not all fields are to be usued.

    Parameters
    ----------
    f_csv : str
        Comma-separated file.

    n_header : int (optional)
        Number of header lines.
        The field names are expected to be in the last line of the header.

    l_flds : list or None (optional)
        List of field names to read. If *l_flds* is None all fields are read.

    fld_str : str or None (optional)
        An arbitrary string which is scanned for occurences of field names.
        Occuring field names will be included in the list of fields to be read.

        Such a string could originate from user input, e.g. a condition string which is specified in an input file for a tool.

    Returns
    -------
    result : numpy recarray

    See Also
    --------
    :ref:`reading_tables`
    :ref:`csv_file`
    :func:`table_func.table2arr`
    """
    dbflds=get_fields(f_csv,delimiter=",",autostrip=True,n_header=n_header)
    flds0=deepcopy(l_flds)
    flds=[]
    if type(flds0) in [list,tuple]:
        for i in range(0,len(flds0)):
            try: flds+=[dbflds.index(flds0[i])]
            except: pass
    else: flds=range(0,len(dbflds))
    flds=_str2flds(dbflds,flds,fld_str)
    return txt2arr(f_csv,delimiter=",",autostrip=True,i_flds=flds,formats=None,n_header=-n_header,recarr2ndarr=False)

def dbf2arr(f_dbf,l_flds=None,fld_str=None):
    """Function to read a DBF file and create a numpy recarray.

    It is not necessary to read the entire table file, but a selection of fields could be made.
    This is useful for large table files if not all fields are to be usued.

    Parameters
    ----------
    f_dbf : str
        DBF file.

    l_flds : list or None (optional)
        List of field names to read. If *l_flds* is None all fields are read.

    fld_str : str or None (optional)
        An arbitrary string which is scanned for occurences of field names.
        Occuring field names will be included in the list of fields to be read.

        Such a string could originate from user input, e.g. a condition string which is specified in an input file for a tool.

    Returns
    -------
    result : numpy recarray

    See Also
    --------
    :ref:`reading_tables`
    :ref:`dbf_file`
    :func:`table_func.table2arr`
    """
    if l_flds != None:
        l_flds=_str2flds(dbf2fields(f_dbf),l_flds,fld_str,i_or_fldname=1)
    f=open(f_dbf,"rb")
    dbdata=list(dbfreader(f,l_flds=l_flds))
    dbdata[0]=[string.strip(fld) for fld in dbdata[0]]
    f.close()
    dbflds=deepcopy(dbdata[0])
    flds0=deepcopy(l_flds)
    flds=[]
    if type(flds0) in [list,tuple]:
        flds0=[string.strip(fld) for fld in flds0]
        for i in range(0,len(flds0)):
            try: flds+=[dbflds.index(flds0[i])]
            except: pass
        flds=np.compress(np.where(np.array(flds) < len(dbflds),True,False),flds,0).tolist()
    else: flds=range(0,len(dbdata[0]))
    flds=_str2flds(dbflds,flds,fld_str)
    dt=[]
    for i in flds:
        if dbdata[1][i][0] == "N":
            if dbdata[1][i][2] == 0: dt+=[(dbdata[0][i],int32)]
            else: dt+=[(dbdata[0][i],float64)]
        elif dbdata[1][i][0] == "F": dt+=[(dbdata[0][i],float64)]
        elif dbdata[1][i][0] == "D": dt+=[(dbdata[0][i],"a%d" %(10))]
        else: dt+=[(dbdata[0][i],"a%d" %(dbdata[1][i][1]))]
    arr=np.zeros((len(dbdata)-2,),dtype=_dt2unique_names(dt))
    for i in range(0,len(dbdata)-2): arr[i]=tuple([dbdata[i+2][j] for j in flds])
    for fld in arr.dtype.names:
        try: arr[fld]=[string.strip(s) for s in arr[fld]]
        except: pass
    return arr

def dat2arr(f_dat,n_header=1,l_flds=None,fld_str=None):
    """Function to read a space-separated file and create a numpy recarray.

    It is not necessary to read the entire table file, but a selection of fields could be made.
    This is useful for large table files if not all fields are to be usued.

    Parameters
    ----------
    f_dat : str
        Space-separated file.

    n_header : int (optional)
        Number of header lines.
        The field names are expected to be in the last line of the header.

    l_flds : list or None (optional)
        List of field names to read. If *l_flds* is None all fields are read.

    fld_str : str or None (optional)
        An arbitrary string which is scanned for occurences of field names.
        Occuring field names will be included in the list of fields to be read.

        Such a string could originate from user input, e.g. a condition string which is specified in an input file for a tool.

    Returns
    -------
    result : numpy recarray

    See Also
    --------
    :ref:`reading_tables`
    :ref:`dat_file`
    :func:`table_func.table2arr`
    """
    dbflds=get_fields(f_dat,delimiter=None,autostrip=True,n_header=n_header)
    flds0=deepcopy(l_flds)
    flds=[]
    if type(flds0) in [list,tuple]:
        for i in range(0,len(flds0)):
            try: flds+=[dbflds.index(flds0[i])]
            except: pass
    else: flds=range(0,len(dbflds))
    flds=_str2flds(dbflds,flds,fld_str)
    return txt2arr(f_dat,delimiter=None,autostrip=True,i_flds=flds,formats=None,n_header=-n_header,recarr2ndarr=False)

def xls2arr(f_xls,sheet=0,n_header=1,l_flds=None,fld_str=None,date2datetime64=True,datablock=None):
    """Function to read a table from a worksheet in an Excel workbook.

    Parameters
    ----------
    f_xls : str
        Excel file name.

    sheet : int or str (optional)
        Sheet index number or sheet name.

    n_header : int (optional)
        Number of header lines. The field names are expected to be in the last line of the header.

        Note that empty rows are always ignored; n_header is counted from the first non-empty row.

    l_flds : list or None (optional)
        List of field names to read. If *l_flds* is None all fields are read.

    fld_str : str or None (optional)
        An arbitrary string which is scanned for occurences of field names.
        Occuring field names will be included in the list of fields to be read.

        Such a string could originate from user input, e.g. a condition string which is specified in an input file for a tool.

    date2datetime64 : bool (optional)
        True = convert Excel dates to numpy datetime64 dtype.

        False = do not convert Excel dates to numpy datetime64 dtype; dates are returned as strings in the format 'YYYY-MM-DD hh:mm:ss'.

    datablock : list or None (optional)
        Data block: [irow_start,irow_end,icol_start,icol_end].

        The indices may be None, which means that default values are used: 0 for *irow_start* and *icol_start*, nrow and ncol for *irow_end* and *icol_end*.

        The indices *irow_end* and *icol_end* may be negative, which means that they are counted backward from nrow and ncol.

    Returns
    -------
    result : numpy recarray

    See Also
    --------
    :ref:`reading_tables`
    :ref:`xls_file`
    :func:`table_func.table2arr`
    """
    dbflds,irow,icol=xls2fields(f_xls,sheet=sheet,n_header=n_header,return_irowcol=True,datablock=datablock)
    if len(dbflds) == 0:
        arr=[]

    else:
        flds0=deepcopy(l_flds)
        flds=[]
        if type(flds0) in [list,tuple]:
            for i in range(0,len(flds0)):
                try: flds+=[dbflds.index(flds0[i])]
                except: pass
        else: flds=range(0,len(dbflds))
        flds=_str2flds(dbflds,flds,fld_str)

        icol=[icol[fld] for fld in flds]

        book=xlrd.open_workbook(f_xls)
        if type(sheet) == str:
            sheet=[str(s).lower() for s in book.sheet_names()].index(sheet.lower())
        sheet=book.sheet_by_index(sheet)

        arr_cols=[]
        for c in icol:
            ct=sheet.col_types(c,start_rowx=irow[0]+n_header, end_rowx=irow[-1])
            vals=sheet.col_values(c, start_rowx=irow[0]+n_header, end_rowx=irow[-1])
            if 3 in ct:
                datemode=_xls2datemode(f_xls)
                for i in np.compress(np.array(ct) == 3,np.arange(0,len(ct)),0):
                    try:
                        vals[i]="%4d-%02d-%02d %02d:%02d:%02d" %((xlrd.xldate_as_tuple(vals[i],datemode)+(0,)*6)[:6])
                        if date2datetime64:
                            vals[i]=np.array(vals[i]+"Z",np.datetime64)
                    except:
                        pass
            arr_cols+=[np.array(vals)]
            try:
                arr_cols[-1]=np.array(arr_cols[-1],"a%d" %(max([len(s) for s in arr_cols[-1]])))
            except:
                pass
        dt=[(dbflds[flds[i]],arr_cols[i].dtype) for i in range(0,len(flds))]
        arr=np.zeros((len(arr_cols[0]),),dtype=dt)
        for i in range(0,len(arr_cols)):
            arr[arr.dtype.names[i]]=arr_cols[i]

    return arr

def xls2arr_allsheets(f_xls,skip_empty_sheets=True,n_header=1,l_flds=None,fld_str=None,date2datetime64=True,datablock=None):
    """Function to read the tables from all worksheets in an Excel workbook.

    Parameters
    ----------
    f_xls : str
        Excel file name.

    skip_empty_sheets : bool (optional)
        Option to skip empty worksheets in the workbook.

    n_header : int (optional)
        Number of header lines. The field names are expected to be in the last line of the header.

        Note that empty rows are always ignored; n_header is counted from the first non-empty row.

    l_flds : list or None (optional)
        List of field names to read. If *l_flds* is None all fields are read.

    fld_str : str or None (optional)
        An arbitrary string which is scanned for occurences of field names.
        Occuring field names will be included in the list of fields to be read.

        Such a string could originate from user input, e.g. a condition string which is specified in an input file for a tool.

    date2datetime64 : bool (optional)
        True = convert Excel dates to numpy datetime64 dtype.

        False = do not convert Excel dates to numpy datetime64 dtype; dates are returned as strings.

    datablock : list or None (optional)
        Data block: [irow_start,irow_end,icol_start,icol_end].

        The indices may be None, which means that default values are used: 0 for *irow_start* and *icol_start*, nrow and ncol for *irow_end* and *icol_end*.

        The indices *irow_end* and *icol_end* may be negative, which means that they are counted backward from nrow and ncol.

    Returns
    -------
    result : list
        List containing a numpy recarray for each table.

    sheets : list
        List of corresponding worksheet names.

    See Also
    --------
    :ref:`reading_tables`
    :ref:`xls_file`
    :func:`table_func.table2arr`
    """
    sheets=xls2sheets(f_xls)
    arr=[xls2arr(f_xls,sheet,n_header=n_header,l_flds=l_flds,fld_str=fld_str,date2datetime64=date2datetime64,datablock=datablock) for sheet in sheets]
    for i in range(0,len(arr))[::-1]:
        if arr[i] == []:
            arr=arr[:i]+arr[i+1:]
            sheets=sheets[:i]+sheets[i+1:]
    return arr,sheets

def dbfreader(f,only_fields=False,l_flds=None):
    """Function to create a generator over records in a DBF file.

    Adapted from: `<http://code.activestate.com/recipes/362715-dbf-reader-and-writer/>`_

    Parameters
    ----------
    f : file object (DBF file opened for binary reading)

    only_fields : bool (optional)
        True = only field names and specs are returned.

        False = field names and specs and data records are returned.

    l_flds : list or None (optional)
        List of field names to read. If *l_flds* is None all fields are read.

    Returns
    -------
    result : generator
        First row: field names.

        Second row: field specs (type, size, decimal places).

        Subsequent rows: data records.

    See Also
    --------
    :ref:`reading_tables`
    :ref:`dbf_file`
    :func:`table_func.dbf2arr`
    :func:`table_func.dbf2fields_specs`
    """
    numrec, lenheader = struct.unpack('<xxxxLH22x', f.read(32))
    numfields = (lenheader - 33) // 32

    fields = []
    for fieldno in xrange(numfields):
        name, typ, size, deci = struct.unpack('<11sc4xBB14x', f.read(32))
        name = name.replace('\0', '')       # eliminate NULs from string
        fields.append((name, typ, size, deci))

    if l_flds == None:
        dbflds=[rec[0].strip() for rec in fields]
        fields1=deepcopy(fields)
    else:
        dbflds=[fld.strip() for fld in l_flds]
        fields1=[]
        for i in range(0,len(fields)):
            if fields[i][0].strip() in dbflds:
                fields1+=[fields[i]]

    yield [field[0] for field in fields1]
    yield [tuple(field[1:]) for field in fields1]

    if not only_fields:
        terminator = f.read(1)
        assert terminator == '\r'

        fields.insert(0, ('DeletionFlag', 'C', 1, 0))
        fmt = ''.join(['%ds' % fieldinfo[2] for fieldinfo in fields])
        fmtsiz = struct.calcsize(fmt)
        for i in xrange(numrec):
            record = struct.unpack(fmt, f.read(fmtsiz))
            if record[0] != ' ':
                continue                        # deleted record
            result = []
            for (name, typ, size, deci), value in itertools.izip(fields, record):
                if name == 'DeletionFlag':
                    continue
                if name.strip() in dbflds:
                    if typ == "N":
                        try:
                            value = value.replace('\0', '').lstrip()
                            if value == '':
                                value = 0
                            elif deci:
                                value = decimal.Decimal(value)
                            else:
                                value = int(value)
                        except:
                            if deci:
                                value=np.nan
                            else:
                                value=0
                    elif typ == 'D':
                        try:
                            y, m, d = int(value[:4]), int(value[4:6]), int(value[6:8])
                            if y == 0 or m == 0 or d == 0:
                                raise
                        except:
                            y,m,d=1,1,1
                        value = datetime.date(y, m, d)
                    elif typ == 'L':
                        value = (value in 'YyTt' and 'T') or (value in 'NnFf' and 'F') or '?'
                    elif typ == 'F':
                        try:
                            value = float(value)
                        except:
                            value=np.nan
                    result.append(value)
            yield result

def dbfwriter(f, fieldnames, fieldspecs, records):
    """Function to create and write a binary string directly to an opened DBF file.

    Adapted from: `<http://code.activestate.com/recipes/362715-dbf-reader-and-writer/>`_

    Parameters
    ----------
    f : file object (file opened for binary writing)

    fieldnames : list
        List of fieldnames.

        Fieldnames should be no longer than ten characters and not include \\x00.

    fieldspecs : list
        List of fieldspecs for each field.

        Fieldspecs are in the form (type, size, deci) where

            type is one of:

                C for ascii character data

                M for ascii character memo data (real memo fields not supported)

                D for datetime objects

                N for ints or decimal objects

                F for floats

                L for logical values 'T', 'F', or '?'

            size is the field width

            deci is the number of decimal places in the provided decimal object

    records : array or array_like
        Sequences of field values (the records or rows of the table).

    See Also
    --------
    :ref:`writing_tables`
    :ref:`dbf_file`
    :func:`table_func.arr2dbfspecs`
    :func:`table_func.arr2dbf`
    """
    # header info
    ver = 3
    now = datetime.datetime.now()
    yr, mon, day = now.year-1900, now.month, now.day
    numrec = len(records)
    numfields = len(fieldspecs)
    lenheader = numfields * 32 + 33
    lenrecord = sum(field[1] for field in fieldspecs) + 1
    hdr = struct.pack('<BBBBLHH20x', ver, yr, mon, day, numrec, lenheader, lenrecord)
    f.write(hdr)

    # field specs
    for name, (typ, size, deci) in itertools.izip(fieldnames, fieldspecs):
        name = name.ljust(11, '\x00')
        fld = struct.pack('<11sc4xBB14x', name, typ, size, deci)
        f.write(fld)

    # nodata
    l_nodata=[]
    for i in range(0,len(records[0])):
        l_nodata+=[dtype2nodata(type(records[0][i]))]

    # terminator
    f.write('\r')

    # records
    for i in range(0,len(records)):
        record=records[i]
        f.write(' ')                        # deletion flag
        j=0
        for (typ, size, deci), value in itertools.izip(fieldspecs, record):
            if value == l_nodata[j]:
                value=" "*size
            elif typ == "N":
                value = ("%%.%df" %(deci) %(value))[:size].rjust(size, ' ')
            elif typ == "F":
                if np.isnan(value): value=" "*size
                elif size <= 13: value="%13.6e" %(value)
                else: value="%22.15e" %(value)
            elif typ == 'D':
                value = value.strftime('%Y%m%d')
            elif typ == 'L':
                value = str(value)[0].upper()
            else:
                value = str(value)[:size].ljust(size, ' ')
            assert len(value) == size
            f.write(value)
            j+=1

    # End of file
    f.write('\x1A')

def make_recarr(n,dt,nodata=0):
    """Function to create a numpy recarray filled with nodata.

    Parameters
    ----------
    n : int
        Number of records.

    dt : list
        List of dtypes in the form (field name, dtype).

    nodata : bool, int, float, str or sequence (optional)
        Nodata value(s).

        If *nodata* is a single value (bool, int or float) this value is applied for all fields, if possible.

        If *nodata* is a sequence (list, tuple or array) it should contain one value for each field.

    Returns
    -------
    result : numpy recarray
    """
    arr=np.zeros((n,),dtype=dt)
    if nodata != 0:
        try: arr[:]=tuple(nodata)
        except:
            try: arr[:]=(nodata,)*len(arr[0])
            except: pass
    return arr

def take_from_recarr(arr,flds):
    """Function to take specific fields from a numpy recarray.

    Parameters
    ----------
    arr : numpy recarray

    flds : sequence
        Field name(s) to be taken from *arr*.

        If a field name occurs more than once in *flds* the field name is extended with a number.

    Returns
    -------
    result : numpy recarray
    """
    dbflds=arr.dtype.names
    cnt=np.zeros((len(dbflds),),uint32)
    flds1=[]
    dt=[]
    for fld in flds:
        i=dbflds.index(fld)
        cnt[i]+=1
        if cnt[i] > 1:
            while True:
                fld1="%s_%d" %(fld,cnt[i])
                if fld1 not in dbflds: break
                cnt[i]+=1
        else: fld1=fld
        dt.append((fld1,arr.dtype[i]))
        flds1.append(fld1)
    arr1=np.zeros((len(arr),),dtype=dt)
    for i in range(0,len(flds)): arr1[flds1[i]]=arr[flds[i]].copy()
    return arr1

def add_to_recarr(arr,dt_or_arr,nodata=0):
    """Function to add fields to a numpy recarray.

    Parameters
    ----------
    arr : numpy recarray

    dt_or_arr : list of dtype(s) or numpy recarray
        The dtypes of the fields to be added or the recarray to be added.

        If *dt_or_arr* is specified as list it should be a list of dtypes in the form (field name, dtype).

        If *dt_or_arr* is a recarray containing field names which already exist in *arr* these field names are extended with a number.
        If the number of records differs from *arr* records are removed or new records are added to *dt_or_arr*.

    nodata : bool, int, float, str or sequence (optional)
        Nodata value(s) to be applied if *dt_or_arr* is specified as dtype.

        If *nodata* is a single value (bool, int or float) this value is applied for all fields, if possible.

        If *nodata* is a sequence (list, tuple or array) it should contain one value for each field.

    Returns
    -------
    result : numpy recarray
    """
    dbflds=arr.dtype.names
    try:
        dt_or_arr.dtype.names
        arr0=dt_or_arr; del dt_or_arr
        arr0=arr0[:len(arr)]
        if len(arr0) < len(arr):
            tmp=np.zeros((len(arr)-len(arr0),),arr0.dtype)
            try: tmp[:]=tuple(nodata)
            except:
                try: tmp[:]=(nodata,)*len(tmp[0])
                except: pass
            arr0=np.concatenate([arr0,tmp],0); del tmp
    except:
        dbflds0=[dt[0] for dt in dt_or_arr]
        for i in range(0,len(dbflds0)):
            n=1
            while True:
                if dbflds0[i] not in dbflds0[:i]:
                    break
                dbflds0[i]="%s_%d" %(dt_or_arr[i][0],n)
                n+=1
            dt_or_arr[i]=(dbflds0[i],dt_or_arr[i][1])
        arr0=np.zeros((len(arr),),dtype=list(dt_or_arr))
        try: arr0[:]=tuple(nodata)
        except:
            try: arr0[:]=(nodata,)*len(arr0[0])
            except: pass
    dbflds0=arr0.dtype.names
    cnt=np.ones((len(dbflds),),uint32)
    flds1=[]
    dt=[]
    for i in range(0,len(dbflds)):
        fld=dbflds[i]
        dt.append((fld,arr.dtype[i]))
        flds1.append(fld)
    for i in range(0,len(dbflds0)):
        fld=dbflds0[i]
        if fld in dbflds:
            i2=dbflds.index(fld)
            cnt[i2]+=1
            while True:
                fld1="%s_%d" %(fld,cnt[i2])
                if fld1 not in dbflds+dbflds0:
                    fld=fld1; break
                cnt[i2]+=1
        dt.append((fld,arr0.dtype[i]))
        flds1.append(fld)
    arr1=np.zeros((len(arr),),dtype=dt)
    for fld in dbflds: arr1[fld]=arr[fld].copy()
    for i in range(0,len(dbflds0)):
        arr1[flds1[len(dbflds)+i]]=arr0[dbflds0[i]].copy()
    return arr1

def remove_from_recarr(arr,flds):
    """Function to remove fields from a numpy recarray.

    Parameters
    ----------
    arr : numpy recarray

    flds: list
        List of fields to be removed.

    Returns
    -------
    result : numpy recarray
    """
    sel=[]
    for fld in arr.dtype.names:
        if fld not in flds:
            sel+=[fld]
    return arr[sel]

def change_dtype(arr,flds,new_types):
    """Function to change the datatype (dtype) of specific fields in a numpy recarray.

    Parameters
    ----------
    arr : numpy recarray

    flds: list
        List of fields to be changed.

    new_types : list
        List of new dtypes.

    Returns
    -------
    result : numpy recarray
    """
#    flds0=list(arr.dtype.names)
#    flds1=deepcopy(flds0)
#    for fld in flds: flds1[flds0.index(fld)]="%sqQqQqQqQ" %(fld)
#    arr.dtype.names=flds1
#    dt=[]
#    for i in range(0,len(flds)): dt.append((flds[i],new_types[i]))
#    arr=add_to_recarr(arr,dt)
#    for fld in flds:
#        arr[fld]=arr["%sqQqQqQqQ" %(fld)]
#    arr=take_from_recarr(arr,flds0)
#    return arr
    dt=[]
    for i in range(0,len(arr.dtype)):
        try:
            dt.append((arr.dtype.names[i],new_types[flds.index(arr.dtype.names[i])]))
        except:
            dt.append((arr.dtype.names[i],arr.dtype[i]))
#    arr_new=np.zeros(arr.shape,dtype=dt)
#    for fld in arr.dtype.names:
#        arr_new[fld]=arr[fld].copy()
    arr_new=arr.astype(dt)
    return arr_new

def arr2table(arr,f_table,formats=["%s"],delimiter=" ",i_ext=0,relpath=False,fieldspecs=None):
    """Function to write a numpy recarray to a table file.

    The table file could be a comma-separated file (\*.csv), DBF file (\*.dbf), iMOD IPF file (\*.ipf) or space-separated file.
    The first three file types are recognized by the file extension.

    There are also separate writers for the various file formats, but this overall writer is suitable for most cases.

    Parameters
    ----------
    arr : numpy recarray

    f_table : str
        Table file name.

    formats : str, sequence or None (optional)
        The Python % format(s) used to write the values.

        Only relevant for text-formatted files (including iMOD IPF files).

        See `<http://docs.python.org/2/library/stdtypes.html#string-formatting-operations>`_.

        If *formats* is None the format '%s' is used.

    delimiter : str (optional)
        The delimiter/separator used to separate values.

        Only relevant for iMOD files and text-formatted files other than \*.csv.

    i_ext : int (optional)
        Index number. Only relevant for iMOD IPF files.

        See :ref:`imod_file`.

    relpath : bool (optional)
        Only relevant for iMOD IPF files.

        True = convert references to iMOD timeseries files (if existing) to relative path names.

        False = do not convert references to iMOD timeseries files (if existing) to relative path names.

    fieldspecs : list or None (optional)
        List of field specs in the form (type, size, deci). Only relevant for DBF files.

        See :ref:`dbf_file` and :func:`arr2dbfspecs <table_func.arr2dbfspecs`.

        If *fieldspecs* is None the specs are determined automatically.

    See Also
    --------
    :ref:`writing_tables`
    :ref:`table_formats`
    """
    ext=string.lower(os.path.splitext(f_table)[-1])
    if ext == ".ipf": arr2ipf(arr.copy(),f_table,formats=formats,delimiter=delimiter,i_ext=i_ext,relpath=relpath)
    elif ext == ".csv": arr2csv(arr.copy(),f_table,header=True,formats=formats)
    elif ext == ".dbf": arr2dbf(arr.copy(),f_table,fieldspecs=fieldspecs)
    else: arr2txt(arr.copy(),f_table,delimiter=delimiter,header=True,formats=formats)

def arr2ipf(arr,f_ipf,formats=["%s"],delimiter=",",i_ext=0,relpath=False):
    """Function to write a numpy recarray to an iMOD IPF file.

    Parameters
    ----------
    arr : numpy recarray

    f_ipf : str
        iMOD IPF file.

    formats : str, sequence or None (optional)
        The Python % format(s) used to write the values.

        See `<http://docs.python.org/2/library/stdtypes.html#string-formatting-operations>`_.

        If *formats* is None the format '%s' is used.

    delimiter : str (optional)
        The delimiter/separator used to separate values.

    i_ext : int (optional)
        Index number.

        See :ref:`imod_file`.

        The extension is determined automatically and (if possbile) stripped off from the values in the field.
        If this is not possible the extension is set to 'TXT' by default.

    relpath : bool (optional)
        True = convert references to iMOD timeseries files (if existing) to relative path names.

        False = do not convert references to iMOD timeseries files (if existing) to relative path names.

    See Also
    --------
    :ref:`writing_tables`
    :ref:`imod_file`
    :func:`table_func.arr2table`
    """
    ext="TXT"

    if len(arr) != 0:
        if formats == None: formats=["%s"]
        if type(formats) == str: formats=[formats]
        for i in range(len(formats),len(arr.dtype)): formats.append(formats[-1])

        if i_ext > 0:
            try:
                un=np.unique([string.split(string.replace(s,'"',''),".")[-1] for s in arr[arr.dtype.names[i_ext-1]]])
                if len(un) == 1:
                    if string.find(arr[0][i_ext-1],".") != -1:
                        ext=un[0]
                        arr[arr.dtype.names[i_ext-1]]=[string.replace(s,".%s" %(ext),"") for s in arr[arr.dtype.names[i_ext-1]]]
                if relpath:
                    arr[arr.dtype.names[i_ext-1]]=[os.path.relpath(s,os.path.dirname(f_ipf)) for s in arr[arr.dtype.names[i_ext-1]]]
            except: i_ext=0
        else: i_ext=0

        for i in range(0,len(arr.dtype)):
            dt_name=arr[arr.dtype.names[i]].dtype.name
            if string.find(dt_name,"string") != -1:
                if max([string.find(s,delimiter) for s in arr[arr.dtype.names[i]]]+[string.find(s," ") for s in arr[arr.dtype.names[i]]]) != -1:
                    s_len=int(string.replace(dt_name,"string",""))/8
                    arr=change_dtype(arr,[arr.dtype.names[i]],["a%d" %(s_len+2)])
                    arr[arr.dtype.names[i]]=[string.replace('"%s"' %(s),'""','"') for s in arr[arr.dtype.names[i]]]
                    for j in range(0,len(arr)):
                        if arr[arr.dtype.names[i]][j] == '"':
                            arr[arr.dtype.names[i]][j]='""'

        l_col=[[formats[i] %(v) for v in arr[arr.dtype.names[i]]] for i in range(0,len(arr.dtype))]
        l_maxlen=[max([len(v) for v in l_col[i]]) for i in range(0,len(l_col))]
        l_align=[""]*len(l_maxlen)
        for i in range(0,len(arr.dtype)):
            if string.find(arr[arr.dtype.names[i]].dtype.name,"string") != -1: l_align[i]="-"

        formats=["%%%s%ds" %(l_align[i],l_maxlen[i]) for i in range(0,len(l_maxlen))]

    outf=open(f_ipf,"w")
    outf.write("%d\n%d\n%s\n%d,%s\n" %(len(arr),len(arr.dtype.names),string.join(arr.dtype.names,"\n"),i_ext,ext))
    if len(arr) != 0:
        for i in range(0,len(l_col[0])):
            outf.write("%s\n" %(string.join([formats[c] %(l_col[c][i]) for c in range(0,len(l_col))],delimiter)))
    outf.close()

def arr2imodtss(arr,f_tss,l_nodata=-999999,delimiter=","):
    """Function to write a numpy recarray to an iMOD timeseries file.

    Parameters
    ----------
    arr : numpy recarray

    f_tss : str
        iMOD timeseries file.

    l_nodata : dict, list, int or float (optional)
        Nodata values(s) of the fields.

        If *l_nodata* is a dict the keys in the dict are the field names and the values the nodata values.

        If *l_nodata* is a single value (int, float) this value is used for all fields.

    delimiter : str (optional)
        The delimiter/separator used to separate values.

    See Also
    --------
    :ref:`writing_tables`
    :ref:`imod_file`
    :func:`table_func.arr2table`
    """
    if type(l_nodata) not in [list,tuple]:
        if type(l_nodata) == dict:
            l_nodata=[l_nodata[key] for key in arr.dtype.names]
        else:
            l_nodata=[l_nodata]*len(arr.dtype)
    outf=open(f_tss,"w")
    outf.write("%d\n%d\n" %(len(arr),len(arr.dtype)))
    for i in range(0,len(arr.dtype)):
        if string.find(arr.dtype.names[i]," ") != -1:
            outf.write('"%s"%s%s\n' %(arr.dtype.names[i],delimiter,l_nodata[i]))
        else:
            outf.write('%s%s%s\n' %(arr.dtype.names[i],delimiter,l_nodata[i]))
    for i in range(0,len(arr)):
        outf.write("%s\n" %(string.join([str(v) for v in arr[i]],delimiter)))
    outf.close()

def arr2csv(arr,f_csv,header=True,formats=["%s"]):
    """Function to write numpy recarray to a comma-separated file.

    Parameters
    ----------
    arr : numpy recarray

    f_table : str
        Comma-separated file.

    header : bool
        True = a header line containing the field names is written.

        False = no header line is written.

    formats : str, sequence or None (optional)
        The Python % format(s) used to write the values.

        See `<http://docs.python.org/2/library/stdtypes.html#string-formatting-operations>`_.

        If *formats* is None the format '%s' is used.

    See Also
    --------
    :ref:`writing_tables`
    :ref:`csv_file`
    :func:`table_func.arr2table`
    """
    arr2txt(arr,f_csv,",",header,formats)

def arr2dbfspecs(arr):
    """Function to get DBF field specs for a numpy recarray.

    Parameters
    ----------
    arr : numpy recarray

    Returns
    -------
    dbfspecs : list
        List with field specs in the form (type, size, deci).

        See :ref:`dbf_file`.

    See Also
    --------
    :ref:`dbf_file`
    """
    fieldspecs=[]
    for i in range(0,len(arr.dtype.names)):
        dt=arr[arr.dtype.names[i]].dtype.name
        if dt == "int64": fieldspecs.append(("N",21,0))
        elif dt == "uint64": fieldspecs.append(("N",20,0))
        elif dt == "int32": fieldspecs.append(("N",11,0))
        elif dt == "uint32": fieldspecs.append(("N",10,0))
        elif dt == "int16": fieldspecs.append(("N",6,0))
        elif dt == "uint16": fieldspecs.append(("N",5,0))
        elif dt == "int8": fieldspecs.append(("N",4,0))
        elif dt == "uint8": fieldspecs.append(("N",3,0))
        elif dt in ["bool"]: fieldspecs.append(("L",1,0))
        elif dt in ["float64"]:
            a=np.array(arr[arr.dtype.names[i]],int64)
            deci=max(22-2-max(_get_power10(a.min()),_get_power10(a.max())),1)
            fieldspecs.append(("F",22,deci))
        elif dt in ["float32","float16"]:
            a=np.array(arr[arr.dtype.names[i]],int32)
            deci=max(13-2-max(_get_power10(a.min()),_get_power10(a.max())),1)
            fieldspecs.append(("F",13,deci))
        elif dt == np.datetime64:
            fieldspecs.append(("D",8,0))
        elif len(dt) > 6:
            if dt[:6] == "string": fieldspecs.append(("C",int(dt[6:])/8,0))
            else: fieldspecs.append(("C",50,0))
        else: fieldspecs.append(("C",50,0))
    return fieldspecs

def arr2dbf(arr,f_dbf,fieldspecs=None):
    """Function to write numpy recarray to a DBF file.

    Parameters
    ----------
    arr : numpy recarray

    f_dbf : str
        DBF file.

    fieldspecs : list or None (optional)
        List of field specs in the form (type, size, deci).

        See :ref:`dbf_file` and :func:`arr2dbfspecs <table_func.arr2dbfspecs`.

        If *fieldspecs* is None the specs are determined automatically.

    See Also
    --------
    :ref:`writing_tables`
    :ref:`dbf_file`
    :func:`table_func.arr2table`
    """
    flds0,flds=[],[]
    for i in range(0,len(arr.dtype.names)):
        fld=arr.dtype.names[i]
        fld=string.replace(fld," ","_")
        if len(fld) > 10: fld=fld[:10]
        flds0.append(fld)
    for i in range(0,len(flds0)):
        fld=flds0[i]
        if fld in flds0[:i]:
            fld0=fld[:9]
            n=1
            while True:
                fld="%s%d" %(fld0,n)
                if fld not in flds0 and fld not in flds: break
                n+=1
        flds.append(fld)
    if fieldspecs == None:
        fieldspecs=arr2dbfspecs(arr)
    outf=open(f_dbf,"wb")
    dbfwriter(outf,flds,fieldspecs,arr)
    outf.close()

def arr2dat(arr,f_dat,header=True,formats=["%s"]):
    """Function to write numpy recarray to a space-separated file.

    Parameters
    ----------
    arr : numpy recarray

    f_dat : str
        Space-separated file.

    header : bool
        True = a header line containing the field names is written.

        False = no header line is written.

    formats : str, sequence or None (optional)
        The Python % format(s) used to write the values.

        See `<http://docs.python.org/2/library/stdtypes.html#string-formatting-operations>`_.

        If *formats* is None the format '%s' is used.

    See Also
    --------
    :ref:`writing_tables`
    :ref:`dat_file`
    :func:`table_func.arr2table`
    """
    arr2txt(arr,f_dat," ",header,formats)

def arr2txt(arr,f_txt,delimiter=",",header=True,formats=["%s"]):
    """Function to write a numpy recarray to a text-formatted table file.

    Parameters
    ----------
    arr : numpy recarray

    f_txt : str
        Text-formatted file.

    delimiter : str (optional)
        The delimiter/separator used to separate values.

    header : bool
        True = a header line containing the field names is written.

        False = no header line is written.

    formats : str, sequence or None (optional)
        The Python % format(s) used to write the values.

        See `<http://docs.python.org/2/library/stdtypes.html#string-formatting-operations>`_.

        If *formats* is None the format '%s' is used.

    See Also
    --------
    :ref:`writing_tables`
    :ref:`txt_file`
    :func:`table_func.arr2table`
    """
    if len(arr) != 0:
        if type(formats) not in [list,tuple]: formats=[formats]
        formats=list(formats)
        for i in range(len(formats),len(arr[0])): formats.append("%s")

        for i in range(0,len(arr.dtype)):
            dt_name=arr[arr.dtype.names[i]].dtype.name
            if string.find(dt_name,"string") != -1:
                if max([string.find(s,delimiter) for s in arr[arr.dtype.names[i]]]) != -1:
                    s_len=int(string.replace(dt_name,"string",""))/8
                    arr=change_dtype(arr,[arr.dtype.names[i]],["a%d" %(s_len+2)])
                    arr[arr.dtype.names[i]]=[string.replace('"%s"' %(s),'""','"') for s in arr[arr.dtype.names[i]]]

    outf=open(f_txt,"w")
    if header:
        try: flds=arr.dtype.names
        except: flds=["f%d" %(i) for i in range(0,len(arr[0]))]
        outf.write("%s\n" %(string.join(["%s" %(s) for s in flds],delimiter)))
    for i in range(0,len(arr)):
        outf.write("%s\n" %(string.join([formats[j] %(arr[i][j]) for j in range(0,len(arr[i]))],delimiter)))
    outf.close()

def split_csv(s,commaSplit=True,semicolonSplit=False,whitespaceSplit=False,multiLines=False):
    """Function to split a string according to 'csv' rules.

    Split on commas and/or semicolons and/or whitespace. String may contain multiple lines, in which case \\\\n is used as delimiter.

    Double-quoted substrings are not split.

    Whitespace is stripped off from the substrings.

    Parameters
    ----------
    s : string
        The string to be split.

    commaSplit : bool (optional)
        True = comma is used as delimiter.

        False = comma is not used as delimiter.

    semicolonSplit : bool (optional)
        True = semicolon is used as delimiter.

        False = semicolon is not used as delimiter.

    whitespaceSplit : bool (optional)
        True = whitespace is used as delimiter. Whitespace around comma or semicolon is not treated as separate delimiter.

        False = whitespace is not used as delimiter.

    multiLines : bool (optional)
        True = string is split into multiple lines at occurences of \\\\n.

        False = string is not split into multiple lines.

    Returns
    -------
    record : list
        Record contains the substrings. If *multiLines* is True then a list of records is returned.
    """
    if multiLines:
        return [split_csv(line,commaSplit=commaSplit,semicolonSplit=semicolonSplit,multiLines=False) for line in s.split("\n")]

    if semicolonSplit:
        if commaSplit:
            splitList=[",",";"]
        else:
            splitList=[";"]
    else:
        splitList=[","]

    s=s.strip()

    rep=[[sub.span(),'""',s[sub.start()+1:sub.end()-1]] for sub in re.finditer(r'".*?"',s)]

    if len(rep) > 0:
        for rec in rep[::-1]:
            s=s[:rec[0][0]+1]+s[rec[0][1]-1:]

    if whitespaceSplit:
        splitRec=re.split(r"\s*%s\s*|\s*" %(string.join(splitList,r"\s*|\s*")),s)
    else:
        splitRec=[v.strip() for v in re.split(string.join(splitList,r"|"),s)]

    if len(rep) > 0:

        i_rep=0
        for i in range(0,len(splitRec)):
            i_sub=0
            while True:
                if splitRec[i][i_sub:].find(rep[i_rep][1]) == -1:
                    break
                i_start=splitRec[i][i_sub:].find(rep[i_rep][1])+i_sub
                i_end=i_start+len(rep[i_rep][1])
                splitRec[i]="%s%s%s" %(splitRec[i][:i_start],rep[i_rep][2],splitRec[i][i_end:])
                i_sub=i_start+len(rep[i_rep][2])
                i_rep+=1
                if i_rep == len(rep):
                    break
            if i_rep == len(rep):
                break

    return splitRec

def split_ipf(s,multiLines=False):
    """Function to split a string according to 'ipf' rules.

    Split on whitespace, commas and semicolons. String may contain multiple lines, in which case \\\\n is used as delimiter.

    Double-quoted substrings are not split.

    Whitespace is stripped off from the substrings.

    Parameters
    ----------
    s : string
        The string to be split.

    multiLines : bool (optional)
        True = string is split into multiple lines at occurences of \\\\n.

        False = string is not split into multiple lines.

    Returns
    -------
    record : list
        Record contains the substrings. If *multiLines* is True then a list of records is returned.
    """
    return split_csv(s,commaSplit=True,semicolonSplit=True,whitespaceSplit=True,multiLines=multiLines)

def split_freeformat(s):
    """Function to split a string according to 'freeformat' rules.

    Split on whitespace and commas. Subsequent delimiters (whitespace and commas) are treated as one delimiter.

    Double-quoted substrings are not split.

    Whitespace is stripped off from the substrings.

    Parameters
    ----------
    s : string
        The string to be split.

    Returns
    -------
    record : list
        Record contains the substrings.
    """
    return [v.replace('"',"") for v in re.findall(r'[^\s,"]*".*?"[^\s,"]*|[^\s,"]+',s)]

def split_string(s,splitList=[","],whitespace=True,autostrip=True,keeptogether=[['"']],removekeepChars=['"'],double2one=False,multiLines=False):
    """Function to split a string using one or more delimiters.

    Parameters
    ----------
    s :
        String to be split.

    splitList : list (optional)
        List containing the delimiter string(s). This may be an empty list if no delimiter string will apply.

    whitespace : bool (optional)
        True = whitespace is used as delimiter. Whitespace around other delimiters is not treated as separate delimiter.

        False = whitespace is not used as delimiter.

    autostrip : bool (optional)
        True = whitespace is stripped off from the substrings.

        False = whitespace is not stripped off.

    keeptogether : list or None (optional)
        List containing the string(s) between which the string is not split (e.g. double quotes). Examples:

        [] or None = not specified

        ['"'] = substrings between double quotes are not split

        [['(', ')'] , '"'] = substrings between parentheses (open and close parenthesis) and substrings between double quotes are not split

    removekeepChars : list or None (optional)
        List of strings specified at *keeptogether* which should be removed from the resulting substrings.

        [] or None = not specified, all (optional) strings specified at *keeptogether* will be preserved.

        ['"'] = double quotes will be removed from the respective substrings.

        ['(', ')', '"'] = parentheses and double quotes will be removed from the respective substrings.

    double2one : bool (optional)
        True = subsequent (double or multiple) delimiters are treated as one delimiter.

        False = subsequent delimiters are treated as separate delimiters.

    multiLines : bool (optional)
        True = string is split into multiple lines at occurences of \\\\n.

        False = string is not split into multiple lines.

    Returns
    -------
    record : list
        Record contains the substrings.
    """

    if multiLines:
        return [split_string(line,splitList=splitList,whitespace=whitespace,autostrip=autostrip,keeptogether=keeptogether,removekeepChars=removekeepChars,double2one=double2one,multiLines=False) for line in s.split("\n")]

    if autostrip or whitespace:
        s=s.strip()

    keep=None
    if keeptogether not in [None,False,""]:
        if type(keeptogether) == str:
            keep=[[keeptogether,keeptogether]]
        else:
            keep=[]
            for i in range(0,len(keeptogether)):
                if type(keeptogether[i]) == str:
                    keep+=[[keeptogether[i]]]
                else:
                    keep+=[keeptogether[i]]
            if len(keep) == 0:
                keep=None

    rep=[]

    if keep != None:

        if removekeepChars in [False,None,""] or type(removekeepChars) not in [str,bool,list,tuple]:
            removekeepChars=[]
        elif type(removekeepChars) == str:
            removekeepChars=[removekeepChars]
        elif type(removekeepChars) == bool:
            removekeepChars=[]
            for i in range(0,len(keep)):
                for j in range(0,len(keep[i])):
                    removekeepChars+=[keep[i][j]]

        rep=[]
        for i in range(0,len(keep)):
            keep1,keep2=keep[i][0],keep[i][-1]
            if keep1 in [".","^","$","*","+","?","{","}","\\","[","]","|","(",")"]:
                keep1=r"\%s" %(keep1)
            if keep2 in [".","^","$","*","+","?","{","}","\\","[","]","|","(",")"]:
                keep2=r"\%s" %(keep2)
            for sub in re.finditer(r'%s.*?%s' %(keep1,keep2),s):
                rep+=[[sub.span(),"%s%s" %(keep[i][0],keep[i][-1]),s[sub.start()+(keep[i][0] in removekeepChars):sub.end()-(keep[i][-1] in removekeepChars)]]]
        if len(rep) > 0:
            rep=[rep[i] for i in np.argsort([rec[0][0] for rec in rep])]
            for rec in rep[::-1]:
                s=s[:rec[0][0]+1]+s[rec[0][1]-1:]
        else:
            keep=None

    if len(splitList) > 0:
        if double2one:
            if whitespace:
                for i in range(0,len(splitList)):
                    s=s.replace(splitList[i]," ")
            else:
                for i in range(0,len(splitList)):
                    for j in range(0,len(splitList)):
                        while True:
                            if s.find("%s%s" %(splitList[i],splitList[j])) == -1:
                                break
                            s=s.replace("%s%s" %(splitList[i],splitList[j]),splitList[i])
        if whitespace:
            pattern=r"\s*%s\s*|\s*" %(string.join(splitList,r"\s*|\s*"))
        else:
            pattern=string.join(splitList,"|")
        splitRec=re.split(pattern,s)
    elif whitespace:
        splitRec=s.split()
    else:
        splitRec=[s]

    if len(rep) > 0:
        i_rep=0
        for i in range(0,len(splitRec)):
            i_sub=0
            while True:
                if splitRec[i][i_sub:].find(rep[i_rep][1]) == -1:
                    break
                i_start=splitRec[i][i_sub:].find(rep[i_rep][1])+i_sub
                i_end=i_start+len(rep[i_rep][1])
                splitRec[i]="%s%s%s" %(splitRec[i][:i_start],rep[i_rep][2],splitRec[i][i_end:])
                i_sub=i_start+len(rep[i_rep][2])
                i_rep+=1
                if i_rep == len(rep):
                    break
            if i_rep == len(rep):
                break

    if autostrip:
        for i in range(0,len(splitRec)):
            splitRec[i]=splitRec[i].strip()

    return splitRec

def replace_string(s,sourceList=[],targetList=[],whitespaceTarget=None,keeptogether=[['"']]):
    """Function to replace substrings by other substrings.

    Parameters
    ----------
    s : string
        Source string within which substrings are replaced.

    sourceList : list (optional)
        List containing substrings to be replaced.

    targetList : list (optional)
        List containing substrings which are used as replacements. If the number of strings is less than in *sourceList* then empty strings are used.

    whitespaceTarget : string or None (optional)
        String to be used as replacement for whitespace. None = not specified.

    keeptogether : list or None (optional)
        List containing the string(s) between which replacements are not performed (e.g. double quotes). Examples:

        [] or None = not specified

        ['"'] = between double quotes no replacements are performed

        [['(', ')'] , '"'] = between parentheses (open and close parenthesis) and double quotes no replacements are performed

    Returns
    -------
    result : string
        Resulting string.
    """
    for i in range(len(targetList),len(sourceList)):
        targetList+=[""]

    keep=None
    if keeptogether not in [None,False,""]:
        if type(keeptogether) == str:
            keep=[[keeptogether,keeptogether]]
        else:
            keep=[]
            for i in range(0,len(keeptogether)):
                if type(keeptogether[i]) == str:
                    keep+=[[keeptogether[i]]]
                else:
                    keep+=[keeptogether[i]]
            if len(keep) == 0:
                keep=None

    if keep != None:
        rep=[]
        for i in range(0,len(keep)):
            keep1,keep2=keep[i][0],keep[i][-1]
            if keep1 in [".","^","$","*","+","?","{","}","\\","[","]","|","(",")"]:
                keep1=r"\%s" %(keep1)
            if keep2 in [".","^","$","*","+","?","{","}","\\","[","]","|","(",")"]:
                keep2=r"\%s" %(keep2)
            for sub in re.finditer(r'%s.*?%s' %(keep1,keep2),s):
                rep+=[[sub.span(),"%s%s" %(keep[i][0],keep[i][-1]),s[sub.start():sub.end()]]]
        if len(rep) > 0:
            rep=[rep[i] for i in np.argsort([rec[0][0] for rec in rep])]
            for rec in rep[::-1]:
                s=s[:rec[0][0]+1]+s[rec[0][1]-1:]
        else:
            keep=None

    if type(whitespaceTarget) == str:
        s=string.join(re.split(r'\s*',s),whitespaceTarget)

    for i in range(0,len(sourceList)):
        s=s.replace(sourceList[i],targetList[i])

    if keep != None:
        i_sub=0
        for i_rep in range(0,len(rep)):
            i_start=s[i_sub:].find(rep[i_rep][1])+i_sub
            i_end=i_start+len(rep[i_rep][1])
            s="%s%s%s" %(s[:i_start],rep[i_rep][2],s[i_end:])
            i_sub=i_start+len(rep[i_rep][2])

    return s


def dtype2nodata(dtype):
    if type(dtype) == str:
        if dtype[0] == "a":
            dtype="'string%d'" %(int(dtype[1:])*8)
    typ=string.split(string.split(str(dtype),"'")[1],".")[-1]
    if string.find(typ,"float") != -1:
        nodata=np.nan
    elif string.find(typ,"uint") != -1:
        bit=string.split(typ,"uint")[-1]
        if bit == "": bit=32
        nodata=2**int(bit)-1
    elif string.find(typ,"int") != -1:
        bit=string.split(typ,"int")[-1]
        if bit == "": bit=32
        nodata=-2**int(bit)/2
    elif string.find(typ,"string") != -1:
        nodata=""
    elif string.find(typ,"datetime") != -1:
        nodata=np.datetime64("NaT")
    else:
        nodata=None
    return nodata

def _get_power10(v):
    """Function to get the exponent of a number.
    """
    return int(string.split("%E" %(v),"E")[1])

def _value_dtype2type(v):
    """Function to convert a value from numpy dtype to bool/int/float.
    """
    try:
        if v.dtype in [bool,bool8]: return bool(v)
        elif v.dtype in [float16,float32,float64]: return float(v)
        else: return int(v)
    except: return v

def _replace_delimiter(f,old,new=None):
    """Function to replace a delimiter in a double-quoted value; the delimiter is replaced by a unique character/string.
    """
    if type(f) == str:
        if os.path.isfile(f): inf=open(f,"r"); s=inf.read(); inf.close()
        else: s=f
        if string.find(s,'"') != -1:
            if new == None:
                new=old
                i=1
                while True:
                    if new != old:
                        break
                    for x in ["^","@","!","$"]:
                        if string.find(s,x*i) == -1:
                            new=x*i
                            break
                    i+=1
            l=split_string(s,splitList=[old],whitespace=False,autostrip=False,keeptogether=['"'],removekeepChars=['"'],double2one=False,multiLines=False)
            l=[s.replace(old,new) for s in l]
            s=string.join(l,old)
            if string.find(s,new) != -1:
                i=0
                while True:
                    f_tmp="%s(%d)%s" %(os.path.splitext(f)[0],i,os.path.splitext(f)[1])
                    if not os.path.isfile(f_tmp):
                        f=f_tmp
                        break
                    i+=1
                outf=open(f,"w"); outf.write(s); outf.close()
    elif new != None:
        for fld in f.dtype.names:
            try:
                f[fld]=[s.replace(old,new) for s in f[fld]]
            except:
                pass
    return f,new
