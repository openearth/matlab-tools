import xml.etree.ElementTree as ET
import xml.dom.minidom
import string

class ETParse_including_comments(ET.XMLTreeBuilder):
   def __init__(self):
       ET.XMLTreeBuilder.__init__(self)
       # assumes ElementTree 1.2.X
       self._parser.CommentHandler = self.handle_comment

   def close(self):
       return ET.XMLTreeBuilder.close(self)

   def handle_comment(self, data):
       self._target.start(ET.Comment, {})
       self._target.data(data)
       self._target.end(ET.Comment)

def read_xml(f_xml,strip_xmlns=None,strip_comments=True):
    ## Parse xml file to ElementTree
    if strip_comments: root=ET.parse(f_xml).getroot()
    else: root=ET.parse(f_xml,ETParse_including_comments()).getroot()
    ## Get default xml namespace
    def_xmlns=string.split(root.tag,"}")[0][1:]
    ## Strip off namespaces if required; strip_xmlns: True=strip off all namespaces, False=keep all namespaces, other=strip off all namespaces except for root
    if strip_xmlns == True and type(strip_xmlns) == bool:
        root.tag=string.split(root.tag,"}")[-1]
    elif type(strip_xmlns) != bool:
        strip_xmlns=True
    if strip_xmlns:
        started=False
        for e in root.iter():
            if started:
                try: e.tag=string.split(e.tag,"}")[-1]
                except: pass
            started=True
    ## Return ElementTree and default namespace
    return root,def_xmlns

def create_root_xml(tag,attrib={},FEWS=True,xmlns=None,xmlns_xsi=None,xsi_schemaLocation=None):
    attr=''
    for key in attrib:
        if key == "xmlns":
            if xmlns == None: xmlns=attrib["xmlns"]
        if key == "xmlns_xsi":
            if xmlns_xsi == None: xmlns_xsi=attrib["xmlns_xsi"]
        if key == "xsi_schemaLocation":
            if xsi_schemaLocation == None: xsi_schemaLocation=attrib["xmlns"]
    if FEWS:
        if xmlns == None:
            if tag in ["TimeSeries","MapStacks"]:
                attr+=' xmlns="http://www.wldelft.nl/fews/PI"'
            else:
                attr+=' xmlns="http://www.wldelft.nl/fews"'
        if xmlns_xsi == None: attr+=' xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"'
        if xsi_schemaLocation == None:
            dict_sl=dict([\
                ("Diag"                         ,"version1.0/pi-schemas/pi_diag.xsd"),\
                ("TimeSeries"                   ,"version1.0/pi-schemas/pi_timeseries.xsd"),\
                ("MapStacks"                    ,"version1.0/pi-schemas/pi_mapstacks.xsd"),\
                ("WhatIfScenarioEditor"         ,"version1.0/whatIfScenarioEditor.xsd"),\
                ("archiveRun"                   ,"version1.0/archiveRun.xsd"),\
                ("branches"                     ,"version1.0/branches.xsd"),\
                ("coldModuleInstanceStateGroups","version1.0/coldModuleInstanceStateGroups.xsd"),\
                ("displayDescriptors"           ,"version1.0/displayDescriptors.xsd"),\
                ("displayGroups"                ,"version1.0/displayGroups.xsd"),\
                ("displayInstanceDescriptors"   ,"version1.0/displayInstanceDescriptors.xsd"),\
                ("explorer"                     ,"version1.0/explorer.xsd"),\
                ("filters"                      ,"version1.0/filters.xsd"),\
                ("generalAdapterRun"            ,"version1.0/generalAdapterRun.xsd"),\
                ("gridDisplay"                  ,"version1.0/gridDisplay.xsd"),\
                ("grids"                        ,"version1.0/grids.xsd"),\
                ("idMap"                        ,"version1.0/idMap.xsd"),\
                ("interpolationSets"            ,"version1.0/interpolationSets.xsd"),\
                ("locationSets"                 ,"version1.0/locationSets.xsd"),\
                ("locations"                    ,"version1.0/locations.xsd"),\
                ("massBalance"                  ,"version1.0/massBalance.xsd"),\
                ("moduleDescriptors"            ,"version1.0/moduleDescriptors.xsd"),\
                ("moduleInstanceSets"           ,"version1.0/moduleInstanceSets.xsd"),\
                ("parameterGroups"              ,"version1.0/parameters.xsd"),\
                ("polygons"                     ,"version1.0/polygons.xsd"),\
                ("scadaDisplay"                 ,"version1.0/scadaDisplay.xsd"),\
                ("systemMonitorDisplay"         ,"version1.0/systemMonitorDisplay.xsd"),\
                ("taskRunDialog"                ,"version1.0/taskRunDialog.xsd"),\
                ("timeSeriesDisplay"            ,"version1.0/timeSeriesDisplay.xsd"),\
                ("transformationModule"         ,"version1.0/transformationModule.xsd"),\
                ("transformationSets"           ,"version1.0/transformationSets.xsd"),\
                ("workflow"                     ,"version1.0/workflow.xsd"),\
                ])
            for key in dict_sl:
                if tag == key:
                    if tag in ["Diag","MapStacks","TimeSeries"]:
                        attr+=' xsi:schemaLocation="http://www.wldelft.nl/fews/PI http://fews.wldelft.nl/schemas/%s"' %(dict_sl[key])
                    else:
                        attr+=' xsi:schemaLocation="http://www.wldelft.nl/fews http://fews.wldelft.nl/schemas/%s"' %(dict_sl[key])
                    break
        else:
            if xsi_schemaLocation[:7]=="version":
                attr+=' xsi:schemaLocation="http://www.wldelft.nl/fews http://fews.wldelft.nl/schemas/%s' %(xsi_schemaLocation)
            elif string.find(xsi_schemaLocation," ") == -1:
                attr+=' xsi:schemaLocation="http://www.wldelft.nl/fews %s' %(xsi_schemaLocation)
            else:
                attr+=' %s' %(xsi_schemaLocation)
            xsi_schemaLocation=None
    if xmlns != None: attr+=' xmlns="%s"' %(xmlns)
    if xmlns_xsi != None: attr+=' xmlns:xsi="%s"' %(xmlns_xsi)
    if xsi_schemaLocation != None: attr+=' xsi:schemaLocation="%s"' %(xsi_schemaLocation)
    for key in attrib:
        if key not in ["xmlns","xmlns_xsi","xsi_schemaLocation"]:
            if type(attrib[key]) == str:
                attr+=' %s="%s"' %(key,attrib[key])
            else:
                attr+=' %s=%s' %(key,attrib[key])

    return ET.fromstring('<%s%s></%s>' %(tag,attr,tag))

def write_xml(root,f_xml,strip_xmlns=True,def_xmlns=""):
    ## Indent and linebreak
    indent,linebreak="\t","\n"
    ## If def_xmlns not specified then try to set def_xmlns
    if string.find(root.tag,"}") != -1 and def_xmlns in ["",False]:
        def_xmlns=string.split(root.tag,"}")[0][1:]
    ## If strip_xmlns is False then check if all namespaces exist; if not then set def_xmlns as namespace, otherwise set strip_xmlns to True
    if not strip_xmlns:
        for e in root.iter():
            try:
                if string.find(e.tag,"}") == -1:
                    if def_xmlns not in ["",False]:
                        e.tag="{%s}%s" %(def_xmlns,e.tag)
                    else:
                        strip_xmlns=True
                        break
            except: pass
    ## If strip_xmlns is True then strip off all namespaces; set def_xmlns to root if namespace of root does not exist
    if strip_xmlns:
        started=False
        for e in root.iter():
            if started:
                try: e.tag=string.split(e.tag,"}")[-1]
                except: pass
            started=True
        if string.find(root.tag,"}") == -1 and def_xmlns not in ["",False]:
            root.tag="{%s}%s" %(def_xmlns,root.tag)
    ## Make xml string
    s=xml.dom.minidom.parseString(ET.tostring(root)).toprettyxml(indent=indent,newl=linebreak,encoding="UTF-8")
    ## If strip_xmlns is True then remove any namespace declarations
    if strip_xmlns:
        i=0
        while True:
            if string.find(s,"ns%d:" %(i)) == -1 and string.find(s,":ns%d=" %(i)) == -1: break
            s=string.replace(s,"ns%d:" %(i),"")
            s=string.replace(s,":ns%d=" %(i),"=")
            i+=1
    ## Remove trailing spaces
    while True:
        if string.find(s," \n") == -1: break
        s=string.replace(s," \n","\n")
    ## Remove empty lines
    while True:
        if string.find(s,"%s\n" %(indent)) == -1: break
        s=string.replace(s,"%s\n" %(indent),"\n")
    while True:
        if string.find(s,"\n\n") == -1: break
        s=string.replace(s,"\n\n","\n")
    ## Replace &amp; with &
    s=string.replace(s,"&amp;","&")
    ## Write xml file
    outf=open(f_xml,"w"); outf.write(s); outf.close()

def add_comment(element,comment=" ",index=None):
    if index == None:
        index=len(list(element))
    element.insert(index,ET.Comment(comment))

def comment_subelement(root_element,tag,index=0):
    i,j=-1,0
    for e in root_element.iter():
        if e.tag == tag:
            if j == index:
                comment=ET.Comment(ET.tostring(e))
                root_element.remove(e)
                root_element.insert(i,comment)
                break
            j+=1
        i+=1

def uncomment_subelement(root_element,tag,index=0):
    i,j=-1,0
    for e in root_element.iter():
        if ET.tostring(e)[:4] == "<!--":
            comment=string.strip(string.strip(ET.tostring(e))[4:-3])
            if comment[:1+len(tag)] == "<%s" %(tag):
                if j == index:
                    root_element.remove(e)
                    root_element.insert(i,ET.fromstring(comment))
                    break
                j+=1
        i+=1
