## TIMING FUNCTIONS ##

## IMPORTING MODULES ##

try:
    from general_func import *
    import datetime
except:
    pass


## FUNCTIONS ##

def sec2time(sec,num=-1):
    sec=float(sec)
    numismax=0
    if num in [None,"",0]:
        num=5; numismax=1
    else:
        if num > 0:
            numismax=1
        num=max(1,int(abs(num)))
    years,days,hours,minutes,seconds=0,0,0,0,0
    nsec_m=60; nsec_h=nsec_m*60; nsec_d=nsec_h*24; nsec_y=nsec_d*365
    nsec_list=[nsec_y,nsec_d,nsec_h,nsec_m]
    time_list=[0,0,0,0,0]
    text_list=["y","d","","",""]
    format_list=["%d","%03d","%02d","%02d","%02d"]
    for i in range(0,len(nsec_list)):
        if sec/nsec_list[i] >= 1:
            time_list[i]=int(sec/nsec_list[i]); sec=sec-time_list[i]*nsec_list[i]
    time_list[-1]=sec
    timestr,x="",0
    for i in range(0,len(time_list)):
        if not x:
            if numismax and i >= len(time_list)-num and time_list[i] != 0:
                x=1
            elif not numismax and (time_list[i] != 0 or i >= len(time_list)-num):
                x=1
        if x:
            timestr=timestr+"%s%%s:" %(format_list[i]) %(time_list[i],text_list[i])
    return timestr[:-1]

def tt2age(tt):
    daysinyear=365.2425
    dimt=1
    if type(tt[0]) in [bool,int,long,float,bool_,uint8,uint16,uint32,uint64,int8,int16,int32,int64,float16,float32,float64]:
        tt=[tt]; dimt=0
    islist=False
    if type(tt) in [list,tuple]:
        islist=True
    tt=array(tt,uint16)
    age=zeros((len(tt)),float32)
    for t in range(0,len(tt)):
        diff=((tt[t,0]-1971)/10)*10
        ttage=(tt[t,0]-diff,tt[t,1],max(1,tt[t,2]),0,0,0,0,0,0)
        age[t]=-diff-20-(time.mktime(ttage)/3600-2)/(24*daysinyear)
    if islist:
        age=age.tolist()
    if dimt == 0:
        age=age[0]
    return age

def age2tt(age):
    daysinyear=365.2425
    dimt=1
    if type(age) in [bool,int,long,float,bool_,uint8,uint16,uint32,uint64,int8,int16,int32,int64,float16,float32,float64]:
        age=[age]; dimt=0
    islist=False
    if type(age) in [list,tuple]:
        islist=True
    age=array(age,float32)
    tt=zeros((len(age),3),uint16)
    for t in range(0,len(age)):
        a=((age+20)*(-24*daysinyear)+2)*3600
        diff=int(a/(3600*24*daysinyear))-1
        tt[t]=array(time.localtime(a-diff*(3600*24*daysinyear)+12*3600)[:3],uint16); tt[t,0]=tt[t,0]+diff
    if islist:
        tt=tt.tolist()
    if dimt == 0:
        tt=tt[0]
    return tt

def tt2yrtime(tt):
    dimt=1
    if type(tt[0]) in [bool,int,long,float,bool_,uint8,uint16,uint32,uint64,int8,int16,int32,int64,float16,float32,float64]:
        tt=[tt]; dimt=0
    islist=False
    if type(tt) in [list,tuple]:
        islist=True
    tt=array(tt,uint16)
    yrtime=-tt2age(tt)+1950
    if islist:
        yrtime=yrtime.tolist()
    if dimt == 0:
        yrtime=yrtime[0]
    return yrtime

def isleap(tt,isdateYYYYMMDD=False):
    dimt,islist=1,False
    if isdateYYYYMMDD:
        if type(tt) in [str,bool,int,long,float,string_,bool_,uint8,uint16,uint32,uint64,int8,int16,int32,int64,float16,float32,float64]: tt,dimt=[tt],0
    else:
        if type(tt) in [bool,int,long,float,bool_,uint8,uint16,uint32,uint64,int8,int16,int32,int64,float16,float32,float64]: tt,dimt=[[int(tt),1,1]],0
        elif type(tt[0]) in [bool,int,long,float,bool_,uint8,uint16,uint32,uint64,int8,int16,int32,int64,float16,float32,float64]: tt,dimt=[tt],0
    if type(tt) in [list,tuple]: islist=True
    if isdateYYYYMMDD: tt=array(array(tt,uint32)/10000,uint16)
    else: tt=array(swapaxes(swapaxes(tt,0,-1)[0],0,-1),uint16)
    leap=array(where(remainder(tt,100) == 0,where(remainder(tt,400) == 0,1,0),where(remainder(tt,4) == 0,1,0)),uint8)
    if islist: leap=leap.tolist()
    if dimt == 0: leap=leap[0]
    return leap

def month2dayduration(year,month):
    year,month=int(year),int(month)
    monthduration=[[0,[[1,31],[2,28],[3,31],[4,30],[5,31],[6,30],[7,31],[8,31],[9,30],[10,31],[11,30],[12,31]]],\
                   [1,[[1,31],[2,29],[3,31],[4,30],[5,31],[6,30],[7,31],[8,31],[9,30],[10,31],[11,30],[12,31]]]]
    i=0
    if not bool(year%100):
        if not bool(year%400): i=1
    elif not bool(year%4): i=1
    return lookup(month,lookup(i,monthduration),30)

def maandduur(jaar,schrikkel,jaarlen):
    md,md0=[],[]
    for i in range(0,12):
        md0.append(float(month2dayduration(jaar,i+1)))
    if not schrikkel:
        md0[1]=28.0
    elif schrikkel and md0[1] == 29:
        jaarlen=float(jaarlen)*(366.0/365.0)
    fac=float(jaarlen)/float(sum(md0))
    for m in md0:
        md.append(m*fac)
    return md,fac

# Estimates the duration in days of the given months
def tt2dayduration(tt):
    dimt=1
    if type(tt[0]) in [bool,int,long,float,bool_,uint8,uint16,uint32,uint64,int8,int16,int32,int64,float16,float32,float64]:
        tt=[tt]; dimt=0
    islist=False
    if type(tt) in [list,tuple]:
        islist=True
    tt=array(tt,uint16)
    tt=swapaxes(tt,0,-1)
    leap=array(where(remainder(tt[0],100) == 0,where(remainder(tt[0],400) == 0,1,0),where(remainder(tt[0],4) == 0,1,0)),uint8)
    monthduration=[[[1,31],[2,28],[3,31],[4,30],[5,31],[6,30],[7,31],[8,31],[9,30],[10,31],[11,30],[12,31]],\
                   [[1,31],[2,29],[3,31],[4,30],[5,31],[6,30],[7,31],[8,31],[9,30],[10,31],[11,30],[12,31]]]
    daydur=ones((tt.shape[1:]),uint8)*30
    for m in range(0,12):
        for l in range(0,2):
            daydur=where(leap == l,where(tt[1] == m+1,monthduration[l][m][1],daydur),daydur)
    daydur=swapaxes(daydur,0,-1)
    if islist:
        daydur=daydur.tolist()
    if dimt == 0:
        daydur=daydur[0]
    return daydur

def periodsec(tt1,tt2,dst=0,neg=False):
    tt1,tt2=tuple(tt1)+(0,)*(9-len(tt1)),tuple(tt2)+(0,)*(9-len(tt2))
    if dst in [0,None]:
        if neg:
            return int(time.mktime(tt2)-time.mktime(tt1))
        else:
            return abs(int(time.mktime(tt2)-time.mktime(tt1)))
    else:
        if neg:
            return int(time.mktime(time.strptime("%d-%d-%d %d:%d" %tt2[:5],"%Y-%m-%d %H:%M"))-time.mktime(time.strptime("%d-%d-%d %d:%d" %tt1[:5],"%Y-%m-%d %H:%M")))
        else:
            return abs(int(time.mktime(time.strptime("%d-%d-%d %d:%d" %tt2[:5],"%Y-%m-%d %H:%M"))-time.mktime(time.strptime("%d-%d-%d %d:%d" %tt1[:5],"%Y-%m-%d %H:%M"))))

def periodday(tt1,tt2,dateformat=None,neg=False):
    if dateformat != None:
        tt1,tt2=date2tt(tt1,dateformat),date2tt(tt2,dateformat)
##    if array(tt1).ndim == 2:
##        return array([int(around(periodsec(tt1[t],tt2[t],neg=neg)/(24.*3600))) for t in range(0,len(tt1))],int32)
##    else:
##        return int(around(periodsec(tt1,tt2,neg=neg)/(24.*3600)))
    if array(tt1).ndim == 2:
        if neg:
            return array([(datetime.date(tt2[t][0],tt2[t][1],tt2[t][2])-datetime.date(tt1[t][0],tt1[t][1],tt1[t][2])).days for t in range(0,len(tt1))],int32)
        else:
            return array([abs((datetime.date(tt2[t][0],tt2[t][1],tt2[t][2])-datetime.date(tt1[t][0],tt1[t][1],tt1[t][2])).days) for t in range(0,len(tt1))],int32)
    else:
        if neg:
            return int((datetime.date(tt2[0],tt2[1],tt2[2])-datetime.date(tt1[0],tt1[1],tt1[2])).days)
        else:
            return abs(int((datetime.date(tt2[0],tt2[1],tt2[2])-datetime.date(tt1[0],tt1[1],tt1[2])).days))

def add2tt(tt,addsec):
    dimt=1
    if type(tt[0]) in [bool,int,long,float,bool_,uint8,uint16,uint32,uint64,int8,int16,int32,int64,float16,float32,float64]:
        tt=[tt]; dimt=0
    islist=False
    if type(tt) in [list,tuple]:
        islist=True
    if type(addsec) in [bool,int,long,float,bool_,uint8,uint16,uint32,uint64,int8,int16,int32,int64,float16,float32,float64]:
        addsec=[addsec]
    tt=array(tt,int32)
    addsec=array(addsec,int64)
    if len(tt) == 1 and len(addsec) > 1:
        tt=repeat(tt,len(addsec),0); dimt=1
    if len(addsec) == 1 and len(tt) > 1:
        addsec=repeat(addsec,len(tt))
    tt=tt[:min(len(tt),len(addsec))]; addsec=addsec[:min(len(tt),len(addsec))]
    lentt=len(tt[0])
    for i in range(0,len(tt)):
        tt0=list(tt[i])+[0]*(7-len(tt[i]))
        try:
            tt[i,:min(lentt,8)]=array((datetime.datetime(tt0[0],tt0[1],tt0[2],tt0[3],tt0[4],tt0[5],tt0[6])+datetime.timedelta(seconds=int(addsec[i]))).timetuple()[:min(lentt,8)])
        except:
            pass
    tt=array(tt,uint16)
    if islist:
        tt=tt.tolist()
    if dimt == 0:
        tt=tt[0]
    return tt

def addday2tt(tt,d):
    dimt=1
    if type(tt[0]) in [bool,int,long,float,bool_,uint8,uint16,uint32,uint64,int8,int16,int32,int64,float16,float32,float64]:
        tt=[tt]; dimt=0
    islist=False
    if type(tt) in [list,tuple]:
        islist=True
    tt=array(tt,int32)
    dd=ones(len(tt),int32)*d
    tt[:,2]=tt[:,2]+dd.copy()
    if d > 0:
        while 1:
            daydur=tt2dayduration(tt)
            if where(tt[:,2] > daydur,1,0).sum() == 0: break
            tt[:,1]=where(tt[:,2] > daydur,tt[:,1]+1,tt[:,1])
            tt[:,0]=where(tt[:,1] == 13,tt[:,0]+1,tt[:,0])
            tt[:,1]=where(tt[:,1] == 13,1,tt[:,1])
            tt[:,2]=where(tt[:,2] > daydur,tt[:,2]-daydur.copy(),tt[:,2])
    else:
        while 1:
            if where(tt[:,2] < 1,1,0).sum() == 0: break
            tt[:,1]=where(tt[:,2] < 1,tt[:,1]-1,tt[:,1])
            tt[:,0]=where(tt[:,1] < 1,tt[:,0]-1,tt[:,0])
            tt[:,1]=where(tt[:,1] < 1,12,tt[:,1])
            daydur=tt2dayduration(tt)
            tt[:,2]=where(tt[:,2] < 1,daydur.copy()+tt[:,2],tt[:,2])
    tt=array(tt,uint16)
    if islist:
        tt=tt.tolist()
    if dimt == 0:
        tt=tt[0]
    return tt

def date2tt(date,format="yyyymmdd"):
    dimd=1
    if type(date) in [str,bool,int,long,float,string_,bool_,uint8,uint16,uint32,uint64,int8,int16,int32,int64,float16,float32,float64]:
        dimd=0; date=[date]
    islist=False
    if type(date) in [list,tuple]:
        islist=True
    tt=None
    format=string.lower(format)
    if format == "yyyymmdd":
        try:
            datelist=array(date,uint32)
            tt=array(concatenate([reshape(datelist/10000,datelist.shape+(1,)),\
                                  reshape(remainder(datelist,10000)/100,datelist.shape+(1,)),\
                                  reshape(remainder(datelist,100),datelist.shape+(1,))],-1),int16)
            upper=array(tt2dayduration(tt),int8)
            tt=swapaxes(tt,0,-1)
            tt[-2]=where(tt[-2] < 1,-1,where(tt[-2] > 12,-1,tt[-2]))
            upper=where(tt[-2] == -1,31,where(tt[-3] == -1,where(tt[-2] == 2,29,upper),upper))
            tt[-1]=where(tt[-1] < 1,-1,where(tt[-1] > upper,-1,tt[-1]))
            tt=swapaxes(tt,0,-1)
        except:
            datelist=deepcopy(date)
    else:
        datelist=deepcopy(date)
    if type(tt) == type(None):
        tt=zeros((len(datelist),3),uint16)
        mntxt=["jan","feb","mrt","apr","mei","jun","jul","aug","sep","okt","nov","dec","mar","may","oct"]
        mnnum=[1,2,3,4,5,6,7,8,9,10,11,12,3,5,10]
        for t in range(0,len(datelist)):
            date=str(datelist[t])
            if "mmm" not in format:
                format=string.replace(format,"yyyy","%Y")
                format=string.replace(format,"yy","%y")
                format=string.replace(format,"mm","%m")
                format=string.replace(format,"m","%m")
                format=string.replace(format,"dd","%d")
                format=string.replace(format,"d","%d")
                format=string.replace(format,"%%","%")
                yr,mn,day=time.strptime(date,format)[:3]
            else:
                yr,mn,day=-1,-1,-1
                for testyr in ["yyyy","yy"]:
                    i=string.find(format,testyr)
                    if i != -1:
                        try:
                            yr=int(date[i:i+len(testyr)])
                            break
                        except:
                            pass
                if yr < 0:
                    yr=-1
                for testmn in ["mmm","mm","m"]:
                    i=string.find(format,testmn)
                    if i != -1:
                        try:
                            if testmn == "mmm":
                                mn=string.lower(date[i:i+len(testmn)])
                                mn=mnnum[mntxt.index(mn)]
                            elif testmn == "m":
                                try:
                                    mn=int(date[i:i+2])
                                    if mn not in range(10,13):
                                        mn=int(date[i:i+1])
                                    else:
                                        format=string.replace(format,"m","mm",1)
                                except:
                                    mn=int(date[i:i+1])
                            else:
                                mn=int(date[i:i+len(testmn)])
                            break
                        except:
                            pass
                if mn not in range(1,13):
                    mn=-1
                for testday in ["dd","d"]:
                    i=string.find(format,testday)
                    if i != -1:
                        try:
                            if testday == "d":
                                try:
                                    day=int(date[i:i+2])
                                    if mn == -1:
                                        upper=31
                                    elif yr == -1 and mn == 2:
                                        upper=29
                                    else:
                                        upper=tt2dayduration([yr,mn,1])
                                    if day not in range(10,upper+1):
                                        day=int(date[i:i+1])
                                except:
                                    day=int(date[i:i+1])
                            else:
                                day=int(date[i:i+len(testday)])
                            break
                        except:
                            pass
                if mn == -1:
                    upper=31
                elif yr == -1 and mn == 2:
                    upper=29
                else:
                    upper=tt2dayduration([yr,mn,1])
                if day not in range(1,upper+1):
                    day=-1
            tt[t]=array([yr,mn,day],uint16)
    if islist:
        tt=tt.tolist()
    if dimd == 0:
        tt=tt[0]
    return tt

def tt2date(tt,format="yyyymmdd"):
    dimt=1
    if type(tt[0]) in [bool,int,long,float,bool_,uint8,uint16,uint32,uint64,int8,int16,int32,int64,float16,float32,float64]:
        tt=[tt]; dimt=0
    format=string.replace(format,"Mmmm","nnnn")
    format=string.replace(format,"Mmm","nnn")
    format=string.lower(format)
    for x,y in [["yyyy","q101"],["yy","q102"],["mmmm","q11"],["nnnn","q12"],["mmm","q13"],["nnn","q14"],["mm","q15"],["m","q16"],["dd","q1"],["d","q2"]]:
        format=string.replace(format,x,y)
    islist=True
    datelist=None
    if format == "q101q15q1":
        try:
            tt.shape; islist=False
        except:
            pass
        try:
            tt=array(tt,uint32)
            tt=swapaxes(tt,0,-1)
            datelist=tt[0]*10000+tt[1]*100+tt[2]
            datelist=swapaxes(datelist,0,-1)
            if islist:
                datelist=array(datelist,dtype="a8").tolist()
        except:
            pass
    if type(datelist) == type(None):
        datelist=[]
        for t in range(0,len(tt)):
            tt0=tt[t][:3]
            date=format
            for testyr in ["q101","q102"]:
                try:
                    yr=("%%0%dd" %(len(testyr)) %(int(tt0[0])))[-len(testyr):]
                    date=string.replace(date,testyr,yr)
                except:
                    pass
            for testmn in ["q11","q12","q13","q14","q15","q16"]:
                try:
                    if testmn == "q11":
                        mn=["januari","februari","maart","april","mei","juni","juli","augustus","september","oktober","november","december"][int(tt0[1])-1]
                    elif testmn == "q12":
                        mn=["January","February","March","April","May","June","July","August","September","October","November","December"][int(tt0[1])-1]
                    elif testmn == "q13":
                        mn=["jan","feb","mrt","apr","mei","jun","jul","aug","sep","okt","nov","dec"][int(tt0[1])-1]
                    elif testmn == "q14":
                        mn=["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"][int(tt0[1])-1]
                    else:
                        mn=("%%0%dd" %(len(testmn)) %(int(tt0[1])))
                        if testmn == "q15" or (testmn == "q16" and tt0[1] >= 10):
                            mn=mn[-2:]
                        else:
                            mn=mn[-1:]
                    date=string.replace(date,testmn,mn)
                except:
                    pass
            for testday in ["q1","q2"]:
                try:
                    day=("%%0%dd" %(len(testday)) %(int(tt0[2])))
                    if testday == "q1" or (testday == "q2" and tt0[2] >= 10):
                        day=day[-2:]
                    else:
                        day=day[-1:]
                    date=string.replace(date,testday,day)
                except:
                    pass
            datelist.append(date)
    if dimt == 0:
        datelist=datelist[0]
    return datelist

def tt2daynum(tt,schrikkel=False):
    dimt=1
    if type(tt[0]) in [bool,int,long,float,bool_,uint8,uint16,uint32,uint64,int8,int16,int32,int64,float16,float32,float64]:
        tt=[tt]; dimt=0
    islist=False
    if type(tt) in [list,tuple]:
        islist=True
    tt=array(tt,uint16)
    daynum=zeros((len(tt)),uint16)
    for mn in range(1,tt[:,1].max()):
        daynum=where(tt[:,1] > mn,daynum+tt2dayduration(concatenate([tt[:,0:1],ones((len(tt),1),uint16)*mn],1)),daynum)
    daynum=daynum+tt[:,2].copy()
    leap=zeros((len(tt)),uint8)
    isfeb29=array(where(tt[:,1] == 2,where(tt[:,2] == 29,1,0),0),uint8)
    febdur=tt2dayduration(concatenate([tt[:,0:1],ones((len(tt),1),uint16)*2],1))
    if not schrikkel:
        leap=array(where(isfeb29 == 1,1,where(tt[:,1] > 2,where(febdur == 29,1,leap),leap)),uint8)
    leap=where(febdur == 28,isfeb29.copy(),leap)
    daynum=daynum-leap
    if islist:
        daynum=daynum.tolist()
    if dimt == 0:
        daynum=daynum[0]
    return daynum

def daynum2tt(daynum,schrikkel=False):
    dimt=1
    if type(daynum) in [bool,int,long,float,bool_,uint8,uint16,uint32,uint64,int8,int16,int32,int64,float16,float32,float64]:
        daynum=[daynum]; dimt=0
    islist=False
    if type(daynum) in [list,tuple]:
        islist=True
    daynum=array(daynum,uint16)
    try:
        if schrikkel == None: schrikkel=0
    except: pass
    if type(schrikkel) in [bool,int,long,float,bool_,uint8,uint16,uint32,uint64,int8,int16,int32,int64,float16,float32,float64]:
        schrikkel=[schrikkel]*len(daynum)
    try:
        if len(schrikkel) != len(daynum):
            schrikkel=[schrikkel[0]]*len(daynum)
        else:
            for i in range(0,len(schrikkel)):
                if schrikkel[i] in [None,False]: schrikkel[i]=0
                elif schrikkel[i] in [True]: schrikkel[i]=1
                else: schrikkel[i]=int(schrikkel[i])
    except:
        schrikkel=[0]*len(daynum)
    schrikkel=array(schrikkel,uint16)
    yr=schrikkel.copy(); yr=where(yr > 1000,yr,0)
    schrikkel=array(where(schrikkel > 1000,isleap(sublist([schrikkel.tolist(),[1]*len(daynum),[1]*len(daynum)])),schrikkel),bool)
    feb29=where(schrikkel == 1,where(daynum == 60,1,0),0)
    daynum=where(schrikkel == 1,where(daynum >= 60,daynum-1,daynum),daynum)
    tt=zeros((len(daynum),3),uint16); tt[:,0]=yr; tt[:,1]=1
    mndur=[31,28,31,30,31,30,31,31,30,31,30,31]
    for mn in range(0,len(mndur)):
        tt[:,1]=where(daynum > mndur[mn],tt[:,1]+1,tt[:,1])
        tt[:,2]=where(daynum <= mndur[mn],where(tt[:,2] == 0,daynum,tt[:,2]),tt[:,2])
        daynum=where(daynum >= mndur[mn],daynum-mndur[mn],0)
    tt[:,2]=tt[:,2]+feb29.copy()
    tt=array(tt,uint16)
    if islist:
        tt=tt.tolist()
    if dimt == 0:
        tt=tt[0]
    return tt

def tt2excelday(tt,date1904=False):
    dimt=1
    if type(tt[0]) in [bool,int,long,float,bool_,uint8,uint16,uint32,uint64,int8,int16,int32,int64,float16,float32,float64]:
        tt=[tt]; dimt=0
    islist=False
    if type(tt) in [list,tuple]:
        islist=True
    tt=array(tt,uint16)
    dn=tt2daynum(tt,True); dn=where(tt[:,0] == 1900,where(dn > 59,dn+1,dn),dn)
    minyr,maxyr=min(1900,tt[:,0].min()),max(1900,tt[:,0].max()); nyr=maxyr-minyr+1
    tt2=ones((nyr,3),uint16); tt2[:,0]=ravel(arange(minyr,maxyr+1,dtype=uint16))
    i1900=compress(where(tt2[:,0] == 1900,1,0),indices((len(tt2),))[0],0)[0]
    il=isleap(tt2); il[i1900]=1
    ndayyr=array(il,uint16)+365
    startday=add.accumulate(concatenate([[0],array(ndayyr[:-1],int32)])); startday=startday-startday[i1900]
    exday=startday[tt[:,0]-minyr]+dn
    if date1904: exday=exday-1462
    if islist:
        exday=exday.tolist()
    if dimt == 0:
        exday=exday[0]
    return exday

def excelday2tt(exday,date1904=0):
    dimt=1
    if type(exday) in [bool,int,long,float,bool_,uint8,uint16,uint32,uint64,int8,int16,int32,int64,float16,float32,float64]:
        exday=[exday]; dimt=0
    islist=False
    if type(exday) in [list,tuple]:
        islist=True
    exday=array(exday,int32)
    if date1904:
        exday=exday+1462
    exday=where(exday >= 60,exday-1,exday)
    exday=exday-1
    tt=array(concatenate([ones((len(exday),1))*1900,ones((len(exday),1)),ones((len(exday),1))],1),uint16)
    for t in range(0,len(exday)):
        if exday[t] >= 0:
            while 1:
                yrdur=337+tt2dayduration([tt[t,0],2,1])
                if yrdur > exday[t]:
                    break
                tt[t,0]=tt[t,0]+1
                exday[t]=exday[t]-yrdur
        else:
            while 1:
                yrdur=337+tt2dayduration([tt[t,0]-1,2,1])
                tt[t,0]=tt[t,0]-1
                exday[t]=exday[t]+yrdur
                if exday[t] > 0:
                    break
        while 1:
            mndur=tt2dayduration([tt[t,0],tt[t,1],1])
            if mndur > exday[t]:
                break
            tt[t,1]=tt[t,1]+1
            exday[t]=exday[t]-mndur
        tt[t,2]=tt[t,2]+exday[t]
    if islist:
        tt=tt.tolist()
    if dimt == 0:
        tt=tt[0]
    return tt

def ttwindow(tt,dayl=[14,28],windowsize=4,include_all=False):
    tt=array(tt,uint16)
    if include_all:
        used=zeros((len(tt),1),uint8)
        for d in dayl:
            used=array(where(tt[:,2:] == d,1,used),uint8)
        for dd in range(1,windowsize+1):
            tt0=addday2tt(tt,dd)
            for d in dayl:
                tt=where(tt0[:,2:] == d,where(used == 0,tt0,tt),tt)
                used=array(where(tt0[:,2:] == d,1,used),uint8)
            tt0=addday2tt(tt,-dd)
            for d in dayl:
                tt=where(tt0[:,2:] == d,where(used == 0,tt0,tt),tt)
                used=array(where(tt0[:,2:] == d,1,used),uint8)
        tt=where(used == 1,tt,0)
    else:
        datearr=tt2date(tt).tolist()
        endyr,startyr=tt[-1,0],tt[0,0]
        tt0=zeros(((endyr-startyr+1)*12*len(dayl),3),uint16)
        tt0[:,0]=repeat(arange(startyr,endyr+1,dtype=uint16),12*len(dayl),0)
        tt0[:,1]=resize(repeat(arange(1,13,dtype=uint16),len(dayl),0),len(tt0))
        tt0[:,2]=resize(array(dayl,uint16),len(tt0))
        used=ones((len(tt0)),int32)*-1
        tti=arange(0,len(tt0),dtype=uint32)
        for dd in range(0,windowsize+1):
            if used.min() >= 0: break
            datearr0=tt2date(addday2tt(tt0,dd))
            for i in compress(where(used < 0,1,0),tti,0).tolist():
                try:
                    ifound=datearr.index(datearr0[i])
                    used[i]=ifound
                except:
                    pass
            if dd > 0:
                datearr0=tt2date(addday2tt(tt0,-dd))
                for i in compress(where(used < 0,1,0),tti,0).tolist():
                    try:
                        ifound=datearr.index(datearr0[i])
                        used[i]=ifound
                    except:
                        pass
        comparr=where(used < 0,0,1)
        used,tti=compress(comparr,used,0),compress(comparr,tti,0)
        tt=zeros(tt.shape,uint16)
        for i in range(0,len(used)):
            tt[used[i]]=tt0[tti[i]]
    return tt

def timeselectdata(timearr,dataarr,start=19500101,end=20501231):
    datearr=tt2date(array(timearr,uint16))
    start,end=int(start),int(end)
    comparr=where(datearr >= start,where(datearr <= end,1,0),0)
    return compress(comparr,timearr,0),compress(comparr,dataarr,0)

def startend2tt(start,end):
    try: start=int(start)
    except: pass
    try: end=int(end)
    except: pass
    if type(start) in [long,int,str,float]:
        try: start=array(date2tt(int(start)),uint16)
        except: return array([],uint16)
    else:
        try: start=array(start,uint16)
        except: return array([],uint16)
    if type(end) in [long,int,str,float]:
        try: end=array(date2tt(int(end)),uint16)
        except: return array([],uint16)
    else:
        try: end=array(end,uint16)
        except: return array([],uint16)
    if tt2date(start) > tt2date(end): return array([],uint16)
    nday=(datetime.datetime(end[0],end[1],end[2])-datetime.datetime(start[0],start[1],start[2])).days+1
    ttl=add2tt(start,arange(0,nday,dtype=int64)*3600*24)
    return array(ttl,uint16)

def syncdata(ttl,datl,int_intexp_expand=0,nodata=-9999):
    # int_intexp_expand:
    #   0 = intersect (max start and min end of all datasets); remove date if not present in one or more datasets
    #   1 = intersect (max start and min end of all datasets); fill missing records with nodata
    #   2 = expand    (min start and max end of all datasets); fill missing records with nodata
    #   3 = start and end of first dataset;                    fill missing records with nodata
    #  <0 = expand    (min start and max end of all datasets); remove date if nodata occurs in one or more datasets
    ioe=int_intexp_expand
    datel=[]
    for i in range(0,len(ttl)):
        datel.append(tt2date(array(ttl[i],uint16)))
        sortarr=argsort(datel[-1],0)
        if len(datl[i]) == len(ttl[i]): datl[i]=take(datl[i],sortarr,0).copy()
        else: pass
        datel[-1]=sort(datel[-1])
    start,end=datel[0][0],datel[0][-1]
    for i in range(1,len(ttl)):
        if ioe in [0,1]: start,end=max(start,datel[i][0]),min(end,datel[i][-1])
        elif ioe != 3: start,end=min(start,datel[i][0]),max(end,datel[i][-1])
        else: ioe=2
    ttlnew,datlnew=[],[]
    tt=array(startend2tt(start,end),uint16)
    date=tt2date(tt)
    for i in range(0,len(ttl)): ttlnew.append(tt)
    if start > end:
        for i in range(0,len(ttl)): datlnew.append(array([],datl[i].dtype.name))
    else:
        if ioe <= 0: comparr=zeros((len(tt)),int16)
        ndat=0
        for i in range(0,len(ttl)):
            if len(datl[i]) == len(ttl[i]):
                ndat=ndat+1
                valarr=ones((len(tt),)+datl[i].shape[1:],datl[i].dtype.name)*nodata
                ii=0
                for j in range(0,len(datel[i])):
                    for k in range(ii,len(date)):
                        if date[k] == datel[i][j]:
                            valarr[k]=datl[i][j]; ii=k
                            if ioe <= 0: comparr[k]=comparr[k]+1
                            if ioe < 0:
                                try:
                                    if valarr[k] == nodata: comparr[k]=comparr[k]-1
                                except:
                                    for l in range(0,len(valarr[k])):
                                        if valarr[k][l] == nodata:
                                            comparr[k]=comparr[k]-1; break
                            break
                datlnew.append(valarr.copy())
            else:
                datlnew.append(None)
        if ioe <= 0:
            comparr=where(comparr == ndat,1,0)
            for i in range(0,len(ttl)):
                ttlnew[i]=compress(comparr,ttlnew[i],0)
                try: datlnew[i]=compress(comparr,datlnew[i],0)
                except: pass
    return ttlnew,datlnew

