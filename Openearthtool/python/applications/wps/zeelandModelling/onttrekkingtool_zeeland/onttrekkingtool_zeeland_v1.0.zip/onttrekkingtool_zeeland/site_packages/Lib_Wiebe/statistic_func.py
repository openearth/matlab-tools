## STATISTIC FUNCTIONS ##

## IMPORTING MODULES ##

try:
    from general_func import *
    from scipy.stats import hmean
    import numpy.ma as MA
except:
    pass


# Calculates the average and standard deviation (and min, max, number) of the lowest dimension of a multi-dimensional list or array of numbers
#   l = list or array
#   minmaxnum = flag to return min, max and number; default: False
#   nodata = nodata value; default: -9999
def avg_stdev(l,minmaxnum=False,nodata=-9999):
    avg,stdev,minval,maxval,num=nodata,nodata,nodata,nodata,nodata
    type0=type(l)
    if type0 in [complex,bool,int,long,float,bool_,uint8,uint16,uint32,uint64,int8,int16,int32,int64,float16,float32,float64]:
        avg,minval,maxval,num=l,l,l,1
    else:
        try:
            l=array(l,float32)
        except:
            pass
        if type(l) in [list,tuple]:
            avg,stdev,minval,maxval,num=[],[],[],[],[]
            for l0 in walklist(l):
                avg0,stdev0,minval0,maxval0,num0=nodata,nodata,nodata,nodata,nodata
                N=len(l0)
                if N >= 1:
                    avg0=float(sum(l0))/len(l0)
                    if N > 1:
                        xsum=0.0
                        for x in l0:
                            xsum=xsum+(float(x)-avg0)**2
                        stdev0=math.sqrt(xsum/(len(l0)-1))
                    if minmaxnum:
                        minval0,maxval0,num0=min(l0),max(l0),N
                if minmaxnum:
                    avg,stdev,minval,maxval,num=add2lists([avg0,stdev0,minval0,maxval0,num0],[avg,stdev,minval,maxval,num])
                else:
                    avg,stdev=add2lists([avg0,stdev0],[avg,stdev])
        else:
            N=l.shape[-1]
            if N >= 1:
                avg=l.mean(-1)
                if N > 1:
                    stdev=l.std(-1)
                else:
                    if type(avg) in [complex,bool,int,long,float,bool_,uint8,uint16,uint32,uint64,int8,int16,int32,int64,float16,float32,float64]:
                        stdev=nodata
                    else:
                        stdev=ones(avg.shape,float32)*nodata
                if minmaxnum:
                    minval,maxval=l.min(-1),l.max(-1)
                    if type(avg) in [complex,bool,int,long,float,bool_,uint8,uint16,uint32,uint64,int8,int16,int32,int64,float16,float32,float64]:
                        num=N
                    else:
                        num=ones(avg.shape,uint32)*N
                if type0 in [list,tuple] and type(avg) not in [complex,bool,int,long,float,bool_,uint8,uint16,uint32,uint64,int8,int16,int32,int64,float16,float32,float64]:
                    avg,stdev=avg.tolist(),stdev.tolist()
                    if minmaxnum:
                        minval,maxval,num=minval.tolist(),maxval.tolist(),num.tolist()
    if minmaxnum:
        return avg,stdev,minval,maxval,num
    else:
        return avg,stdev

# Calculates harmonic mean along the specified axis
def harm_mean(arr,axis=-1,nodata=-9999):
    arr0=sum(array(maximum(arr <= 0,arr == nodata),min_scalar_type(arr.shape[axis])),axis)
    arr=where(maximum(arr <= 0,arr == nodata),1,arr)
    return where(arr0 != 0,nodata,hmean(arr,axis))

# Calculates covariance matrix of a 2-D array (variables in columns)
def covariance(x):
    n=x.shape[0]; xm=sum(x)/n; ex=x-xm
    return dot(transpose(ex),ex)/(n-1)

# Calculates variance of a 2-D array (variables in columns)
def variance(x):
    return diagonal(covariance(x))

def correl(x):
    n=x.shape[0]
    cov=covariance(x)
    std=diagonal(cov)**0.5; std=dot(transpose([std]),[std]); std=where(std <= 0,-1,std)
    correl=(covariance(x)/std)*(n/(n-1)); correl=where(std == -1,0,correl)
    for i in range(0,len(correl)): correl[i,i]=1
    return correl

# Calculates Student's t and degrees of freedom from two sets of numbers
def ttest(setl):
    for i in range(0,len(setl)): setl[i]=ravel(array(setl[i],float32))
    gn=[len(setl[0]),len(setl[1])]; gavg=[setl[0].sum()/gn[0],setl[1].sum()/gn[1]]; gvar=[((setl[0]-gavg[0])**2).sum(),((setl[1]-gavg[1])**2).sum()]
    sp=sum(gvar)/(sum(gn)-2); sx=math.sqrt(sp/gn[0]+sp/gn[1])
    t=abs((gavg[0]-gavg[1])/sx)
    if sum(gn)-2 > 120:
        ztab=[0.5000,0.5040,0.5080,0.5120,0.5160,0.5199,0.5239,0.5279,0.5319,0.5359,0.5398,0.5438,0.5478,0.5517,0.5557,0.5596,0.5636,0.5675,0.5714,0.5753,0.5793,0.5832,0.5871,0.5910,0.5948,0.5987,0.6026,0.6064,0.6103,0.6141,0.6179,0.6217,0.6255,0.6293,0.6331,0.6368,0.6406,0.6443,0.6480,0.6517,0.6554,0.6591,0.6628,0.6664,0.6700,0.6736,0.6772,0.6808,0.6844,0.6879,0.6915,0.6950,0.6985,0.7019,0.7054,0.7088,0.7123,0.7157,0.7190,0.7224,0.7257,0.7291,0.7324,0.7357,0.7389,0.7422,0.7454,0.7486,0.7517,0.7549,0.7580,0.7611,0.7642,0.7673,0.7704,0.7734,0.7764,0.7794,0.7823,0.7852,0.7881,0.7910,0.7939,0.7967,0.7995,0.8023,0.8051,0.8078,0.8106,0.8133,0.8159,0.8186,0.8212,0.8238,0.8264,0.8289,0.8315,0.8340,0.8365,0.8389,0.8413,0.8438,0.8461,0.8485,0.8508,0.8531,0.8554,0.8577,0.8599,0.8621,0.8643,0.8665,0.8686,0.8708,0.8729,0.8749,0.8770,0.8790,0.8810,0.8830,0.8849,0.8869,0.8888,0.8907,0.8925,0.8944,0.8962,0.8980,0.8997,0.9015,0.9032,0.9049,0.9066,0.9082,0.9099,0.9115,0.9131,0.9147,0.9162,0.9177,0.9192,0.9207,0.9222,0.9236,0.9251,0.9265,0.9279,0.9292,0.9306,0.9319,0.9332,0.9345,0.9357,0.9370,0.9382,0.9394,0.9406,0.9418,0.9429,0.9441,0.9452,0.9463,0.9474,0.9484,0.9495,0.9505,0.9515,0.9525,0.9535,0.9545,0.9554,0.9564,0.9573,0.9582,0.9591,0.9599,0.9608,0.9616,0.9625,0.9633,0.9641,0.9649,0.9656,0.9664,0.9671,0.9678,0.9686,0.9693,0.9699,0.9706,0.9713,0.9719,0.9726,0.9732,0.9738,0.9744,0.9750,0.9756,0.9761,0.9767,0.9772,0.9778,0.9783,0.9788,0.9793,0.9798,0.9803,0.9808,0.9812,0.9817,0.9821,0.9826,0.9830,0.9834,0.9838,0.9842,0.9846,0.9850,0.9854,0.9857,0.9861,0.9864,0.9868,0.9871,0.9875,0.9878,0.9881,0.9884,0.9887,0.9890,0.9893,0.9896,0.9898,0.9901,0.9904,0.9906,0.9909,0.9911,0.9913,0.9916,0.9918,0.9920,0.9922,0.9925,0.9927,0.9929,0.9931,0.9932,0.9934,0.9936,0.9938,0.9940,0.9941,0.9943,0.9945,0.9946,0.9948,0.9949,0.9951,0.9952,0.9953,0.9955,0.9956,0.9957,0.9959,0.9960,0.9961,0.9962,0.9963,0.9964,0.9965,0.9966,0.9967,0.9968,0.9969,0.9970,0.9971,0.9972,0.9973,0.9974,0.9974,0.9975,0.9976,0.9977,0.9977,0.9978,0.9979,0.9979,0.9980,0.9981,0.9981,0.9982,0.9982,0.9983,0.9984,0.9984,0.9985,0.9985,0.9986,0.9986,0.9987,0.9987,0.9987,0.9988,0.9988,0.9989,0.9989,0.9989,0.9990,0.9990]
        zl=arange(0,len(ztab))/100.
        if t < ztab[0]:
            p=1
        else:
            c=0
            for i in range(0,len(zl)):
                if t > zl[i]: c=i
            p=1-ztab[c]
    else:
        ttab=array([[1.000,1.376,1.963,3.078,6.314,12.71,31.82,63.66,127.3,318.3,636.6],\
            [0.816,1.061,1.386,1.886,2.920,4.303,6.965,9.925,14.09,22.33,31.60],\
            [0.765,0.978,1.250,1.638,2.353,3.182,4.541,5.841,7.453,10.21,12.92],\
            [0.741,0.941,1.190,1.533,2.132,2.776,3.747,4.604,5.598,7.173,8.610],\
            [0.727,0.920,1.156,1.476,2.015,2.571,3.365,4.032,4.773,5.893,6.869],\
            [0.718,0.906,1.134,1.440,1.943,2.447,3.143,3.707,4.317,5.208,5.959],\
            [0.711,0.896,1.119,1.415,1.895,2.365,2.998,3.499,4.029,4.785,5.408],\
            [0.706,0.889,1.108,1.397,1.860,2.306,2.896,3.355,3.833,4.501,5.041],\
            [0.703,0.883,1.100,1.383,1.833,2.262,2.821,3.250,3.690,4.297,4.781],\
            [0.700,0.879,1.093,1.372,1.812,2.228,2.764,3.169,3.581,4.144,4.587],\
            [0.697,0.876,1.088,1.363,1.796,2.201,2.718,3.106,3.497,4.025,4.437],\
            [0.695,0.873,1.083,1.356,1.782,2.179,2.681,3.055,3.428,3.930,4.318],\
            [0.694,0.870,1.079,1.350,1.771,2.160,2.650,3.012,3.372,3.852,4.221],\
            [0.692,0.868,1.076,1.345,1.761,2.145,2.624,2.977,3.326,3.787,4.140],\
            [0.691,0.866,1.074,1.341,1.753,2.131,2.602,2.947,3.286,3.733,4.073],\
            [0.690,0.865,1.071,1.337,1.746,2.120,2.583,2.921,3.252,3.686,4.015],\
            [0.689,0.863,1.069,1.333,1.740,2.110,2.567,2.898,3.222,3.646,3.965],\
            [0.688,0.862,1.067,1.330,1.734,2.101,2.552,2.878,3.197,3.610,3.922],\
            [0.688,0.861,1.066,1.328,1.729,2.093,2.539,2.861,3.174,3.579,3.883],\
            [0.687,0.860,1.064,1.325,1.725,2.086,2.528,2.845,3.153,3.552,3.850],\
            [0.686,0.859,1.063,1.323,1.721,2.080,2.518,2.831,3.135,3.527,3.819],\
            [0.686,0.858,1.061,1.321,1.717,2.074,2.508,2.819,3.119,3.505,3.792],\
            [0.685,0.858,1.060,1.319,1.714,2.069,2.500,2.807,3.104,3.485,3.767],\
            [0.685,0.857,1.059,1.318,1.711,2.064,2.492,2.797,3.091,3.467,3.745],\
            [0.684,0.856,1.058,1.316,1.708,2.060,2.485,2.787,3.078,3.450,3.725],\
            [0.684,0.856,1.058,1.315,1.706,2.056,2.479,2.779,3.067,3.435,3.707],\
            [0.684,0.855,1.057,1.314,1.703,2.052,2.473,2.771,3.057,3.421,3.690],\
            [0.683,0.855,1.056,1.313,1.701,2.048,2.467,2.763,3.047,3.408,3.674],\
            [0.683,0.854,1.055,1.311,1.699,2.045,2.462,2.756,3.038,3.396,3.659],\
            [0.683,0.854,1.055,1.310,1.697,2.042,2.457,2.750,3.030,3.385,3.646],\
            [0.681,0.851,1.050,1.303,1.684,2.021,2.423,2.704,2.971,3.307,3.551],\
            [0.679,0.849,1.047,1.299,1.676,2.009,2.403,2.678,2.937,3.261,3.496],\
            [0.679,0.848,1.045,1.296,1.671,2.000,2.390,2.660,2.915,3.232,3.460],\
            [0.678,0.846,1.043,1.292,1.664,1.990,2.374,2.639,2.887,3.195,3.416],\
            [0.677,0.845,1.042,1.290,1.660,1.984,2.364,2.626,2.871,3.174,3.390],\
            [0.677,0.845,1.041,1.289,1.658,1.980,2.358,2.617,2.860,3.160,3.373],\
            [0.674,0.842,1.036,1.282,1.645,1.960,2.326,2.576,2.807,3.090,3.291]])
        dfl=[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,40,50,60,80,100,120,1e31]
        pl=[0.25,0.2,0.15,0.1,0.05,0.025,0.01,0.005,0.0025,0.001,0.0005]
        r,c=0,0
        for i in range(0,len(dfl)):
            if sum(gn)-2 > dfl[i]: r=i+1
        if t < ttab[r,0]:
            p=1
        else:
            for i in range(0,len(ttab[r])):
                if t > ttab[r,i]: c=i
            p=pl[c]
    return t,sum(gn)-2,p

# Calculates one-way ANOVA F and degrees of freedom of numerator and denominator from several sets of numbers
def ftest(setl):
    for i in range(0,len(setl)): setl[i]=ravel(array(setl[i],float32))
    ng=len(setl)
    gsum,gx2,gn=[],[],[]
    for i in range(0,ng):
        gsum.append(setl[i].sum())
        gx2.append((setl[i]**2).sum())
        gn.append(len(setl[i]))
    tn,tsum,tx2=sum(gn),sum(gsum),sum(gx2)
    c=tsum**2/tn
    sstot,ssgr=tx2-c,(array(gsum)**2/array(gn)).sum()-c; sserr=sstot-ssgr
    dftot,dfgr=tn-1,ng-1; dferr=dftot-dfgr
    f=(ssgr/dfgr)/(sserr/dferr)
    return abs(f),dfgr,dferr

# Calculates percentile(s) of the lowest dimension of a multi-dimensional list or array of numbers
#   l = list or array
#   perc = percentiles; default: [0,10,25,50,75,90,100]
#   lin = flag for linear interpolation between values; default: True
#   nodata = nodata value; default: -9999
def calc_percentile(l,perc=[0,10,25,50,75,90,100],lin=True,nodata=-9999):
    dimperc=1
    if type(perc) in [complex,bool,int,long,float,bool_,uint8,uint16,uint32,uint64,int8,int16,int32,int64,float16,float32,float64]:
        perc=[perc]; dimperc=0
    perc=ravel(array(perc))
    perc=where(perc < 0,0,where(perc > 100,100,perc))
    type0=type(l)
    if type0 in [float,float16,float32,float64]:
        output=ones(len(perc),float32)*l
    elif type0 in [int,long,uint8,uint16,uint32,uint64,int8,int16,int32,int64]:
        output=ones(len(perc),int32)*l
    else:
        try:
            l=array(l,float32)
        except:
            pass
        if type(l) in [list,tuple]:
            output=[]
            for l1 in walklist(l,"sort(array(sub))"):
                l0=[]
                for i in range(0,len(l1)):
                    if l1[i] != nodata: l0.append(l1[i])
                N=len(l0)
                if N == 1:
                    output.append((ones(perc.shape,float32)*l0[0]).tolist())
                elif N > 1:
                    pf=(perc.copy()/100.0)*(N-1)
                    i1,i2=array(pf.copy(),int32),minimum(len(l0)-1,array(pf.copy(),int32)+1)
                    i1=where(i1 == i2,where(perc == 100,maximum(0,i1-1),i1),i1)
                    if lin:
                        y1,y2=take(l0,tuple(i1),-1),take(l0,tuple(i2),-1)
                        for i in get_shape(l0)[:-1]:
                            i1=repeat(reshape(i1,(1,)+i1.shape),i,0)
                            i2=repeat(reshape(i2,(1,)+i2.shape),i,0)
                        p1=concatenate([reshape(i1,i1.shape+(1,)),reshape(y1,y1.shape+(1,))],-1)
                        p2=concatenate([reshape(i2,i2.shape+(1,)),reshape(y2,y2.shape+(1,))],-1)
                        output0=linear(p1,p2,pf)
                    else:
                        output0=take(l0,tuple(i1),-1)
                    output.append(output0.tolist())
                else:
                    output.append((ones(perc.shape,float32)*nodata).tolist())
        else:
            l=sort(l,-1)
            N=l.shape[-1]
            if N == 1:
                output=repeat(l,len(perc),-1)
            elif N > 1:
                pf=(perc.copy()/100.0)*(N-1)
                i1,i2=array(pf.copy(),int32),minimum(N-1,array(pf.copy(),int32)+1)
                i1=where(i1 == i2,where(perc == 100,maximum(0,i1-1),i1),i1)
                if lin:
                    y1,y2=take(l,tuple(i1),-1),take(l,tuple(i2),-1)
                    for i in l.shape[:-1]:
                        i1=repeat(reshape(i1,(1,)+i1.shape),i,0)
                        i2=repeat(reshape(i2,(1,)+i2.shape),i,0)
                    p1=concatenate([reshape(i1,i1.shape+(1,)),reshape(y1,y1.shape+(1,))],-1)
                    p2=concatenate([reshape(i2,i2.shape+(1,)),reshape(y2,y2.shape+(1,))],-1)
                    output=linear(p1,p2,pf)
                else:
                    output=take(l,tuple(i1),-1)
                output=where(perc >= 100,take(l,(-1,),-1),output)
                output=where(perc <= 0,take(l,(0,),-1),output)
            else:
                output=ones((len(l),len(perc)),float32)*nodata
    if dimperc == 0:
        output=reshape(output,output.shape[:-1])
    if type0 in [list,tuple]:
        try:
            output=output.tolist()
        except:
            pass
    return output

# Interpolates linearly between points
#   p1,p2 = list or array of points; lowest-dimension: x,y
def linear(p1,p2,x=None,nodata=-9999):
    islist=False
    if type(p1) in [list,tuple]:
        islist=True
    dimp=1
    if type(p1[0]) in [complex,bool,int,long,float,bool_,uint8,uint16,uint32,uint64,int8,int16,int32,int64,float16,float32,float64]:
        p1,p2=[p1],[p2]; dimp=0
    try: arrtype=p1.dtype.name
    except: arrtype="float64"
    p1,p2=array(p1,arrtype),array(p2,arrtype)
    inshape=p1.shape; outshape=inshape[:-1]+(1,)
    if x == None:
        x=zeros(outshape,arrtype)
    elif type(x) in [complex,bool,int,long,float,bool_,uint8,uint16,uint32,uint64,int8,int16,int32,int64,float16,float32,float64]:
        x=ones(outshape,arrtype)*x
    else:
        x=array(x,arrtype)
        try: x=reshape(x,outshape)
        except: x=resize(x,outshape)
    try:
        dx,dy=take(p1,(0,),-1)-take(p2,(0,),-1),take(p1,(1,),-1)-take(p2,(1,),-1)
        nodata0=dx.min()-1
        dx=where(dx == 0,nodata0,dx)
        a=dy.copy()/dx.copy(); b=take(p1,(1,),-1)-a.copy()*take(p1,(0,),-1)
        y=a.copy()*x.copy()+b.copy()
        y=where(dx == nodata0,nodata,y)
    except:
        y=ones(outshape,arrtype)*nodata
    y=reshape(y,y.shape[:-1])
    if dimp == 0:
        y=reshape(y,y.shape[:-1])
    if islist:
        if dimp == 1:
            y=y.tolist()
        else:
            y=float(y)
    return y

def interpolate(XL,YL,x=None,nodata=-9999,descending=False):
    islist0,islist1,dimp,at=False,False,1,float64
    if type(XL) in [list,tuple]: islist0=True
    if type(XL[0]) in [complex,bool,int,long,float,bool_,uint8,uint16,uint32,uint64,int8,int16,int32,int64,float16,float32,float64]: dimp=0
    elif type(XL[0]) in [list,tuple]: islist1=True
    atx,aty=at,at
    if islist0:
        xl,yl=deepcopy(list(XL)),deepcopy(list(YL))
    else:
        xl,yl=XL.tolist(),YL.tolist()
    if dimp == 0:
        for i in range(0,len(xl)): xl[i],yl[i]=[xl[i]],[yl[i]]
    xl,yl=array(xl,atx).copy(),array(yl,aty).copy()
    outshape=xl[0].shape
    if x == None:
        x=zeros(outshape,atx)
    elif type(x) in [complex,bool,int,long,float,bool_,uint8,uint16,uint32,uint64,int8,int16,int32,int64,float16,float32,float64]:
        x=ones(outshape,atx)*x
    else:
        x=array(x,atx).copy()
        x=reshape(x,outshape)
    if descending: xl,x=-xl,-x
    try:
        xy0,xy1=array([xl[0],yl[0]]),array([xl[1],yl[1]])
        found=zeros(xl[0].shape,uint8)
        for i in range(1,len(xl)-1):
            found=array(where(x <= xl[i],1,found),uint8)
            if where(found == 0,1,0).sum() == 0: break
            xy0[0]=where(x > xl[i],where(found == 0,xl[i],xy0[0]),xy0[0])
            xy0[1]=where(x > xl[i],where(found == 0,yl[i],xy0[1]),xy0[1])
            xy1[0]=where(x > xl[i],where(found == 0,xl[i+1],xy1[0]),xy1[0])
            xy1[1]=where(x > xl[i],where(found == 0,yl[i+1],xy1[1]),xy1[1])
        xy0=swapaxes(reshape(xy0,xy0.shape+(1,)),0,-1)[0]
        xy1=swapaxes(reshape(xy1,xy1.shape+(1,)),0,-1)[0]
        y=linear(xy0,xy1,x)
    except:
        y=ones(outshape,aty)*nodata
    if islist1: y=y.tolist()
    elif islist0:
        y0=[]
        for i in range(0,len(y)): y0.append(y[i])
        y=y0
    if dimp == 0:
        y=y[0]
    return y

def regression(XL,YL,nodata=-9999):
    islist0,islist1,dimp=False,False,1
    if type(XL) in [list,tuple]: islist0=True
    if type(XL[0]) in [complex,bool,int,long,float,bool_,uint8,uint16,uint32,uint64,int8,int16,int32,int64,float16,float32,float64]: dimp=0
    elif type(XL[0]) in [list,tuple]: islist1=True
    if islist0:
        xl,yl=deepcopy(list(XL)),deepcopy(list(YL))
    else:
        xl,yl=XL.tolist(),YL.tolist()
    if dimp == 0:
        for i in range(0,len(xl)): xl[i],yl[i]=[xl[i]],[yl[i]]
    xl,yl=array(xl,float32).copy(),array(yl,float32).copy()
    outshape=xl[0].shape
    slope,intercept=ones(outshape,float32)*nodata,ones(outshape,float32)*nodata
    nx,ny=len(xl),len(yl)
    if nx == ny and nx > 1:
        xm,ym=sum(xl)/nx,sum(yl)/ny
        b1,b2=zeros(outshape,float32),zeros(outshape,float32)
        for i in range(0,nx):
            b1=b1+(xl[i].copy()-xm.copy())*(yl[i].copy()-ym.copy())
            b2=b2+(xl[i].copy()-xm.copy())**2
        nodat=array(where(b2 == 0,1,0),uint8)
        b2=where(b2 == 0,1,b2)
        slope=where(nodat == 1,nodata,b1.copy()/b2.copy())
        intercept=where(nodat == 1,nodata,ym.copy()-slope.copy()*xm.copy())
    if islist1: slope,intercept=slope.tolist(),intercept.tolist()
    elif islist0:
        slope0=[]
        for i in range(0,len(slope)): slope0.append(slope[i])
        slope=slope0
        intercept0=[]
        for i in range(0,len(intercept)): intercept0.append(intercept[i])
        intercept=intercept0
    if dimp == 0:
        slope,intercept=slope[0],intercept[0]
    return slope,intercept

def normalize(Arr,interval=[-1,1],shift=0,nodata=-9999,perc=[0,100]):
    arr=array(Arr).copy()
    p0,p50,p100=percentile(compress(ravel(arr) != nodata,ravel(arr),0),[perc[0],50,perc[1]],True,nodata)
    if p0 != nodata:
        mid0=avg_stdev(interval,False,nodata)[0]
        if shift == 0:
            mid=(p0+p100)/2.0
        elif shift == 1:
            mid=avg_stdev(compress(ravel(arr) != nodata,ravel(arr),0),False,nodata)[0]
        else:
            mid=p50
        delt=mid0-mid
        multmin,multmax=1,1
        if p0-mid != 0: multmin=abs((interval[0]-mid0)/(p0-mid))
        if p100-mid != 0: multmax=abs((interval[1]-mid0)/(p100-mid))
        mult=min(multmin,multmax)
        arr=where(arr != nodata,(arr+delt)*mult,nodata)
    return arr

def calc_histogram(dataarray,minval,maxval,intervals):
    dataarray=ravel(dataarray)
    s=(float(maxval)-minval)/intervals
    hist=zeros((intervals))
    for n in range(0,dataarray.shape[0]):
        val=dataarray[n]
        if val < maxval and val > minval:
            interval=int((val-minval)/s)
            hist[interval]=hist[interval]+1
    return hist

# Greatest common divisor
def calc_gcd(n1,n2):
    n1,n2=abs(n1),abs(n2)
    a,b=max(n1,n2),min(n1,n2)
    while 1:
        c=a%b
        if c <= 1e-10: break
        a=b; b=c
    return b

# Least common multiple
def calc_lcm(n1,n2):
    return (n1*n2)/calc_gcd(n1,n2)

def calc_multiples(n,minm=1,maxm=None):
    n,mult=int(n),[]
    try: minm=int(minm)
    except: minm=1
    for i in range(minm,n):
        if n%i == 0: mult.append(i)
    mult=mult+[n]
    try:
        maxm=int(maxm)
        mult=mult+range(n*2,maxm+1,n)
    except: pass
    return mult


