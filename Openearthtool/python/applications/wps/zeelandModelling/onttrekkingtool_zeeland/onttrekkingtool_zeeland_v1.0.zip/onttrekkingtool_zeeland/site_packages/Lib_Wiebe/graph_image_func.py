## FUNCTIONS FOR GRAPHS AND IMAGES ##

## Importing modules

try:
    from general_func import *
    from timing_func import *
    import pylab
    from pylab import *
    from matplotlib.ticker import *
    import numpy.ma as MA
    from PIL import Image, ImageDraw, ImageFont
    from PIL import BmpImagePlugin, EpsImagePlugin, GifImagePlugin, JpegImagePlugin, PngImagePlugin, TiffImagePlugin
except:
    pass


## GRAPH FUNCTIONS ##

## Closes all graphs
def closegraph():
    pylab.clf(); pylab.close('all')

def get_color(v,v_minmax=None,colormap="jet",return_r=False):
    if v_minmax == None: v_minmax=[0,1]
    if v_minmax[0] == v_minmax[1]: r=0.5
    else: r=max(0.0,min(1.0,float(v-min(v_minmax))/float(max(v_minmax)-min(v_minmax))))
    if return_r: return r
    else:
        Cmap=plt.get_cmap(colormap)
        return Cmap(r)

def graphfig(figdata,figlist,fig=None,pars=None):
#Figuur (fig)
# [breedte,hoogte,margin,nrow,ncol]
# None = default
#
#Parameters (pars)
# [lmargin,tmargin,rmargin,bmargin],[axiskleur,internalspace,legendspace],[fonts ...],[fontsizes ...],[fontweights ...],[fontkleuren ...]
# None = default
#
# fonts/fontsizes/fontweights/fontkleuren:
# {titel,legendlabels,text},{xlabel,ylabel,y2label},{xticks,yticks,y2ticks}
#
#Data (figdata)
# [arrays/lists]
#
#Figlist
# [parameters]
# [titel]
# [xlabel,xminmax,xtickposities,xticktexts,xtickrotatie,xformat,xreverse,xticklinesize,xticklinewidth,xticklinecolor,xticklinestyle]
# [ylabel,yminmax,ytickposities,yticktexts,ytickrotatie,yformat,yreverse,yticklinesize,yticklinewidth,yticklinecolor,yticklinestyle]
# [y2label,y2minmax,y2tickposities,y2ticktexts,y2tickrotatie,y2format,y2reverse,y2ticklinesize,y2ticklinewidth,y2ticklinecolor,y2ticklinestyle]
# [elementtype,elementargumenten ...]
#  ...
#
# None = default
#
# Titel/labels:
#  None, "" = geen tekst
#  " " = geen tekst, maar wel ruimte
#
# yinmax/y2minmax:
#  "dy2y" = zelfde intervallen
#  "y2y" = helemaal hetzelfde
#
#Elementen:
#
# "l": Lijn (plot)
#  [x,y,primsec],[labeltext],[lijnstijl(ls),lijndikte(lw),lijnkleur(c)],[markerstijl(marker),markergrootte(ms),markerranddikte(mew),markerkleur(mfc),markerrandkleur(mec)]
#
# "p": Polygon (patches)
#  [x,y,primsec],[labeltext],[fillkleur(fc),lijndikte(lw),lijnkleur(ec)]
#
# "s": Scatter (scatter)  >> not yet implemented
#  [x,y,z,primsec],[labeltext],[colormap,color_under,color_over],[colorbar_shrink,colorbar_ticks]
#
# "f": Fill tussen lijnen (fill)
#  [x,y1,y2,primsec],[labeltext],[fillkleur(fc),lijndikte(lw),lijnkleur(c)]]
#
# "c": Contour filled (contourf)  >> not yet implemented
#  [x,y,z,primsec],[dx,dy,nz,zmin,zmax],[labeltext],[colormap,color_under,color_over],[colorbar_shrink,colorbar_ticks]
#
# "i": Image (imshow)
#  [x,y,z,primsec],[dx,dy,z_interpolation,zmin,zmax],[labeltext],[colormap,color_under,color_over],[colorbar_shrink,colorbar_ticks]
#
# "pc": Pcolor image (pcolor)
#  [x,y,z,primsec],[dx,dy,z_interpolation,zmin,zmax],[labeltext],[colormap,color_under,color_over],[colorbar_shrink,colorbar_ticks]
#
# "t": Tekst (ax.text)
#  [x,y,primsec],[text,textfont,textfontsize,textfontweight,textkleur],[horizontalalignment,verticalalignment,rotatie]
#
# "b": Bars (bar)
#  [bu,bl,bh,bw,bb,byerr,primsec],[(labeltexts)],[(barkleuren),(barranddikte),(barrandkleuren),(yerrcapsizes),(yerrkleuren)]
#
# "ft": Figuurtekst (figtext)
#  [x,y,dummy],[text,textfont,textfontsize,textfontweight,textkleur],[horizontalalignment,verticalalignment,rotatie]
#
# None = default
#
# Labels:
#  None, "" = geen tekst, niet in legenda
# Bij Tekst/Figuurtekst:
#  x,y verwijst niet naar figdata
#
    def expand_p(p,p0):
        p=var2list_ct(p)
        for i in range(len(p),len(p0)): p.append([None])
        p=p[:len(p0)]
        for i in range(0,len(p0)):
            p[i]=var2list_ct(p[i])
            if len(p[i]) == 0: p[i]=[None]
            for j in range(len(p[i]),len(p0[i])):
                if type(p0[i][j]) == type(p0[i][j-1]): p[i].append(p[i][-1])
                else: p[i].append(None)
            p[i]=p[i][:len(p0[i])]
            if type(p0[i][0]) in [list,tuple] and type(p0[i][-1]) in [list,tuple]:
                for j in range(0,len(p0[i])):
                    p[i][j]=var2list_ct(p[i][j])
                    if len(p[i][j]) == 0: p[i][j]=[None]
                    for k in range(len(p[i][j]),len(p0[i][j])): p[i][j].append(p[i][j][-1])
                    p[i][j]=p[i][j][:len(p0[i][j])]
        return p
    def p2p(p,p0):
        for i in range(0,len(p0)):
            if i >= 2:
                for j in range(0,len(p0[i])):
                    for k in range(0,len(p0[i][j])):
                        if p[i][j][k] != None: p0[i][j][k]=p[i][j][k]
            else:
                for j in range(0,len(p0[i])):
                    if p[i][j] != None: p0[i][j]=p[i][j]
        return p0
    def expand_f2f(f,f0,parsdef):
        f=var2list_ct(f)
        f[0]=p2p(expand_p(f[0],parsdef),parsdef)
        for i in range(1,5):
            f[i]=var2list_ct(f[i])
            if len(f[i]) == 0: f[i]=[None]
            for j in range(len(f[i]),len(f0[i])): f[i].append(None)
            f[i]=f[i][:len(f0[i])]
            for j in range(0,len(f[i])):
                if f[i][j] == None: f[i][j]=f0[i][j]
        return f
    def expand_l2l(l,l0):
        l=var2list_ct(l)
        for i in range(len(l),len(l0)): l.append([None])
        l=l[:len(l0)]
        for i in range(0,len(l0)):
            if type(l[i]) not in [list,tuple]: l[i]=[l[i]]
            l[i]=var2list_ct(l[i])
            for j in range(len(l[i]),len(l0[i])): l[i].append(None)
            l[i]=l[i][:len(l0[i])]
            for j in range(0,len(l0[i])):
                if l[i][j] == None: l[i][j]=l0[i][j]
        return l
    def expand_b2b(b,b0,un=None):
        b=var2list_ct(b)
        for i in range(len(b),len(b0)): b.append([None])
        b=b[:len(b0)]
        for i in range(0,len(b0)):
            if type(b[i]) not in [list,tuple]: b[i]=[b[i]]
            b[i]=var2list_ct(b[i])
            if i == 0:
                for j in range(len(b[i]),len(b0[i])): b[i].append(None)
                b[i]=b[i][:len(b0[i])]
                for j in range(0,len(b0[i])):
                    if b[i][j] == None: b[i][j]=b0[i][j]
            else:
                for j in range(len(b[i]),len(b0[i])): b[i].append([None])
                b[i]=b[i][:len(b0[i])]
                for j in range(0,len(b0[i])):
                    if type(b[i][j]) not in [list,tuple]: b[i][j]=[b[i][j]]
                    elif len(b[i][j]) == 0: b[i][j]=[None]
                    b[i][j]=var2list_ct(b[i][j])
                    if b[i][j] == [None]: b[i][j]=b0[i][j]
                    if un != None:
                        lut=[[None,None]]
                        try:
                            rs=get_shape(b[i][j])
                            if len(rs) == 3: lutval=b[i][j][0][-1]
                            elif len(rs) == 2:
                                if type(b[i][j][0]) == tuple: lutval=b[i][j][0]
                                else: lutval=b[i][j][0][-1]
                            else:
                                try: lutval=b[i][j][0]
                                except: lutval=b[i][j]
                        except:
                            lutval=None
                        if lutval == None: lutval=b0[i][j][0]
                        lut=sublist([un,[lutval]*len(un)])
                        for k in range(0,len(lut)):
                            try:
                                lutval1=lookup(lut[k][0],b[i][j],lut[k][1])
                                if lutval1 != None: lut[k][1]=lutval1
                            except: pass
                        b[i][j]=deepcopy(lut)
        return b
    def format_abs_int(x,pos): return "%d" %(abs(x))
    def format_abs_fl1(x,pos): return "%.1f" %(abs(x))
    def format_abs_fl2(x,pos): return "%.2f" %(abs(x))
    def format_abs_fl3(x,pos): return "%.3f" %(abs(x))
    def format_abs_fl4(x,pos): return "%.4f" %(abs(x))

    figdef=[6,4.5,0.01,1,None]
    parsdef=[[0.08]*4,[(0,0,0)]+[0.05,0.05],[["Arial"]*3,["Arial"]*3,["Arial"]*3],[[10]*3,[10]*3,[10]*3],[["bold","regular","regular"],["regular"]*3,["regular"]*3],[[(0,0,0)]*3,[(0,0,0)]*3,[(0,0,0)]*3]]
    figlistdef=[parsdef,[""],["",None,None,None,0,None,False,4,1,None,"-"],["",None,None,None,0,None,False,4,1,None,"-"],["",None,None,None,0,None,False,4,1,None,"-"]]
    colordef=[(0,0,1),(1,0,0),(0,1,0),(1,0,1),(0,1,1),(1,1,0),(0.5,0,1),(1,0.5,0),(0,0.5,1),(0.6,0.4,0.2),(0.2,0.6,0.4),(0.5,0.5,0.5)]*10
    linedef=[[0,1,1],[""],["-",1,None],[None,4,0,None,(0.75,0.75,0.75)]]
    polydef=[[0,1,1],[""],[(0,0,1),0,(0,0,0)]]
    filldef=[[0,1,2,1],[""],[(0,0,1),0,(0,0,0)]]
    contdef=[[0,1,2,1],[None,None,10,None,None],[""],["jet",(0.75,0.75,0.75),(0.75,0.75,0.75)],[0.8,None]]
    imdef=[[0,1,2,1],[None,None,"nearest",None,None],[""],["jet",(0.75,0.75,0.75),(0.75,0.75,0.75)],[0.8,None]]
    pcoldef=[[0,1,2,1],[None,None,"nearest",None,None],[""],["jet",(0.75,0.75,0.75),(0.75,0.75,0.75)],[0.8,None]]
    bardef=[[0,1,2,3,None,None,1],[[""]],[[None],[0],[(0.75,0.75,0.75)],[3],[(0,0,0)]]]
    textdef=[[0,0,1],[None,None,None,None,None],["left","bottom",0]]
    figtextdef=[[0,0,0],[None,None,None,None,None],["left","bottom",0]]
    horlut=[["r","right"],["R","right"],["right","right"],["RIGHT","right"],["c","center"],["C","center"],["center","center"],["CENTER","center"],["centre","center"],["CENTRE","center"]]
    vertlut=[["t","top"],["T","top"],["top","top"],["TOP","top"],["c","center"],["C","center"],["center","center"],["CENTER","center"],["centre","center"],["CENTRE","center"]]

    fig=var2list_ct(fig)
    for i in range(len(fig),len(figdef)): fig.append(None)
    fig=fig[:len(figdef)]
    for i in range(0,len(figdef)):
        if fig[i] != None: figdef[i]=fig[i]
    if fig[-2] == None and fig[-1] != None: figdef[-2]=None
    figw,figh,figm,nrow,ncol=figdef

    parsdef=p2p(expand_p(pars,parsdef),parsdef)

    figlst=deepcopy(figlist)

    N=len(figlst)
    if nrow == None:
        ncol=min(ncol,N)
        nrow=float(N)/float(ncol)
        if nrow == int(nrow): nrow=int(nrow)
        else: nrow=int(nrow)+1
    elif ncol == None:
        nrow=min(nrow,N)
        ncol=float(N)/float(nrow)
        if ncol == int(ncol): ncol=int(ncol)
        else: ncol=int(ncol)+1
    else:
        ncol=max(1,int(ncol*(N/float(nrow*ncol))**0.5))
        nrow=float(N)/ncol
        if nrow == int(nrow): nrow=int(nrow)
        else: nrow=int(nrow)+1

    primsec=[]
    for i in range(0,N):
        primsec.append(0)
        figlst[i]=expand_f2f(deepcopy(figlst[i]),figlistdef,parsdef)
        for j in range(2,5):
            if figlst[i][j][9] == None: figlst[i][j][9]=figlst[i][0][1][0]
        icl,icb=0,0
        for j in range(5,len(figlst[i])):
            try: el=string.lower(figlst[i][j][0])
            except: el=None
            el0=[]
            if el in ["line","l"]: el,el0="l",deepcopy(linedef)
            elif el in ["polygon","poly","p"]: el,el0="p",deepcopy(polydef)
            elif el in ["fill","f"]: el,el0="f",deepcopy(filldef)
            elif el in ["bar","bars","b"]: el,el0="b",deepcopy(bardef)
            elif el in ["contourf","contour","cont","c"]: el,el0="c",deepcopy(contdef)
            elif el in ["image","imshow","im","i"]: el,el0="i",deepcopy(imdef)
            elif el in ["pcolor","pcol","pc"]: el,el0="pc",deepcopy(pcoldef)
            elif el in ["text","txt","t"]: el,el0="t",deepcopy(textdef)
            elif el in ["figtext","figtxt","ft"]: el,el0="ft",deepcopy(figtextdef)
            if el0 != []:
                if el in ["l","p","f","c","i","pc","t","ft"]:
                    el0=expand_l2l(figlst[i][j][1:],el0)
                    if el == "l":
                        if el0[2][0] == "" or el0[2][1] == 0: el0[2][0]=None
                        if el0[3][0] == "" or el0[3][1] == 0: el0[3][0]=None
                        if el0[2][0] == None and el0[3][0] == None:
                            el=None
                        else:
                            if el0[2][2] == None and el0[3][3] == None:
                                el0[2][2],el0[3][3]=colordef[icl],colordef[icl]; icl=icl+1
                            elif el0[2][2] != None and el0[3][3] == None: el0[3][3]=el0[2][2]
                            elif el0[2][2] == None and el0[3][3] != None: el0[2][2]=el0[3][3]
                            if type(el0[3][4]) not in [list,tuple,type(None)]: el0[3][4]=el0[3][3]
                    elif el == "p":
                        if el0[2][1] != 0 and el0[2][2] == None:
                            el0[2][2]=colordef[icl]; icl=icl+1
                    elif el == "f":
                        if el0[2][1] != 0 and el0[2][2] == None:
                            el0[2][2]=colordef[icl]; icl=icl+1
                    elif el in ["t","ft"]:
                        if el0[1][0] in ["",None]: el=None
                        else:
                            if el0[1][1] == None: el0[1][1]=figlst[i][0][2][0][2]
                            if el0[1][2] == None: el0[1][2]=figlst[i][0][3][0][2]
                            if el0[1][3] == None: el0[1][3]=figlst[i][0][4][0][2]
                            if el0[1][4] == None: el0[1][4]=figlst[i][0][5][0][2]
                else:
                    el1=expand_b2b(figlst[i][j][1:],el0)
                    un=uniquenumbers(array(figdata[el1[0][0]])).tolist()
                    el0=expand_b2b(el1,el0,un)
                    for k in range(0,len(el0[2][0])):
                        if el0[2][0][k][1] == None:
                            el0[2][0][k][1]=colordef[icb]; icb=icb+1

                figlst[i][j]=[el]+deepcopy(el0)
                primsec[-1]=max(primsec[-1],figlst[i][j][1][-1])
            else:
                figlst[i][j][0]=None

    graph=figure(figsize=(figw*ncol,figh*nrow))
    W,H=1.0/ncol,1.0/nrow

    for i in range(0,N):
        r,c=i/ncol,i%ncol
        lmargin,tmargin,rmargin,bmargin=figlst[i][0][0]
        space1,space2=figlst[i][0][1][1:3]
        if figlst[i][1][0] == "": tmargin=0
        if figlst[i][2][0] == "": bmargin=0
        if figlst[i][3][0] == "": lmargin=0
        if figlst[i][4][0] == "": rmargin=0
        #left=W*c+figm+(W*lmargin); bottom=H*(nrow-r-1)+figm+(H*bmargin); width=W-2*figm-(W*lmargin); height=H-2*figm-(H*bmargin)-(H*tmargin)
        left=W*(c+figm+lmargin); bottom=H*(nrow-r-1+figm+bmargin); width=W*(1-2*figm-lmargin); height=H*(1-2*figm-bmargin-tmargin)
        if primsec[i] == 2 or figlst[i][4][0] != "":
            width=width-(W*rmargin)

        if primsec[i] == 2:
            ax2=axes([left,bottom,width,height])
            ax1=twinx(ax2)
            #setp(get(ax2,"frame"),"edgecolor",figlst[i][0][1][0])
            for child in ax2.get_children():
                if isinstance(child, matplotlib.spines.Spine): child.set_edgecolor(figlst[i][0][1][0])
            ax2.yaxis.set_ticks_position("right"); ax1.yaxis.set_ticks_position("left")
        else:
            ax1=axes([left,bottom,width,height])
        #setp(get(ax1,"frame"),"edgecolor",figlst[i][0][1][0])
        for child in ax1.get_children():
            if isinstance(child, matplotlib.spines.Spine): child.set_edgecolor(figlst[i][0][1][0])

        leg1,leg2=[],[]
        xmax=ymax=ymax2=-1e31; xmin=ymin=ymin2=1e31

        zorder=0
        for el in figlst[i][5:]:
            zorder+=1
            if el[0] == "l":
                sec=False
                if el[1][-1] == 2: sec=True
                if el[3][0] != None and el[4][0] != None:
                    if sec: p=ax2.plot(figdata[el[1][0]],figdata[el[1][1]],label=el[2][0],ls=el[3][0],lw=el[3][1],c=el[3][2],marker=el[4][0],ms=el[4][1],mew=el[4][2],mfc=el[4][3],mec=el[4][4])
                    else: p=ax1.plot(figdata[el[1][0]],figdata[el[1][1]],label=el[2][0],ls=el[3][0],lw=el[3][1],c=el[3][2],marker=el[4][0],ms=el[4][1],mew=el[4][2],mfc=el[4][3],mec=el[4][4])
                elif el[3][0] != None:
                    if sec: p=ax2.plot(figdata[el[1][0]],figdata[el[1][1]],label=el[2][0],ls=el[3][0],lw=el[3][1],c=el[3][2])
                    else: p=ax1.plot(figdata[el[1][0]],figdata[el[1][1]],label=el[2][0],ls=el[3][0],lw=el[3][1],c=el[3][2])
                else:
                    if sec: p=ax2.plot(figdata[el[1][0]],figdata[el[1][1]],label=el[2][0],lw=0,marker=el[4][0],ms=el[4][1],mew=el[4][2],mfc=el[4][3],mec=el[4][4])
                    else: p=ax1.plot(figdata[el[1][0]],figdata[el[1][1]],label=el[2][0],lw=0,marker=el[4][0],ms=el[4][1],mew=el[4][2],mfc=el[4][3],mec=el[4][4])
                if el[2][0] != "":
                    leg1.append(p[0]); leg2.append(el[2][0])
                xmax,xmin=max(xmax,max(figdata[el[1][0]])),min(xmin,min(figdata[el[1][0]]))
                if sec: ymax2,ymin2=max(ymax2,max(figdata[el[1][1]])),min(ymin2,min(figdata[el[1][1]]))
                else: ymax,ymin=max(ymax,max(figdata[el[1][1]])),min(ymin,min(figdata[el[1][1]]))
                setp(p,"zorder",zorder)
            elif el[0] == "p":
                sec=False
                if el[1][-1] == 2: sec=True
                if el[1][0] == el[1][1]: verts=figdata[el[1][0]]
                else: verts=swapaxes(array([figdata[el[1][0]],figdata[el[1][1]]]),0,1)
                if el[3][1] != 0:
                    pol=matplotlib.patches.Polygon(verts,closed=True,fc=el[3][0],lw=el[3][1],ec=el[3][2])
                else:
                    pol=matplotlib.patches.Polygon(verts,closed=True,fc=el[3][0],lw=0)
                if sec: p=ax2.add_path(pol)
                else: p=ax1.add_patch(pol)
                if el[2][0] != "":
                    leg1.append(el[2][0]); leg2.append(el[2][0])
                xmax,xmin=max(xmax,max(verts[:,0])),min(xmin,min(verts[:,0]))
                if sec: ymax2,ymin2=max(ymax2,max(verts[:,1])),min(ymin2,min(verts[:,1]))
                else: ymax,ymin=max(ymax,max(verts[:,1])),min(ymin,min(verts[:,1]))
                setp(p,"zorder",zorder)
            elif el[0] == "f":
                sec=False
                if el[1][-1] == 2: sec=True
                if sec:
                    p=ax2.fill(ravel(array(figdata[el[1][0]])).tolist()+ravel(array(figdata[el[1][0]])).tolist()[::-1],ravel(array(figdata[el[1][1]])).tolist()+ravel(array(figdata[el[1][2]])).tolist()[::-1],\
                        fc=el[3][0],lw=el[3][1],ec=el[3][2])
                else:
                    p=ax1.fill(ravel(array(figdata[el[1][0]])).tolist()+ravel(array(figdata[el[1][0]])).tolist()[::-1],ravel(array(figdata[el[1][1]])).tolist()+ravel(array(figdata[el[1][2]])).tolist()[::-1],\
                        fc=el[3][0],lw=el[3][1],ec=el[3][2])
                if el[2][0] != "":
                    leg1.append(p[0]); leg2.append(el[2][0])
                xmax,xmin=max(xmax,max(figdata[el[1][0]])),min(xmin,min(figdata[el[1][0]]))
                if sec: ymax2,ymin2=max(ymax2,max(figdata[el[1][1]]),max(figdata[el[1][2]])),min(ymin2,min(figdata[el[1][1]]),min(figdata[el[1][2]]))
                else: ymax,ymin=max(ymax,max(figdata[el[1][1]]),max(figdata[el[1][2]])),min(ymin,min(figdata[el[1][1]]),min(figdata[el[1][2]]))
                setp(p,"zorder",zorder)
            elif el[0] == "c":
                pass
            elif el[0] == "i":
                sec=False
                if el[1][-1] == 2: sec=True
                xarr,yarr,zarr=array(figdata[el[1][0]]),array(figdata[el[1][1]]),array(figdata[el[1][2]])
                Nx,Ny,Nz=size(xarr),size(yarr),size(zarr)
                irreg,grid=False,False
                if rank(xarr) == 1 and rank(yarr) == 2: xarr=repeat([xarr],len(yarr),0)
                if rank(yarr) == 1 and rank(xarr) == 2: yarr=repeat(reshape(yarr,(len(yarr),1)),len(xarr[0]),1)
                if rank(xarr) == 1 and rank(zarr) == 1 and Nx == Nz:                                                                # "irregular", 1-D
                    irreg,grid=True,True
                    xarr0=sort(xarr.copy()); dxarr0=xarr0[1:]-xarr0[:-1]; dx0=compress(dxarr0 > 0,dxarr0).min()
                    yarr0=sort(yarr.copy()); dyarr0=yarr0[1:]-yarr0[:-1]; dy0=compress(dyarr0 > 0,dyarr0).min()
                elif rank(xarr) == 1 and rank(zarr) == 1 and Nx*Ny == Nz:                                                           # "regular", 2-D, x and y sorted
                    xarr,yarr=meshgrid(xarr,yarr)
                    zarr=reshape(zarr,xarr.shape)
                elif rank(xarr) == 1 and rank(zarr) == 2 and Nx == Nz: xarr,yarr=reshape(xarr,zarr.shape),reshape(yarr,zarr.shape)  # "regular", 2-D, x and y sorted
                elif rank(xarr) == 1 and rank(zarr) == 2 and Nx*Ny == Nz: xarr,yarr=meshgrid(xarr,yarr)                             # "regular", 2-D, x and y sorted
                elif rank(xarr) == 2 and rank(zarr) == 1 and Nx == Nz: zarr=reshape(zarr,xarr.shape)                                # "regular", 2-D, x and y sorted
                if not irreg:
                    if xarr[0,0] > xarr[0,-1]: xarr,zarr=xarr[:,::-1],zarr[:,::-1]
                    if yarr[0,0] < yarr[-1,0]: yarr,zarr=yarr[::-1],zarr[::-1]
                if not grid:
                    dxarr0=abs(xarr.copy()[:,1:]-xarr.copy()[:,:-1])
                    if dxarr0.min() != dxarr0.max(): dx0,grid=dxarr0.min(),True
                    dyarr0=abs(yarr.copy()[1:]-yarr.copy()[:-1])
                    if dyarr0.min() != dyarr0.max(): dy0,grid=dyarr0.min(),True
                if grid:
                    dx=el[2][0]
                    if dx in [None,0]: dx=dx0
                    dy=el[2][1]
                    if dy in [None,0]: dy=dy0
                    xi=linspace(xarr.min(),xarr.max(),int((xarr.max()-xarr.min())/dx)+1)
                    yi=linspace(yarr.min(),yarr.max(),int((yarr.max()-yarr.min())/dy)+1)
                    zarr=griddata(ravel(xarr),ravel(yarr),ravel(zarr),xi,yi)
                    xarr,yarr=xi.copy(),yi.copy()
                else: dx,dy=xarr[0,1]-xarr[0,0],yarr[0,1]-yarr[0,0]
                Extent=[xarr.min()-dx/2.,xarr.max()+dx/2.,yarr.max()+dy/2.,yarr.min()-dy/2.]
                Cmap=plt.get_cmap(el[4][0])
                Extend="neither"
                zmin,zmax=el[2][3],el[2][4]
                if zmin == None: zmin=zarr.min()
                else:
                    Cmap.set_under(el[4][1])
                    if zmax != None: Extend="both"
                    else: Extend="min"
                if zmax == None: zmax=zarr.max()
                else:
                    Cmap.set_over(el[4][2])
                    if Extend == "neither": Extend="max"
                    else: Extend="both"
                Norm=mpl.colors.Normalize(vmin=zmin,vmax=zmax)
                if sec: ima=ax2.imshow(zarr,interpolation=el[2][2],extent=Extent,cmap=Cmap,norm=Norm,aspect="auto")
                else: ima=ax1.imshow(zarr,interpolation=el[2][2],extent=Extent,cmap=Cmap,norm=Norm,aspect="auto")
                if el[5][0] != 0:
                    cb=colorbar(ima,shrink=el[5][0],extend=Extend)
                    if el[5][1] != None: cb.set_ticks(el[5][1])
                    if el[3][0] != "": cb.set_label(el[3][0])
                xmax,xmin=max(xmax,xarr.max()+dx/2.),min(xmin,xarr.min()-dx/2.)
                if sec: ymax2,ymin2=max(ymax2,yarr.max()+dy/2.),min(ymin2,yarr.min()-dy/2.)
                else: ymax,ymin=max(ymax,yarr.max()+dy/2.),min(ymin,yarr.min()-dy/2.)
                setp(ima,"zorder",zorder)
            elif el[0] == "pc":
                sec=False
                if el[1][-1] == 2: sec=True
                xarr,yarr,zarr=array(figdata[el[1][0]]),array(figdata[el[1][1]]),array(figdata[el[1][2]])
                Nx,Ny,Nz=size(xarr),size(yarr),size(zarr)
                if rank(xarr) == 1 and rank(yarr) == 2: xarr=repeat([xarr],len(yarr),0)
                if rank(yarr) == 1 and rank(xarr) == 2: yarr=repeat(reshape(yarr,(len(yarr),1)),len(xarr[0]),1)
                if rank(xarr) == 1 and rank(zarr) == 1 and Nx == Nz:                                                                # "irregular", 1-D
                    dx=el[2][0]
                    if dx in [None,0]:
                        xarr0=sort(xarr.copy()); dxarr0=xarr0[1:]-xarr0[:-1]; dx=compress(dxarr0 > 0,dxarr0).min()
                    dy=el[2][1]
                    if dy in [None,0]:
                        yarr0=sort(yarr.copy()); dyarr0=yarr0[1:]-yarr0[:-1]; dy=compress(dyarr0 > 0,dyarr0).min()
                    xi=linspace(xarr.min(),xarr.max(),int((xarr.max()-xarr.min())/dx)+1)
                    yi=linspace(yarr.min(),yarr.max(),int((yarr.max()-yarr.min())/dy)+1)
                    zarr=griddata(ravel(xarr),ravel(yarr),ravel(zarr),xi,yi)
                    xarr,yarr=xi.copy(),yi.copy()
                elif rank(xarr) == 1 and rank(zarr) == 1 and Nx*Ny == Nz:                                                           # "regular", 2-D, x and y sorted
                    xarr,yarr=meshgrid(xarr,yarr)
                    zarr=reshape(zarr,xarr.shape)
                elif rank(xarr) == 1 and rank(zarr) == 2 and Nx == Nz: xarr,yarr=reshape(xarr,zarr.shape),reshape(yarr,zarr.shape)  # "regular", 2-D, x and y sorted
                elif rank(xarr) == 1 and rank(zarr) == 2 and Nx*Ny == Nz: xarr,yarr=meshgrid(xarr,yarr)                             # "regular", 2-D, x and y sorted
                elif rank(xarr) == 2 and rank(zarr) == 1 and Nx == Nz: zarr=reshape(zarr,xarr.shape)                                # "regular", 2-D, x and y sorted
                Cmap=plt.get_cmap(el[4][0])
                Extend="neither"
                zmin,zmax=el[2][3],el[2][4]
                if zmin == None: zmin=zarr.min()
                else:
                    Cmap.set_under(el[4][1])
                    if zmax != None: Extend="both"
                    else: Extend="min"
                if zmax == None: zmax=zarr.max()
                else:
                    Cmap.set_over(el[4][2])
                    if Extend == "neither": Extend="max"
                    else: Extend="both"
                Norm=mpl.colors.Normalize(vmin=zmin,vmax=zmax)
                if sec: ima=ax2.pcolor(xarr,yarr,zarr,cmap=Cmap,norm=Norm,edgecolors="none")
                else: ima=ax1.pcolor(xarr,yarr,zarr,cmap=Cmap,norm=Norm,edgecolors="none",shading="flat")
                if el[5][0] != 0:
                    cb=colorbar(ima,shrink=el[5][0],extend=Extend)
                    if el[5][1] != None: cb.set_ticks(el[5][1])
                    if el[3][0] != "": cb.set_label(el[3][0])
                xmax,xmin=max(xmax,xarr.max()),min(xmin,xarr.min())
                if sec: ymax2,ymin2=max(ymax2,yarr.max()),min(ymin2,yarr.min())
                else: ymax,ymin=max(ymax,yarr.max()),min(ymin,yarr.min())
                setp(ima,"zorder",zorder)
            elif el[0] == "b":
                sec=False
                if el[1][-1] == 2: sec=True
                bunit=array(figdata[el[1][0]],uint8)
                bleft=array(figdata[el[1][1]],float32)
                bheight=array(figdata[el[1][2]],float32)
                bwidth=array(figdata[el[1][3]],float32)
                if el[1][4] != None: bbottom=array(figdata[el[1][4]],float32)
                else: bbottom=zeros(bheight.shape,float32)
                if el[1][5] != None: byerr=array(figdata[el[1][5]],float32)
                else: byerr=None
                bright=bleft.copy()+bwidth.copy()
                if byerr != None: btop=bbottom.copy()+bheight.copy()+byerr.copy()
                else: btop=bbottom.copy()+bheight.copy()
                un=sublist(el[2][0],1)
                for u in un:
                    comarray=where(bunit == u,1,0)
                    bl=compress(comarray,bleft,0)
                    bh=compress(comarray,bheight,0)
                    bw=compress(comarray,bwidth,0)
                    bb=compress(comarray,bbottom,0)
                    by=None
                    if type(byerr) != type(None):
                        try: by=compress(comarray,byerr,0)
                        except: by=None
                    if bl.shape[0] != 0:
                        if sec: b=ax2.bar(bl,bh,bw,bb,yerr=by,capsize=lookup(u,el[3][3]),ecolor=lookup(u,el[3][4]))
                        else: b=ax1.bar(bl,bh,bw,bb,yerr=by,capsize=lookup(u,el[3][3]),ecolor=lookup(u,el[3][4]))
                        setp(b,"facecolor",lookup(u,el[3][0]),"linewidth",lookup(u,el[3][1]),"edgecolor",lookup(u,el[3][2]))
                        if lookup(u,el[2][0]) != "":
                            leg1.append(b[0]); leg2.append(lookup(u,el[2][0]))
                        setp(b,"zorder",zorder)
                if sec: ymax2,ymin2=max(ymax2,max(btop)),min(ymin2,min(bbottom))
                else: ymax,ymin=max(ymax,max(btop)),min(ymin,min(bbottom))
                xmax,xmin=max(xmax,max(bright)),min(xmin,min(bleft))
            elif el[0] == "t":
                horal=lookup(el[3][0],horlut,"left")
                vertal=lookup(el[3][1],vertlut,"bottom")
                if el[1][-1] == 2:
                    t=ax2.text(el[1][0],el[1][1],el[2][0],fontname=el[2][1],fontsize=el[2][2],fontweight=el[2][3],color=el[2][4],horizontalalignment=horal,verticalalignment=vertal,rotation=el[3][2])
                else:
                    t=ax1.text(el[1][0],el[1][1],el[2][0],fontname=el[2][1],fontsize=el[2][2],fontweight=el[2][3],color=el[2][4],horizontalalignment=horal,verticalalignment=vertal,rotation=el[3][2])
                setp(t,"zorder",zorder)
            elif el[0] == "ft":
                horal=lookup(el[3][0],horlut,"left")
                vertal=lookup(el[3][1],vertlut,"bottom")
                t=figtext(el[1][0],el[1][1],el[2][0],fontname=el[2][1],fontsize=el[2][2],fontweight=el[2][3],color=el[2][4],horizontalalignment=horal,verticalalignment=vertal,rotation=el[3][2])
                setp(t,"zorder",zorder)

        if tmargin != 0: figtext(W*(c+0.5),H*(nrow-r-figm),figlst[i][1][0],fontname=figlst[i][0][2][0][0],fontsize=figlst[i][0][3][0][0],fontweight=figlst[i][0][4][0][0],color=figlst[i][0][5][0][0],horizontalalignment="center",verticalalignment="top",rotation=0)
        if bmargin != 0: figtext(left+0.5*width,bottom-(H*bmargin),figlst[i][2][0],fontname=figlst[i][0][2][1][0],fontsize=figlst[i][0][3][1][0],fontweight=figlst[i][0][4][1][0],color=figlst[i][0][5][1][0],horizontalalignment="center",verticalalignment="bottom",rotation=0)
        if lmargin != 0: figtext(W*(c+figm),bottom+0.5*height,figlst[i][3][0],fontname=figlst[i][0][2][1][1],fontsize=figlst[i][0][3][1][1],fontweight=figlst[i][0][4][1][1],color=figlst[i][0][5][1][1],horizontalalignment="left",verticalalignment="center",rotation=90)
        if rmargin != 0: figtext(W*(c+1-figm),bottom+0.5*height,figlst[i][4][0],fontname=figlst[i][0][2][1][2],fontsize=figlst[i][0][3][1][2],fontweight=figlst[i][0][4][1][2],color=figlst[i][0][5][1][2],horizontalalignment="right",verticalalignment="center",rotation=90)

        try: xmin,xmax=figlst[i][2][1]
        except: pass
        try: ymin,ymax=figlst[i][3][1]
        except: pass
        try: ymin2,ymax2=figlst[i][4][1]
        except: pass
        if primsec[i] == 2:
            if figlst[i][3][1] == "y2y" or figlst[i][4][1] == "y2y":
                if figlst[i][3][1] != "y2y": ymin2,ymax2=ymin,ymax
                elif figlst[i][4][1] != "y2y": ymin,ymax=ymin2,ymax2
                else:
                    ymin=ymin2=min(ymin,ymin2); ymax=ymax2=max(ymax,ymax2)
            elif figlst[i][3][1] == "dy2y" or figlst[i][4][1] == "dy2y":
                interval=max(ymax-ymin,ymax2-ymin2)
                ymax=ymin+interval
                ymax2=ymin2+interval
        if xmin == xmax: xmin,xmax=xmin-1,xmax+1
        if ymin == ymax: ymin,ymax=ymin-1,ymax+1

        if bmargin == 0: ax1.set_xticklabels([])
        else:
            if type(figlst[i][2][2]) in [bool,int,long,float,bool_,uint8,uint16,uint32,uint64,int8,int16,int32,int64,float16,float32,float64]:
                try: figlst[i][2][2]=arange(figlst[i][2][3],xmax+figlst[i][2][2],figlst[i][2][2]).tolist()
                except: figlst[i][2][2]=arange(xmin-xmin%figlst[i][2][2],xmax+figlst[i][2][2],figlst[i][2][2]).tolist()
                figlst[i][2][3]=None
            if type(figlst[i][2][2]) in [list,tuple]:
                ax1.set_xticks(figlst[i][2][2])
            else: figlst[i][2][3]=None
            if type(figlst[i][2][3]) in [list,tuple]: ax1.set_xticklabels(figlst[i][2][3])
            elif type(figlst[i][2][5]) == str:
                if figlst[i][2][5][0] == "%":
                    try: ax1.set_xticklabels(formatlist(figlst[i][2][2],figlst[i][2][5]))
                    except: pass
                else:
                    xax=get(ax1,"xaxis")
                    try:
                        if figlst[i][2][5] == "format_abs_int": setp(xax,"major_formatter",FuncFormatter(format_abs_int))
                        if figlst[i][2][5] == "format_abs_fl1": setp(xax,"major_formatter",FuncFormatter(format_abs_fl1))
                        if figlst[i][2][5] == "format_abs_fl2": setp(xax,"major_formatter",FuncFormatter(format_abs_fl2))
                        if figlst[i][2][5] == "format_abs_fl3": setp(xax,"major_formatter",FuncFormatter(format_abs_fl3))
                        if figlst[i][2][5] == "format_abs_fl4": setp(xax,"major_formatter",FuncFormatter(format_abs_fl4))
                    except: pass
        if lmargin == 0: ax1.set_yticklabels([])
        else:
            if type(figlst[i][3][2]) in [bool,int,long,float,bool_,uint8,uint16,uint32,uint64,int8,int16,int32,int64,float16,float32,float64]:
                try: figlst[i][3][2]=arange(figlst[i][3][3],ymax+figlst[i][3][2],figlst[i][3][2]).tolist()
                except: figlst[i][3][2]=arange(ymin-ymin%figlst[i][3][2],ymax+figlst[i][3][2],figlst[i][3][2]).tolist()
                figlst[i][3][3]=None
            if type(figlst[i][3][2]) in [list,tuple]: ax1.set_yticks(figlst[i][3][2])
            else: figlst[i][3][3]=None
            if type(figlst[i][3][3]) in [list,tuple]: ax1.set_yticklabels(figlst[i][3][3])
            elif type(figlst[i][3][5]) == str:
                if figlst[i][3][5][0] == "%":
                    try: ax1.set_yticklabels(formatlist(figlst[i][3][2],figlst[i][3][5]))
                    except: pass
                else:
                    yax=get(ax1,"yaxis")
                    try:
                        if figlst[i][3][5] == "format_abs_int": setp(yax,"major_formatter",FuncFormatter(format_abs_int))
                        elif figlst[i][3][5] == "format_abs_fl1": setp(yax,"major_formatter",FuncFormatter(format_abs_fl1))
                        elif figlst[i][3][5] == "format_abs_fl2": setp(yax,"major_formatter",FuncFormatter(format_abs_fl2))
                        elif figlst[i][3][5] == "format_abs_fl3": setp(yax,"major_formatter",FuncFormatter(format_abs_fl3))
                        elif figlst[i][3][5] == "format_abs_fl4": setp(yax,"major_formatter",FuncFormatter(format_abs_fl4))
                    except: pass
        if primsec[i] == 2:
            if rmargin == 0: ax2.set_yticklabels([])
            else:
                if type(figlst[i][4][2]) in [bool,int,long,float,bool_,uint8,uint16,uint32,uint64,int8,int16,int32,int64,float16,float32,float64]:
                    try: figlst[i][4][2]=arange(figlst[i][4][3],ymax2+figlst[i][4][2],figlst[i][4][2]).tolist()
                    except: figlst[i][4][2]=arange(ymin2-ymin2%figlst[i][4][2],ymax2+figlst[i][4][2],figlst[i][4][2]).tolist()
                    figlst[i][4][3]=None
                if type(figlst[i][4][2]) in [list,tuple]: ax2.set_yticks(figlst[i][4][2])
                else: figlst[i][4][3]=None
                if type(figlst[i][4][3]) in [list,tuple]: ax2.set_yticklabels(figlst[i][4][3])
                elif type(figlst[i][4][5]) == str:
                    if figlst[i][4][5][0] == "%":
                        try: ax2.set_yticklabels(formatlist(figlst[i][4][2],figlst[i][4][5]))
                        except: pass
                    else:
                        yax2=get(ax2,"yaxis")
                        try:
                            if figlst[i][4][5] == "format_abs_int": setp(yax2,"major_formatter",FuncFormatter(format_abs_int))
                            if figlst[i][4][5] == "format_abs_fl1": setp(yax2,"major_formatter",FuncFormatter(format_abs_fl1))
                            if figlst[i][4][5] == "format_abs_fl2": setp(yax2,"major_formatter",FuncFormatter(format_abs_fl2))
                            if figlst[i][4][5] == "format_abs_fl3": setp(yax2,"major_formatter",FuncFormatter(format_abs_fl3))
                            if figlst[i][4][5] == "format_abs_fl4": setp(yax2,"major_formatter",FuncFormatter(format_abs_fl4))
                        except: pass

        xtl=get(ax1,"xticklabels")
        if len(xtl) > 0: setp(xtl,"fontname",figlst[i][0][2][2][0],"fontsize",figlst[i][0][3][2][0],"fontweight",figlst[i][0][4][2][0],"color",figlst[i][0][5][2][0],"rotation",figlst[i][2][4])
        ytl=get(ax1,"yticklabels")
        if len(ytl) > 0:
            setp(ytl,"fontname",figlst[i][0][2][2][1],"fontsize",figlst[i][0][3][2][1],"fontweight",figlst[i][0][4][2][1],"color",figlst[i][0][5][2][1],"rotation",figlst[i][3][4])
        if primsec[i] == 2:
            xtl2=get(ax2,"xticklabels")
            if len(xtl2) > 0: setp(xtl2,"fontname",figlst[i][0][2][2][0],"fontsize",figlst[i][0][3][2][0],"fontweight",figlst[i][0][4][2][0],"color",figlst[i][0][5][2][0],"rotation",figlst[i][2][4])
            ytl2=get(ax2,"yticklabels")
            if len(ytl2) > 0:
                setp(ytl2,"fontname",figlst[i][0][2][2][2],"fontsize",figlst[i][0][3][2][2],"fontweight",figlst[i][0][4][2][2],"color",figlst[i][0][5][2][2],"rotation",figlst[i][4][4])

        xt,yt,yt2=get(ax1,"xticklines"),get(ax1,"yticklines"),[]
        if primsec[i] == 2:
            yt2=get(ax2,"yticklines")
        if figlst[i][2][7] == "full":
            for n in xt: setp(n,"ms",0,"lw",figlst[i][2][8],"lc",figlst[i][2][9],"ls",figlst[i][2][9])
        else:
            for n in xt: setp(n,"ms",figlst[i][2][7],"mew",figlst[i][2][8],"mec",figlst[i][2][9])
        if figlst[i][3][7] == "full":
            for n in yt: setp(n,"ms",0,"lw",figlst[i][3][8],"lc",figlst[i][3][9],"ls",figlst[i][3][9])
        else:
            for n in yt: setp(n,"ms",figlst[i][3][7],"mew",figlst[i][3][8],"mec",figlst[i][3][9])
        if figlst[i][4][7] == "full":
            for n in yt2: setp(n,"ms",0,"lw",figlst[i][4][8],"lc",figlst[i][4][9],"ls",figlst[i][4][9])
        else:
            for n in yt2: setp(n,"ms",figlst[i][4][7],"mew",figlst[i][4][8],"mec",figlst[i][4][9])

        if len(leg1) > 0:
            leg=legend(leg1,leg2,loc=1,labelspacing=0)
            legtexts=get(leg,"texts")
            setp(legtexts,"fontname",figlst[i][0][2][0][1],"fontsize",figlst[i][0][3][0][1],"fontweight",figlst[i][0][4][0][1],"color",figlst[i][0][5][0][1])
            setp(get(leg,"frame"),"linewidth",0)

        if figlst[i][2][6]: ax1.set_xlim((xmax+(xmax-xmin)*space1,xmin-(xmax-xmin)*space1))
        else: ax1.set_xlim((xmin-(xmax-xmin)*space1,xmax+(xmax-xmin)*space1))
        if figlst[i][3][6]: ax1.set_ylim((ymax+(ymax-ymin)*space1,ymin-(ymax-ymin)*(space1+space2*len(leg1))))
        else: ax1.set_ylim((ymin-(ymax-ymin)*space1,ymax+(ymax-ymin)*(space1+space2*len(leg1))))
        if primsec[i] == 2:
            if figlst[i][2][6]: ax2.set_xlim((xmax+(xmax-xmin)*space1,xmin-(xmax-xmin)*space1))
            else: ax2.set_xlim((xmin-(xmax-xmin)*space1,xmax+(xmax-xmin)*space1))
            if ymin2 == ymax2: ymin2,ymax2=ymin2-1,ymax2+1
            if figlst[i][4][6]: ax2.set_ylim((ymax2+(ymax2-ymin2)*space1,ymin2-(ymax2-ymin2)*(space1+space2*len(leg1))))
            else: ax2.set_ylim((ymin2-(ymax2-ymin2)*space1,ymax2+(ymax2-ymin2)*(space1+space2*len(leg1))))

    return graph

## Zie ook getminmax hieronder
def getyminmax(datalist,nodata=-9999):
    yminlist1,ymaxlist1,yminlist2,ymaxlist2=[],[],[],[]
    for i in range(0,len(datalist[0])):
        datarr=ravel(array(datalist[0][i])); datarr=compress(where(datarr == nodata,0,1),datarr,0)
        yminlist1.append(datarr.min()); ymaxlist1.append(datarr.max())
    ymin1,ymax1=min(yminlist1),max(ymaxlist1)
    if len(datalist) == 2:
        for i in range(0,len(datalist[1])):
            datarr=array(datalist[1][i]); datarr=compress(where(datarr == nodata,0,1),datarr,0)
            yminlist2.append(datarr.min()); ymaxlist2.append(datarr.max())
        try:
            ymin2,ymax2=min(yminlist2),max(ymaxlist2)
        except:
            ymin2,ymax2=ymin1,ymax1
    else:
        ymin2,ymax2=ymin1,ymax1
    yrange1,yrange2=ymax1-ymin1,ymax2-ymin2
    mult,ivl,iv0,end=1,[1/12.,0.25,0.5,1,2,5],1/12.,0
    while 1:
        for i in range(0,len(ivl)):
            iv=ivl[i]*mult
            if max(yrange1,yrange2)/iv <= 5:
                if max(yrange1,yrange2)/iv0 <= 10:
                    iv=iv0
                end=1; break
            iv0=iv
        mult=mult*10
        if end:
            break
    ymin1,ymax1=ymin1-ymin1%iv,ymax1+(bool(ymax1%iv)*iv-ymax1%iv)
    ymin2,ymax2=ymin2-ymin2%iv,ymax2+(bool(ymax2%iv)*iv-ymax2%iv)
    yrange1,yrange2=ymax1-ymin1,ymax2-ymin2
    if yrange1 > yrange2:
        ymax2=ymax2+(yrange1-yrange2); nint=int(yrange1/iv)
    else:
        ymax1=ymax1+(yrange2-yrange1); nint=int(yrange2/iv)
    return [[ymin1,ymax1],[ymin2,ymax2]],iv,nint

def getminmax(datalist,nodata=-9999,yearmonth=False):
    minlist1,maxlist1,minlist2,maxlist2=[],[],[],[]
    for i in range(0,len(datalist[0])):
        datarr=ravel(array(datalist[0][i])); datarr=compress(where(datarr == nodata,0,1),datarr,0)
        minlist1.append(datarr.min()); maxlist1.append(datarr.max())
    min1,max1=min(minlist1),max(maxlist1)
    if len(datalist) == 2:
        for i in range(0,len(datalist[1])):
            datarr=array(datalist[1][i]); datarr=compress(where(datarr == nodata,0,1),datarr,0)
            minlist2.append(datarr.min()); maxlist2.append(datarr.max())
        try:
            min2,max2=min(minlist2),max(maxlist2)
        except:
            min2,max2=min1,max1
    else:
        min2,max2=min1,max1
    range1,range2=max1-min1,max2-min2
    mult=10**(get_power10(min(range1,range2))-1)
    ivl=[1.,2.,2.5,5.]
    if yearmonth:
        mult,ivl=1,[1/12.]+ivl
    iv0=ivl[0]
    end=False
    while 1:
        for i in range(0,len(ivl)):
            iv=ivl[i]*mult
            if max(range1,range2)/iv <= 5:
                if max(range1,range2)/iv0 <= 10+bool(yearmonth)*8:
                    iv=iv0
                end=1; break
            iv0=iv
        if end:
            break
        mult=mult*10
        if yearmonth: ivl=ivl[1:]
    try:
        if iv/(min1%iv) > 1.001: min1=min1-min1%iv
    except: pass
    try:
        if iv/(min2%iv) > 1.001: min2=min2-min2%iv
    except: pass
    nint=1
    while True:
        if (max1-(min1+nint*iv))/iv < 0.001 and (max2-(min2+nint*iv))/iv < 0.001: break
        nint=nint+1
    min1,min2=float(min1),float(min2)
    max1,max2=min1+nint*iv,min2+nint*iv
    form="%.0f"
    rec=string.split("%s" %(iv),".")
    if len(rec) > 1:
        if rec[1][-1] != "0": form="%%.%df" %(len(rec[1]))
        if iv == 1/12.: form="%.4f"
    return [[min1,max1],[min2,max2]],iv,nint,form

def get_legclas(vl,n=10):
    vl=array(vl,float64)
    vmin,vmax=vl.min(),vl.max()
    vspan=vmax-vmin
    w=vspan/n
    pwr=get_power10(w)
    if w == 10**pwr: pwr-=1
    w_arr=10**pwr*array([2,5,10],float64)
    w=compress(w_arr >= w,w_arr).min()
    if int(vmin/w)*w > vmin:
        return arange((int(vmin/w)-1)*w,vmax+w,w)
    else:
        return arange(int(vmin/w)*w,vmax+w,w)

def get_legfrm(vl,n=10):
    vl=array(vl,float64)
    vmin,vmax=vl.min(),vl.max()
    vspan=vmax-vmin
    w=vspan/n
    pwr1=get_power10(w)
    if pwr1 >= 0: pwr1+=1
    pwr2=get_power10(vmax)
    if pwr2 >= 0: pwr2+=1
    nsig=pwr2-pwr1+1
    if pwr1 < 0:
        ndeci=abs(pwr1)
        ndigit=max(ndeci+2,nsig)
    else:
        ndeci=0
        ndigit=nsig
    if ndigit > nsig+4: frm="%%.%de" %(nsig-1)
    else: frm="%%.%df" %(ndeci)
    return frm

def get_legticks(vl,n=10):
    tp=get_legclas(vl,n)
    frm=get_legfrm(vl,n)
    tt,ex=[],""
    if frm[-1] in ["E","e"]:
        ex=(frm %(tp[-1]))[-4:]
        exec("div=1%s" %(ex))
        tp0=tp.copy()/div
        frm0="%sf" %(frm[:-1])
        for i in range(0,len(tp)): tt.append(frm0 %(tp0[i]))
    else:
        for i in range(0,len(tp)): tt.append(frm %(tp[i]))
    while True:
        quit=False
        for i in range(0,len(tt)):
            if string.find(tt[i],".") == -1 or (tt[i][-1] != "0" and tt[i][-1] != "."):
                quit=True; break
        if quit: break
        for i in range(0,len(tt)):
            tt[i]=tt[i][:-1]
    if ex != "":
        tt=[tt[i]+ex for i in range(0,len(tt))]
    return tp,tt

##def tt2xaxis(tt,n=10,dateformat="yyyy-mm-dd"):
##    iarr=arange(0,len(tt))
##    if len(tt) <= n: cparr=ones((len(tt)),bool)
##    elif len(tt) <= n*2: cparr=resize(array([1,0],bool),(len(tt)))
##    else:
##        cparr=((tt[:,2] == 1)+(tt[:,2] == 15)) > 0
##        if cparr.sum() > n:
##            for dm in [1,2,3,4,6,12]:
##                cparr=zeros((len(tt)),bool)
##                for m in range(tt[0,1],tt[0,1]+12,dm):
##                    cparr+=(tt[:,1] == m)*(tt[:,2] == 1)
##                if cparr.sum() <= n: break
##        if cparr.sum() > n:
##            dy=1
##            while True:
##                cparr=zeros((len(tt)),bool)
##                for y in range(tt[0,0],tt[-1,0]+1,dy):
##                    cparr+=(tt[:,0] == y)*(tt[:,1] == tt[0,1])*(tt[:,2] == 1)
##                if cparr.sum() <= n: break
##                dy+=1
##    return iarr,cparr,compress(cparr,iarr,0),tt2date(compress(cparr,tt,0),dateformat)

def tt2xaxis(tt,nmax=10,frm="yyyy-mm-dd",incl_startend=True):
    nday=periodday(tt[0],tt[-1])+1
    di=nday/nmax
    ii=arange(0,nday)
    if di <= 1:
        pass
    elif di <= 15:
        ii=ii[logical_or(tt[:,2] == 1,tt[:,2] == 15)]
    else:
        if di <= 183:
            ii=ii[tt[:,2] == 1]
            if di <= 31:
                pass
            elif di <= 61:
                ii=ii[arange(0,len(ii))%2 == 0]
            elif di <= 91:
                ii=ii[arange(0,len(ii))%3 == 0]
            elif di <= 122:
                ii=ii[arange(0,len(ii))%4 == 0]
            else:
                ii=ii[arange(0,len(ii))%6 == 0]
        else:
            if tt[0,2] != 1:
                if tt[0,1] == 12: ii=ii[(tt[:,1] == 1)*(tt[:,2] == 1)]
                else: ii=ii[(tt[:,1] == tt[0,1]+1)*(tt[:,2] == 1)]
            else: ii=ii[(tt[:,1] == tt[0,1])*(tt[:,2] == 1)]
            ii=take(ii,arange(0,len(ii),di/366+1),0)
    if incl_startend:
        if ii[0] > 1:  ii=insert(ii,0,0)
        if ii[-1] < nday-2: ii=insert(ii,len(ii),nday-1)
    if nday != len(tt):
        tt2=array(startend2tt(tt2date(tt[0]),tt2date(tt[-1])),uint16)
        date=tt2date(tt2,frm)
    else: date=tt2date(tt,frm)
    return ii,take(date,ii,0),arange(0,len(date)),date


## IMAGE FUNCTIONS ##

def getcolorpalette(colormodel):
    try:
        colormodel=string.lower(string.replace(colormodel," ","")); colorscale,colorpalette=colormodel[0],[]
        if colormodel[1:] in ["","0"]:
            colors=10
        elif colormodel[1:] in ["-","-0"]:
            colors=-10
        else:
            try:
                colors=int(colormodel[1:])
            except:
                colors=10
        if colorscale in ["g","h"]:
            first=255.0
            if colorscale == "h":
                first=230.0
            for n in range(0,abs(colors)):
                if colors == 1:
                    x=first
                elif colors == -1:
                    x=0.0
                elif colors > 1:
                    x=n*first/(colors-1)
                else:
                    x=first-n*first/(-colors-1)
                colorpalette.append((int(first-x),int(first-x),int(first-x)))
        else:
            for n in range(0,abs(colors)):
                if colors == 1:
                    x=215.0
                elif colors == -1:
                    x=0.0
                elif colors > 1:
                    x=n*215.0/(colors-1)
                else:
                    x=215-n*215.0/(-colors-1)
                if x < 43:
                    R,G,B=255-(255.0/43)*x,0,255
                elif x < 86:
                    R,G,B=0,(255.0/43)*(x-43),255
                elif x < 129:
                    R,G,B=0,255,255-(255.0/43)*(x-86)
                elif x < 172:
                    R,G,B=(255.0/43)*(x-129),255,0
                else:
                    R,G,B=255,255-(255.0/43)*(x-172),0
                colorpalette.append((int(R),int(G),int(B)))
    except:
        colorpalette=colormodel
    return colorpalette

def maps2im_avi(maplist=[],arrayname="maparray",mvmap=None,imageformat=None,avifile=None,avigap=1,\
                 interval=None,mvcolor=(0,0,0),outcolor=(0,0,0),colorpalette="c10",\
                 legendtype="scalar",legendcolor=((0,0,0),(255,255,255)),legendfont=None,legendlabels=None,legendresizefact=1):
    if imageformat != None or avifile != None:
        mvarray,mvisarray,mvisfile=None,False,False
        # Maps > array
        print "\n\tReading maps"
        try:
            if len(maplist.shape) == 2:
                maparray=array([maplist])
            else:
                maparray=maplist.copy()
            mvarray=zeros(maparray.shape,uint8)
            maplist=[]
            for n in range(0,maparray.shape[0]):
                maplist.append(str(arrayname)+"%s" %(n))
            print "\t > Map array read"
        except:
            count,truemaplist=0,[]
            for n in range(0,len(maplist)):
                try:
                    map1array=spatial2array(maplist[n])
                    print map1array.shape
                    if map1array.dtype.name == uint8:
                        mapmvarray=where(map1array == 255,1,0)
                    elif map1array.dtype.name == int32:
                        mapmvarray=where(map1array == -2**31,1,0)
                    else:
                        mapmvarray=isnan(map1array)
                    if count == 0:
                        maparray,count=array([map1array]),1
                        mvarray=array([mapmvarray])
                    else:
                        maparray=concatenate([maparray,[map1array]])
                        mvarray=array(concatenate([mvarray,[mapmvarray]]),uint8)
                    print "\t >",maplist[n],"read"
                    truemaplist.append(maplist[n])
                except:
                    pass
            maplist=truemaplist
        if maplist != []:
            try:
                mvshape=mvmap.shape
                if mvshape == maparray.shape:
                    mvarray=where(mvarray == 1,1,mvmap)
                    print "\t > Missing values array read"
                elif mvshape == maparray.shape[1:]:
                    mvarray=where(mvarray == 1,1,repeat([mvmap],maparray.shape[0],0))
                    print "\t > Missing values array read"
                else:
                    "\t > Missing values array has different shape"
            except:
                if mvmap != None:
                    try:
                        mvmaparray=array(map2array(mvmap,0),uint8)
                        if mvmaparray.shape == maparray.shape[1:]:
                            mvarray=where(mvarray == 1,1,repeat([mvmaparray],maparray.shape[0],0))
                            print "\t >",mvmap,"read (missing values map)"
                        else:
                            print "\t >",mvmap,"has different shape (missing values map)"
                    except:
                        print "\t > ERROR in reading",mvmap,"(missing values map)"
            if interval != None:
                min,max=float(interval[0]),float(interval[1])
            elif mvarray != None:
                mapmaskarray=MA.array(maparray,mask=mvarray)
                min,max=float(mapmaskarray.min()),float(mapmaskarray.max())
            else:
                min,max=float(maparray.min()),float(maparray.max())
            outflag,mvflag=0,0
            if mvarray != None:
                maparray=where(mvarray == 1,min,maparray)
                if mvarray.max() != 0:
                    mvflag=1
            if maparray.min() < min or maparray.max() > max:
                outflag=1
            nlay,nrow,ncol=maparray.shape
            # Color palette, Color array
            print "\tCreating color scale and legend"
            colarray=zeros((nlay,nrow,ncol),int8)
            if string.find(string.lower(str(colorpalette))[1:],"m") != -1:
                colorpalette=string.lower(string.replace(str(colorpalette)," ",""))
                valarray,vallist,val=sort(compress(where(ravel(mvarray)==0,1,0),ravel(maparray),0)),[],min
                for n in range(0,valarray.shape[0]):
                    if valarray[n] > max:
                        break
                    elif len(vallist) == 0 and valarray[n] >= val:
                        val=valarray[n]; vallist.append(val)
                    elif valarray[n] > val:
                        val=valarray[n]; vallist.append(val)
                if string.find(colorpalette[1:],"-") != -1:
                    colorpalette=colorpalette[0]+"-"+str(minimum(len(vallist),256-mvflag-outflag))
                else:
                    colorpalette=colorpalette[0]+str(minimum(len(vallist),256-mvflag-outflag))
                colpal,textlist,forpad=getcolorpalette(colorpalette),[],1
                for n in range(0,len(vallist)):
                    colarray=where(maparray == vallist[n],n,colarray.copy()); textlist.append("%g" %(vallist[n]))
            else:
                if len(colorpalette[0]) == 2:
                    colpal,textlist,forpad,vallist=[],[],1,[]
                    for n in colorpalette:
                        colpal.append(n[1]); vallist.append(n[0])
                    for n in range(0,len(vallist)):
                        colarray=where(maparray == vallist[n],n,colarray.copy()); textlist.append("%g" %(vallist[n]))
                else:
                    if len(colorpalette[0]) == 3:
                        colpal,textlist,forpad=colorpalette,[],0
                    else:
                        colorpalette=string.lower(string.replace(str(colorpalette)," ",""))
                        if colorpalette[1:] in ["","0"]:
                            colors=10
                        elif colorpalette[1:] in ["-","-0"]:
                            colors=-10
                        else:
                            try:
                                colors=int(colorpalette[1:])
                            except:
                                colors=10
                        if colors > 256-mvflag-outflag:
                            colors=256-mvflag-outflag
                        elif colors < -256+mvflag+outflag:
                            colors=-256+mvflag+outflag
                        colorpalette=colorpalette[0]+str(colors); colpal,textlist,forpad=getcolorpalette(colorpalette),[],0
                    colarray=array((maparray.copy()-min)/((max-min)/len(colpal)),int8); colarray=where(maparray == max,len(colpal)-1,colarray)
                    if string.lower(str(legendtype)) != "scalar":
                        forpad=1
                        for n in range(0,len(colpal)):
                            textlist.append("%i" %(min+n*(max-min)/(len(colpal)-1)))
                    else:
                        for n in range(0,len(colpal)):
                            textlist.append("%g" %(min+n*(max-min)/(len(colpal))))
                        textlist.append("%g" %(max))
            # Out of range / missing value
            if outflag == 1:
                colarray,colpal[0:0],textlist[0:0]=colarray+1,[outcolor],["Out of range"]
                colarray=where(maparray > max,0,colarray); colarray=where(maparray < min,0,colarray)
            if mvflag == 1:
                colarray,colpal[0:0],textlist[0:0]=colarray+1,[mvcolor],["Missing value"]; colarray=where(mvarray == 1,0,colarray)
            # Image format
            if imageformat != None:
                if string.upper(imageformat) == "BMP":
                    imageformat,extension="BMP","bmp"
                elif string.upper(imageformat) == "EPS":
                    imageformat,extension="EPS","eps"
                elif string.upper(imageformat) == "GIF":
                    imageformat,extension="GIF","gif"
                elif string.upper(imageformat) in ["JPEG","JPG"]:
                    imageformat,extension="JPEG","jpg"
                elif string.upper(imageformat) in ["TIFF","TIF"]:
                    imageformat,extension="TIFF","tif"
                elif string.upper(imageformat) == "PNG":
                    imageformat,extension="PNG","png"
                else:
                    imageformat,extension=None,"png"
            else:
                extension="png"
            # Legend
            for n in [legendfont,"arialn.ttf","arial.ttf","refsan.ttf","verdana.ttf","times.ttf","cour.ttf"]:
                try:
                    font=ImageFont.truetype(n,int(30*legendresizefact))
                    break
                except:
                    pass
            legtest,textwidth=ImageDraw.Draw(Image.new("RGB",(100,100))),0
            if legendlabels != None:
                for n in range(0,minimum(len(legendlabels),len(textlist)-mvflag-outflag)):
                    textlist[n+mvflag+outflag]=str(legendlabels[n])
            for n in textlist:
                textwidthnew,textheight=legtest.textsize(n,font)[0],legtest.textsize(n,font)[1]
                if textwidthnew > textwidth:
                    textwidth=textwidthnew
            pad1,pad2,pad3,rect=textheight/2,textheight/2,textheight/4,(textheight*2,textheight)
            shift=(mvflag+outflag)*(rect[1]+pad3)+(1-forpad)*(bool(mvflag+outflag)+1)*rect[1]/2
            size=(2*pad1+pad2+rect[0]+textwidth,\
                  2*pad1+shift+(len(textlist)-mvflag-outflag)*(rect[1]+forpad*pad3)-(1-forpad)*rect[1]/2)
            legend=Image.new("RGB",size,legendcolor[0]); leg=ImageDraw.Draw(legend)
##            for n in range(0,mvflag+outflag):
##                leg.text((pad1+rect[0]+pad2,pad1+n*rect[1]+n*pad3),textlist[n],legendcolor[1],font)
##                leg.rectangle([pad1,pad1+n*rect[1]+n*pad3,pad1+rect[0],pad1+n*rect[1]+n*pad3+rect[1]],outline=legendcolor[1],fill=colpal[n])
            for n in range(mvflag+outflag,len(textlist)):
                leg.text((pad1+rect[0]+pad2,pad1+shift+(n-mvflag-outflag)*(rect[1]+forpad*pad3)-(1-forpad)*rect[1]/2),\
                         textlist[-n-1+mvflag+outflag+len(textlist)],legendcolor[1],font)
                if forpad == 0 and n == len(textlist)-1:
                    break
                leg.rectangle([pad1,pad1+shift+(n-mvflag-outflag)*(rect[1]+forpad*pad3),\
                               pad1+rect[0],pad1+shift+(n-mvflag-outflag)*(rect[1]+forpad*pad3)+rect[1]],\
                              outline=legendcolor[1],fill=colpal[-n-1+mvflag+outflag+len(colpal)])
            if os.path.dirname(maplist[0]) == "":
                legendfile="%s/Legend.%s" %(string.lower(os.getcwd()),extension)
            else:
                legendfile="%s/Legend.%s" %(string.lower(os.path.dirname(maplist[0])),extension)
            legend.save(legendfile)
            print "\t >",legendfile,"created"
            # AVI
            if avifile != None:
                print "\tWait for the AVI animation to be created..."
                ncolnew=ncol*3
                if ncolnew/4.0 == int(ncolnew/4.0):
                    extracol=0
                else:
                    extracol=int((1-(ncolnew/4.0)+int(ncolnew/4.0))*4)
                outf=open(avifile,"wb")
                outf.write(struct.pack("=4sl4s4sl4s","RIFF",0,"AVI ","LIST",4 + 8+56 + 8+4 + 8+56 + 8+40 + 8+16,"hdrl"))
                outf.write(struct.pack("=4s15l","avih",56,avigap*1e6,nrow*(ncolnew+extracol),0,2064,nlay,0,1,nrow*(ncolnew+extracol),ncol,nrow,0,0,0,0))
                outf.write(struct.pack("=4sl4s","LIST",4+3*8+56+40+16,"strl"))
                outf.write(struct.pack("=4sl4s4s12l","strh",56,"vids","DIB ",0,0,0,1000,1000/avigap,0,nlay,nrow*(ncolnew+extracol),0,0,0,524296))
                outf.write(struct.pack("=4sl 3l28b","strf",40,40,ncol,nrow,1,0,24,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0))
                outf.write(struct.pack("=4sl16s","strn",16,"PCR animation   "))
                outf.write(struct.pack("=4sl4s","LIST",(nrow*(ncolnew+extracol)+8)*nlay+4,"movi"))
                for l in range(0,nlay):
                    outf.write(struct.pack("=4sl","00db",nrow*(ncolnew+extracol)))
                    for r in range(0,nrow):
                        for c in range(0,ncol):
                            R,G,B=colpal[colarray[l,-r-1+nrow,c]]; outf.write(struct.pack("=3b",B,G,R))
                        for c in range(0,extracol):
                            outf.write(struct.pack("=b",0))
                outf.write(struct.pack("=4sl","idx1",16*nlay))
                for n in range(0,nlay):
                    outf.write(struct.pack("=4s3l","00db",16,4+n*(nrow*(ncolnew+extracol)+8),nrow*(ncolnew+extracol)))
                outf.close()
                print "\t >",avifile,"created"
            # Images
            if imageformat != None:
                print "\tWait for the images to be created..."
                colpal2=[]
                for n in colpal:
                    colpal2.append(n[0]); colpal2.append(n[1]); colpal2.append(n[2])
                for l in range(0,nlay):
                    im=Image.fromstring("P",(ncol,nrow),colarray[l].tostring())
                    im.putpalette(colpal2)
                    if imageformat == "JPEG":
                        im.convert("RGB").save("%s.%s" %(maplist[l],extension),imageformat,quality=100)
                    else:
                        im.save("%s.%s" %(maplist[l],extension),imageformat,quality=90)
                    print "\t > %s.%s created" %(maplist[l],extension)
            print "\n"
        else:
            print "\n\tNo maps found\n"
    else:
        print "\n\tNothing to do: imageformat=None and avifile=None\n"
