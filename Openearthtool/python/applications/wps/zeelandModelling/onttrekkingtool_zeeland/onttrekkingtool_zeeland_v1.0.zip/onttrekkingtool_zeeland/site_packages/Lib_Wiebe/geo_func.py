## GEO FUNCTIONS ##

## IMPORTING MODULES ##

try:
    from general_func import *
    from statistic_func import *
    import mmap
    import numpy.ma as MA
    try: import osgeo.gdal
    except: pass
    import shapefile
    from PIL import Image, ImageDraw
    from win32com.client import Dispatch
except:
    pass


## RASTER/GRID FUNCTIONS ##

def readmaptype(mapfile):
    maptype=["Invalid map type","ASCII Grid","IDF","PCRaster","ESRI Grid","MODFLOW column file","IPF"]
    ext=    [""                ,"asc"       ,"idf","map"     ,""         ,"dat"                ,"ipf"]
    if type(mapfile) != str:
        return maptype[0]
    elif mapfile == "return_all":
        return maptype
    elif mapfile == "return_ext" or mapfile == "return_all_ext":
        return ext
    elif not os.path.isfile(mapfile) and not os.path.isdir(mapfile):
        return maptype[0]
    else:
        source=0
        if source == 0:
            try:
                inf=open(mapfile,"rb"); magic=struct.unpack("=27s",inf.read(27))[0]; inf.close()
                if magic == "RUU CROSS SYSTEM MAP FORMAT":
                    source=3
            except:
                try:
                    inf.close()
                except:
                    pass
        if source == 0:
            try:
                inf=open(mapfile,"rb")
                x1,nc,nr,xll,xur,yll,yur,minval,maxval,missing,ieq,itb,mfct,x2,cellsizex,cellsizey=struct.unpack("=3L 7f 4B 2f",inf.read(52))
                inf.close()
                if x1 == 1271:
                    if ieq == 0 and abs(abs(xur-xll)/nc-cellsizex) < 1e-6 and abs(abs(yur-yll)/nr-cellsizey) < 1e-6:
                        source=2
                    elif ieq != 0:
                        if xur > xll and yur > yll and xur <= yll: source=2
            except:
                try:
                    inf.close()
                except:
                    pass
        if source == 0:
            try:
                inf=open(mapfile,"r"); rec1=string.split(inf.readline()); nrec=int(string.split(inf.readline())[0])
                if rec1[0] == "SCD":
                    nrec1=nrec
                else:
                    nrec1=int(rec1[0])
                if nrec1 > 0 and nrec >= 0 and nrec1 >= nrec:
                    rec=string.split(inf.readline())
                    if len(string.split(inf.readline())) > 3:
                        source=5
                inf.close()
            except:
                try:
                    inf.close()
                except:
                    pass
        if source == 0:
            try:
                inf=open(mapfile,"r"); nrec=int(string.split(inf.readline())[0]); nfield=int(string.split(inf.readline())[0])
                if nrec > 0 and nfield >= 3:
                    xfield,yfield=None,None
                    for i in range(0,nfield):
                        rec=string.split(inf.readline())
                        if string.strip(rec[0]) in ["x","X"]:
                            xfield=i
                        elif string.strip(rec[0]) in ["y","Y"]:
                            yfield=i
                    inf.readline()
                    if xfield != None and yfield != None:
                        if len(string.split(inf.readline())) >= nfield:
                            source=6
                inf.close()
            except:
                try:
                    inf.close()
                except:
                    pass
        if source == 0:
            try:
                lines=[]
                inf=open(mapfile,"r")
                for i in range(0,5):
                    lines.append(string.split(string.lower(inf.readline())))
                    eval(lines[i][1])+0.0
                inf.close()
                found=1
                for i in range(0,5):
                    if len(lines[i]) != 2 or string.find(lines[i][0],["ncol","nrow","xll","yll","cel"][i]) == -1:
                        found=0; break
                if found:
                    source=1
            except:
                try:
                    inf.close()
                except:
                    pass
        if source == 0:
            try:
                if os.path.isfile(mapfile+"/hdr.adf"):
                    gd=osgeo.gdal.Open(r'%s' %(mapfile))
                    sn=gd.GetDriver().ShortName; del gd
                    if sn == "AIG":
                        source=4; del gd
            except:
                try:
                    del gd
                except:
                    pass
        return maptype[source]

def readascheader(mapfile):
    inf=open(mapfile,"r")
    ncol=int(string.split(inf.readline())[-1])
    nrow=int(string.split(inf.readline())[-1])
    xcen,ycen=0,0
    rec=string.split(string.lower(inf.readline()))
    xll,xllc=float(rec[-1]),None
    if string.find(rec[0],"center") != -1:
        xllc=xll; xll=None
    rec=string.split(string.lower(inf.readline()))
    yll,yllc=float(rec[-1]),None
    if string.find(rec[0],"center") != -1:
        yllc=yll; yll=None
    cellsize=float(string.split(inf.readline())[-1])
    try:
        rec=string.split(string.lower(inf.readline()))
        if rec[0] == "nodata_value":
            nodata=float(rec[-1])
            if nodata-int(nodata) == 0:
                nodata=int(nodata)
    except:
        nodata=None
    inf.close()
    return [ncol,nrow,xll,xllc,yll,yllc,cellsize,nodata] # ncol,nrow,xll,xllc,yll,yllc,cellsize,nodata

def readidfheader(mapfile,all_dxdy=False):
    inf=open(mapfile,"rb")
    header=list(struct.unpack("=3L 7f 4B",inf.read(44)))
    ncol,nrow=header[1:3]
    if header[10] == 0:
        dx,dy=struct.unpack("=2f",inf.read(8))
        if all_dxdy: dx,dy=ones((ncol,),float32)*dx,ones((nrow,),float32)*dy
    else:
        if header[11] == 1: inf.read(8)
        dx,dy=reshape(fromstring(inf.read(ncol*4),float32),(ncol,)),reshape(fromstring(inf.read(nrow*4),float32),(nrow,))
        if not all_dxdy: dx,dy=dx.mean(),dy.mean()
    header=header+[dx,dy]
    inf.close()
    return header # x1,ncol,nrow,xll,xur,yll,yur,minval,maxval,nodata,ieq,itb,mfct,x2,cellsizex,cellsizey
                  # x1: 1271; x2=empty

def readmapheader(mapfile):
    inf=open(mapfile,"rb"); header=list(struct.unpack("=27s 5B HLHLHL 14B HH",inf.read(68)))
    if header[27] == 0:
        header=header+list(struct.unpack("=H 6s H 6s",inf.read(16)))
    elif header[27] == 38:
        header=header+list(struct.unpack("=llll",inf.read(16)))
    else:
        header=header+list(struct.unpack("=flfl",inf.read(16)))
    header=header+list(struct.unpack("=ddLLddd",inf.read(48))); inf.close()
    return header # sig,x1,x2,x3,x4,x5,version,gisid,proj,attr,datatype,byteorder,x6,x7,x8,x9,x10,x11,x12,x13,x14,x15,x16,x17,x18,x19,valscale,cellrepr,minval,x20,maxval,x21,xul,yul,nrow,ncol,cellsizex,cellsizey,angle
                  # x1-21: 0

def readgridheader(mapfile):
    gd=osgeo.gdal.Open(mapfile)
    layer=gd.GetRasterBand(1)
    nrow=gd.RasterYSize
    ncol=gd.RasterXSize
    xll,cellsizex,rot1,yul,rot2,cellsizey=gd.GetGeoTransform()
    datatype=osgeo.gdal.GetDataTypeName(layer.DataType)
    #datatypes=["Byte","CFloat32","CFloat64","CInt16","CInt32","Float32","Float64","Int16","Int32","UInt16","UInt32"]
    nodata=layer.GetNoDataValue()
    minval,maxval=layer.GetMinimum(),layer.GetMaximum()
    del gd
    if datatype in ["Byte","Int16","Int32","UInt16","UInt32"]:
        nodata,minval,maxval=int(nodata),int(minval),int(maxval)
    return [nrow,ncol,xll,abs(cellsizex),rot1,yul,rot2,abs(cellsizey),datatype,nodata,minval,maxval] # nrow,ncol,xll,cellsizex,rot1,yul,rot2,cellsizey,datatype,nodata,minval,maxval

def readsource(mapfile):
    return readmaptype("return_all").index(readmaptype(mapfile))

def source2ext(mapfile_or_source):
    ext=readmaptype("return_ext")
    if mapfile_or_source == "return_all":
        return ext
    if type(mapfile_or_source) != int:
        mapfile_or_source=readsource(mapfile_or_source)
    else:
        if mapfile_or_source not in range(0,len(ext)):
            mapfile_or_source=0
    return ext[mapfile_or_source]

def ext2source(mapfile_or_ext,none=0):
    ext=source2ext("return_all")
    x=""
    sp=splitpath(mapfile_or_ext)
    if sp[2] != "":
        x=sp[2]
    elif sp[0] == "":
        x=sp[1]
    if x not in ext:
        if type(none) in [int,long,uint8,uint16,uint32,uint64,int8,int16,int32,int64]:
            if none in range(0,len(ext)):
                return none
        x=""
    return ext.index(x)

def target2mapfile(target,mapfile):
    sp=splitpath(mapfile)
    if sp[2] == "":
        sp[2]=source2ext(target)
        mapfile=joinpath(sp)
    return mapfile

def mapfile2mapfile(mapfile):
    try:
        source=readsource(mapfile)
    except:
        source=0
    if source == 0:
        sp=splitpath(mapfile)
        for ext in ["idf","map","asc","","dat","ipf"]:
            mapfile0=joinpath([sp[0],sp[1],ext])
            source=readsource(mapfile0)
            if source != 0:
                mapfile=mapfile0; break
    return mapfile

def readmapproperties(mapfile,none=[0.0,0.0,1.0,1.0,1,0.0,0,0,None,None,None,None,None,0,None]):
    try:
        source=readsource(mapfile)
    except:
        source=0
    props=none
    if source == 1:
        ncol,nrow,xll,xllc,yll,yllc,cellsize,nodata=readascheader(mapfile)
        if xll == None:
            xll=xllc-0.5*cellsize
        if yll == None:
            yll=yllc-0.5*cellsize
        cellsizex=cellsizey=cellsize
        proj,angle,minval,maxval,mapformat,datatype=1,0.0,None,None,"nominal/scalar","int/float"
    elif source ==2:
        x1,ncol,nrow,xll,xur,yll,yur,minval,maxval,nodata,ieq,itb,mfct,x2,cellsizex,cellsizey=readidfheader(mapfile)
        proj,angle,mapformat,datatype=1,0.0,"nominal/scalar","float32"
    elif source == 3:
        sig,x1,x2,x3,x4,x5,version,gisid,proj,attr,datatype,byteorder,x6,x7,x8,x9,x10,x11,x12,x13,x14,x15,x16,x17,x18,x19,valscale,cellrepr,minval,x20,maxval,x21,xll,yul,nrow,ncol,cellsizex,cellsizey,angle=readmapheader(mapfile)
        if proj == 0:
            yll=yul+nrow*cellsizey
        else:
            yll=yul-nrow*cellsizey
        nodata=lookup(cellrepr,[[0,255],[38,-2**31],[90,"-1.#QNAN"]])
        mapformat=lookup(valscale,[[224,"boolean"],[226,"nominal"],[235,"scalar"],[242,"ordinal"],[240,"ldd"],[251,"directional"]])
        datatype=lookup(cellrepr,[[0,"uint8"],[38,"int32"],[90,"float32"]])
    elif source == 4:
        nrow,ncol,xll,cellsizex,rot1,yul,rot2,cellsizey,datatype,nodata,minval,maxval=readgridheader(mapfile)
        yll,proj,angle=yul-nrow*cellsizey,1,0.0
        mapformat="nominal"
        if string.find(datatype,"float") != -1:
            mapformat="scalar"
    elif source in [5,6]:
        xll,yll,cellsizex,cellsizey,proj,angle,nrow,ncol,nodata,minval,maxval,mapformat,datatype=0.0,0.0,1.0,1.0,1,0.0,0,0,None,None,None,"nominal/scalar","int/float"
    else:
        if type(mapfile) == tuple:
            mapfile=list(mapfile)
        if type(mapfile) == list:
            for i in range(0,len(mapfile)):
                if i in [0,1,2,3,5]:
                    try:
                        mapfile[i]=float(mapfile[i])
                    except:
                        pass
            if type(props) in [list,tuple]:
                for i in range(len(mapfile),len(props)):
                    mapfile.append(props[i])
            props=mapfile[:min(15,len(mapfile))]
    if source != 0:
        maptype=readmaptype("return_all")[source]
        props=[xll,yll,cellsizex,cellsizey,proj,angle,nrow,ncol,nodata,minval,maxval,mapformat,datatype,source,maptype]
    return props # xll,yll,cellsizex,cellsizey,proj,angle,nrow,ncol,nodata,minval,maxval,mapformat,datatype,source,maptype

def readclone(mapfile,none=[0.0,0.0,1.0,1.0,1,0.0,0,0]):
    try:
        props=readmapproperties(mapfile,none)
        if type(props) in [list,tuple]:
            return list(props[:min(8,len(props))])
        else:
            return none
    except:
        return none

def spatial2array(mapfile,nodata=None,extent=None,clone=None):
    maparray=None
    try:
        source=readsource(mapfile)
    except:
        source=0
    if source in [1,2,3,4]:
        if extent == None and clone != None: extent=deepcopy(clone)
    if source == 1:
        maparray=asc2array(mapfile,nodata,extent)
    elif source == 2:
        maparray=idf2array(mapfile,nodata,extent)
    elif source == 3:
        maparray=map2array(mapfile,nodata,extent)
    elif source == 4:
        try:
            maparray=grid2array(mapfile,nodata,extent)
        except:
            pass
        try:
            maparray.shape
        except:
            try:
                i=0
                while 1:
                    tempfile="d:/temp_grid2asc%d.asc" %(i)
                    if not os.path.isfile(tempfile):
                        break
                    i=i+1
                grid2asc(mapfile,tempfile)
                maparray=asc2array(tempfile,nodata,extent)
            except:
                pass
            try:
                os.remove(tempfile)
            except:
                pass
    elif source in [5,6]:
        maparray=text2array(mapfile,nodata,extent,clone,None,1,1)
    return maparray

def raster2arr(f,nodata=-999999,extent=None,clone=None,method="avg",return_clone=False):
    arr=spatial2array(f,nodata,extent,clone)
    if clone == None and extent != None:
        if len(extent) == 8: clone=deepcopy(extent)
    if clone != None:
        clone1=clone2intersect(readclone(f),clone)[0]
        arr,clone1=array2resample(arr,clone1,clone,True,nodata,method)
    elif return_clone:
        clone1=readclone(f)
        if extent != None:
            clone2=[extent[0],extent[2],clone1[2],clone1[3],clone1[4],clone1[5],int((extent[3]-extent[2])/clone1[3]),int((extent[1]-extent[0])/clone1[2])]
            clone1=clone2intersect(clone1,clone2,1)[0]
    if return_clone: return arr,clone1
    else: return arr

def idf2mm(f):
    src=readsource(f)
    if src in [2,3]:
        if src == 2: nh=52
        else: nh=256
        xll,yll,cellsizex,cellsizey,proj,angle,nrow,ncol,nodata,minval,maxval,mapformat,datatype,source,maptype=readmapproperties(f)
        if datatype == "uint8": nb=1
        else: nb=4
        inf=open(f,"rb")
        mm=mmap.mmap(inf.fileno(),0,access=mmap.ACCESS_READ)
        return [xll,yll,cellsizex,cellsizey,proj,angle,nrow,ncol],[nh,nb],[inf,mm,nodata,datatype]
    else:
        return [0.0,0.0,1.0,1.0,1,0.0,0,0],[0,0],[None,None,None]

def map2mm(f):
    return idf2mm(f)

def xy_mm2val(xy,l_mm,nodata=-9999): # xy: 2xN matrix; l_mm: [clone,nhb,infmm]
    return rc_mm2val(xy2rc(xy,l_mm[0]),l_mm,nodata)

def rc_mm2val(rc,l_mm,nodata=-9999): # rc: 2xN matrix; l_mm: [clone,nhb,infmm]
    if l_mm[2][3] == "uint8": frm="=B"
    elif l_mm[2][3] == "int32": frm="=l"
    else: frm="=f"
    at=promote_types(l_mm[2][3],array(nodata).dtype)
    nodata0=l_mm[2][2]
    cp=where(rc[0] >= 0,where(rc[0] < l_mm[0][6],where(rc[1] >= 0,where(rc[1] < l_mm[0][7],True,False),False),False),False)
    ind=l_mm[1][0]+l_mm[1][1]*(where(cp,rc[0].copy(),0)*l_mm[0][7]+where(cp,rc[1].copy(),0))
    arr=ones((len(ind),),at)*nodata
    for i in range(0,len(arr)):
        l_mm[2][1].seek(ind[i])
        v=struct.unpack(frm,l_mm[2][1].read(l_mm[1][1]))[0]
        if v != nodata0: arr[i]=v
    arr=where(cp,where(isnan(arr),nodata,arr),nodata)
    return arr

def xy_idf2val(xy,f,nodata=-9999):
    l_mm=idf2mm(f)
    arr=xy_mm2val(xy,l_mm,nodata)
    close_infmm(l_mm[2])
    return arr
def rc_idf2val(rc,f,nodata=-9999):
    l_mm=idf2mm(f)
    arr=rc_mm2val(rc,l_mm,nodata)
    close_infmm(l_mm[2])
    return arr
def xy_map2val(xy,f,nodata=-9999):
    return xy_idf2val(xy,f,nodata)
def rc_map2val(rc,f,nodata=-9999):
    return rc_idf2val(rc,f,nodata)

def close_infmm(infmm):
    infmm[1].close()
    infmm[0].close()

def array2spatial(target,maparray,mapfile,clone=None,mv=None,clipmap=None,mapformat=None,format=None,rz=None,formats=None,div=None,header=None):
    if target == 1:
        mapfile=array2asc(maparray,mapfile,clone,mv,clipmap,format,rz,header)
    elif target == 2:
        mapfile=array2idf(maparray,mapfile,clone,mv,clipmap)
    elif target == 3:
        mapfile=array2map(maparray,mapfile,clone,mv,clipmap,mapformat)
    elif target == 4:
        mapfile=array2grid(maparray,mapfile,clone,mv,clipmap)
    elif target == 5:
        mapfile=array2mfcol(maparray,mapfile,clone,mv,clipmap,formats,div,rz)
    elif target == 6:
        mapfile=array2ipf(maparray,mapfile,clone,mv,clipmap,formats,div,rz)
    else:
        raise Exception,"target map type is invalid"
    return mapfile

def readmapformat(mapfile,none=None):
    try:
        props=readmapproperties(mapfile)
        if type(props) in [list,tuple]:
            return props[11]
        else:
            return none
    except:
        return none

def readdatatype(mapfile,none=None):
    try:
        props=readmapproperties(mapfile)
        if type(props) in [list,tuple]:
            return props[12]
        else:
            return none
    except:
        return none

def readnodata(mapfile,none=None):
    try:
        props=readmapproperties(mapfile)
        if type(props) in [list,tuple]:
            return props[8]
        else:
            return none
    except:
        return none

def readminmax(mapfile,none=[None,None]):
    try:
        props=readmapproperties(mapfile)
        if type(props) in [list,tuple]:
            if props[9] == None or props[10] == None:
                return none
            else:
                return props[9:11]
        else:
            return none
    except:
        return none

def readcloneasc(mapfile):
    return readmapproperties(mapfile)[:8]

def readcloneidf(mapfile):
    return readmapproperties(mapfile)[:8]

def readclonemap(mapfile):
    return readmapproperties(mapfile)[:8]

def readclonegrid(mapfile):
    return readmapproperties(mapfile)[:8]

def readlegend(mapfile,val=0):
    description,leglist="",[]
    source=readsource(mapfile)
    if source == 3:
        header=readmapheader(mapfile)
        attr=header[9]
        cellrepr=header[27]
        inf=open(mapfile,"rb"); inf.read(68)
        legend=0
        if attr != 0:
            inf.read(attr-68)
            pos=attr
            for n in range(0,10):
                attrId,attrOffset,attrSize=struct.unpack("=HLL",inf.read(10))
                pos=pos+10
                if attrId not in range(1,7):
                    break
                elif attrId in [1,6]:
                    legend=1
                    break
        if legend:
            inf.read(attrOffset-pos)
            for n in range(0,attrSize/64):
                description="Legend values"
                if attrId == 6 and n == 0:
                    description=string.replace(struct.unpack("=l60s",inf.read(64))[1],"\x00","")
                else:
                    rec=struct.unpack("=l60s",inf.read(64))
                    leglist.append([rec[0],string.replace(rec[1],"\x00","")])
        elif cellrepr in [0,38]:
            l=uniquenumbers(map2array(mapfile))
            for n in l:
                if not ((cellrepr == 0 and n == 255) or (cellrepr == 38 and n == -2**31)):
                    leglist.append([n,""])
            description="Unique values"
        if val not in [0,"0"]:
            for n in range(0,len(leglist)):
                if leglist[n][1] == "":
                    if type(val) == str:
                        leglist[n][1]=val
                    else:
                        leglist[n][1]=str(leglist[n][0])
    inf.close()
    return description,leglist

def asc2array(mapfile,mv=None,extent=None):
    try:
        float(mv)
    except:
        mv=None
    props=readmapproperties(mapfile)
    clone1=props[:8]; xll,yll,cellsizex,cellsizey,proj,angle,nrow,ncol=clone1; clone2=clone1[:]
    if extent != None:
        try:
            if len(extent) == 8:
                clone2=extent[:]
            else:
                clone2=[extent[0],extent[2],cellsizex,cellsizey,proj,angle,int((extent[3]-extent[2])/cellsizey),int((extent[1]-extent[0])/cellsizex)]
            clone2,[dr1,dr2,dc1,dc2]=clone2intersect(clone1,clone2,1)
            if dr1 == 0 and dr2 == 0 and dc1 == 0 and dc2 == 0:
                extent=None
        except:
            pass
    xll2,yll2,cellsizex2,cellsizey2,proj2,angle2,nrow2,ncol2=clone2
    nodata,skip=props[8],0
    if nodata != None:
        skip=1
    maparray=zeros((nrow2*ncol2),float32)
    count,count2,integer=0,0,1
    inf=open(mapfile,"r")
    for i in range(0,5):
        inf.readline()
    for i in range(0,skip):
        if string.find(inf.readline(),".") != -1:
            integer=0
    while 1:
        try:
            line=inf.readline()
            if integer:
                if string.find(line,".") != -1:
                    integer=0
            rec=string.split(line)
        except:
            break
        if extent != None:
            for j in range(0,len(rec)):
                r,c=count/ncol,count%ncol
                if r in range(-dr1,nrow+dr2) and c in range(-dc1,ncol+dc2):
                    maparray[count2]=float(rec[j])
                    count2=count2+1
                count=count+1
                if count >= nrow*ncol or count2 >= nrow2*ncol2:
                    break
            if count >= nrow*ncol or count2 >= nrow2*ncol2:
                break
        else:
            for j in range(0,len(rec)):
                maparray[count]=float(rec[j])
                count=count+1
                if count >= nrow*ncol:
                    break
            if count >= nrow*ncol:
                break
    inf.close()
    if count == 0:
        if type(mv) in [float,float16,float32,float64]:
            maparray=ones((nrow2,ncol2),float32)*mv
        elif type(mv) in [bool,int,long,bool_,uint8,uint16,uint32,uint64,int8,int16,int32,int64]:
            maparray=ones((nrow2,ncol2),int32)*mv
        else:
            maparray=zeros((nrow2,ncol2),float32)
    else:
        if type(mv) in [float,float16,float32,float64]:
            integer=0
        if integer:
            maparray=array(maparray,get_arrtype([int(maparray.min()),int(maparray.max()),mv,nodata],None))
        else:
            maparray=array(maparray,get_arrtype([maparray.min(),maparray.max(),mv,nodata],None))
        if mv != None and nodata != None:
            maparray=where(maparray == nodata,mv,maparray)
        maparray=array(maparray,get_arrtype([maparray.min(),maparray.max(),mv],None))
    return reshape(maparray,(nrow2,ncol2))

def idf2array(mapfile,mv=None,extent=None):
    try:
        mv=float(mv)
    except:
        mv=None
    ieq,itb,mfct,x2,dx,dy=readidfheader(mapfile,True)[10:16]
    props=readmapproperties(mapfile)
    clone1=props[:8]; xll,yll,cellsizex,cellsizey,proj,angle,nrow,ncol=clone1
    nodata=props[8]
    isint=False
    if (nodata > 1e38 or nodata < -1e38) and (-3.40282e+038 > nodata < -3.40283e+038):
        inf=open(mapfile,"rb"); header=list(struct.unpack("=3L 7f 4B",inf.read(44))); inf.close()
        if header[9] > -1e38 and header[9] < 1e38: nodata,mv,isint=header[9],array([mv],int32)[0],True
    inf=open(mapfile,"rb"); inf.read(44+bool(ieq-1)*8+bool(itb)*8+bool(ieq)*(nrow+ncol)*4)
    if isint:
        maparray=reshape(fromstring(inf.read(nrow*ncol*4),int32),(nrow,ncol))
    else:
        maparray=reshape(fromstring(inf.read(nrow*ncol*4),float32),(nrow,ncol))
    inf.close()
    if extent != None:
        try:
            if ieq == 1 and (dx.min() != dx.max() or dy.min() != dy.max()):
                if len(extent) == 8: xmin,xmax,ymin,ymax=extent[0],extent[0]+extent[2]*extent[7],extent[1],extent[1]+extent[3]*extent[6]
                else: xmin,xmax,ymin,ymax=extent
                x,y=ones((ncol+1,),float32)*xll,ones((nrow+1,),float32)*yll
                x[1:],y[:-1]=x[1:]+add.accumulate(dx),y[:-1]+add.accumulate(dy[::-1])[::-1]
                cpx,cpy=where(x[1:] > xmin,where(x[:-1] < xmax,1,0),0),where(y[1:] < ymax,where(y[:-1] > ymin,1,0),0)
                if cpx.sum() == 0 or cpy.sum() == 0: maparray=zeros((0,0),maparray.dtype.name)
                else: maparray=compress(cpx,compress(cpy,maparray),1)
            else:
                if len(extent) == 8: clone2=extent[:]
                else: clone2=[extent[0],extent[2],cellsizex,cellsizey,proj,angle,int((extent[3]-extent[2])/cellsizey),int((extent[1]-extent[0])/cellsizex)]
                maparray=array2intersect(maparray,clone1,clone2,1)[0]
        except:
            pass
    if mv == None:
        maparray[maparray == nodata]=-9999 #maparray=where(maparray == nodata,-9999,maparray)
    else:
        maparray[maparray == nodata]=mv #maparray=where(maparray == nodata,mv,maparray)
    return maparray

def map2array(mapfile,mv=None,extent=None):
    try:
        float(mv)
    except:
        mv=None
    props=readmapproperties(mapfile)
    clone1=props[:8]; xll,yll,cellsizex,cellsizey,proj,angle,nrow,ncol=clone1
    header=readmapheader(mapfile)
    inf=open(mapfile,"rb"); inf.read(256)
    if header[27] == 0:
        maparray=reshape(fromstring(inf.read(nrow*ncol),uint8),(nrow,ncol))
    elif header[27] == 38:
        maparray=reshape(fromstring(inf.read(4*nrow*ncol),int32),(nrow,ncol))
    else:
        maparray=reshape(fromstring(inf.read(4*nrow*ncol),float32),(nrow,ncol))
        if mv == "-1.#QNAN" or mv == None:
            mv=readminmax(mapfile,[-9998,-9998])[0]-1
        maparray[isnan(maparray)]=mv
    inf.close()
    if header[27] in [0,38]:
        maparray=array(maparray,get_arrtype([mv],maparray.dtype.name))
        if mv != None:
            if header[27] == 0:
                maparray=where(maparray == 255,mv,maparray)
            elif header[27] == 38:
                maparray=where(maparray == -2**31,mv,maparray)
        maparray=array(maparray,get_arrtype([maparray.min(),maparray.max(),mv],None))
    if extent != None:
        try:
            if len(extent) == 8:
                clone2=extent[:]
            else:
                clone2=[extent[0],extent[2],cellsizex,cellsizey,proj,angle,int((extent[3]-extent[2])/cellsizey),int((extent[1]-extent[0])/cellsizex)]
            maparray=array2intersect(maparray,clone1,clone2,1)[0]
        except:
            pass
    return maparray

def grid2array(mapfile,mv=None,extent=None):
    try:
        float(mv)
    except:
        mv=None
    props=readmapproperties(mapfile)
    clone1=props[:8]; xll,yll,cellsizex,cellsizey,proj,angle,nrow,ncol=clone1; clone2=clone1[:]
    dr1,dr2,dc1,dc2=0,0,0,0
    if extent != None:
        try:
            if len(extent) == 8:
                clone2=extent[:]
            else:
                clone2=[extent[0],extent[2],cellsizex,cellsizey,proj,angle,int((extent[3]-extent[2])/cellsizey),int((extent[1]-extent[0])/cellsizex)]
            clone2,[dr1,dr2,dc1,dc2]=clone2intersect(clone1,clone2,1)
        except:
            pass
    nodata,datatype=props[8],props[12]
    datatypes=["Byte","CFloat32","CFloat64","CInt16","CInt32","Float32","Float64","Int16","Int32","UInt16","UInt32"]
    gdts=[osgeo.gdal.GDT_Byte,osgeo.gdal.GDT_CFloat32,osgeo.gdal.GDT_CFloat64,osgeo.gdal.GDT_CInt16,osgeo.gdal.GDT_CInt32,osgeo.gdal.GDT_Float32,osgeo.gdal.GDT_Float64,osgeo.gdal.GDT_Int16,osgeo.gdal.GDT_Int32,osgeo.gdal.GDT_uint16,osgeo.gdal.GDT_uint32]
    structs=["B","f","d","h","l","f","d","h","l","H","L"]
    arraytypes=["uint8","float32","float64","int16","int32","float32","float64","int16","int32","uint16","uint32"]
    idatatype=datatypes.index(datatype)
    maparray=zeros((nrow+dr1+dr2,ncol+dc1+dc2),arraytypes[idatatype])
    gd=osgeo.gdal.Open(mapfile)
    layer=gd.GetRasterBand(1)
    for r in range(-dr1,nrow+dr2):
        data=layer.ReadRaster(-dc1,r,ncol+dc1+dc2,1,ncol+dc1+dc2,1,gdts[idatatype]) # x-offset,y-offset,x-size,y-size,x-buf(=x-size),y-buf(=y-size)
        maparray[r+dr1]=array(struct.unpack("%d%s" %(ncol+dc1+dc2,structs[idatatype]),data),dtype=arraytypes[idatatype],shape=(ncol+dc1+dc2))
    del gd
    maparray=array(maparray,get_arrtype([maparray.min(),maparray.max(),mv,nodata],None))
    if mv != None:
        maparray=where(maparray == nodata,mv,maparray)
    maparray=array(maparray,get_arrtype([maparray.min(),maparray.max(),mv],None))
    return maparray

##def text2array(mapfile,mv=-9999,extent=None,clone=None,field=None,shift=1,avg=1):
##    try:
##        float(mv)
##    except:
##        mv=-9999
##    if clone == None:
##        if extent != None:
##            if len(extent) == 8:
##                clone=extent[:]
##    maparray=None
##    try:
##        source=readsource(mapfile)
##    except:
##        source=0
##    if source in [5,6]:
##        xll,yll,cellsizex,cellsizey,proj,angle,nrow,ncol=readclone(clone)
##        maxrow,maxcol=nrow,ncol
##        fixedsize=0
##        if nrow > 0 and ncol > 0 or source == 6:
##            fixedsize=1
##        else:
##            nrow,ncol=10,10
##        nlay=1
##        maparray=ones((nlay,nrow,ncol),float32)*mv
##        if field == None:
##            if source == 5:
##                field=3
##            else:
##                field=2
##        if avg:
##            countarray=ones((nlay,nrow,ncol))*mv
##        inf=open(mapfile,"r")
##        if source == 5:
##            inf.readline(); nrec=int(string.split(inf.readline())[0])
##        else:
##            nrec=int(string.split(inf.readline())[0])
##            nfield=int(string.split(inf.readline())[0])
##            xfield,yfield,lfield=0,1,-1
##            for i in range(0,nfield):
##                rec=string.split(inf.readline())
##                if string.strip(rec[0]) in ["x","X"]:
##                    xfield=i
##                elif string.strip(rec[0]) in ["y","Y"]:
##                    yfield=i
##                elif string.strip(rec[0]) in ["l","L"]:
##                    lfield=i
##            inf.readline()
##        for i in range(0,nrec):
##            try:
##                rec=string.split(inf.readline())
##                if source == 5:
##                    if len(rec) >= max(3,field+1):
##                        l,r,c,val=int(rec[0])-shift,int(rec[1])-shift,int(rec[2])-shift,float(rec[field])
##                    else:
##                        break
##                else:
##                    if len(rec) >= max(xfield,yfield,lfield,field)+1:
##                        if lfield != -1:
##                            l,x,y,val=int(rec[lfield])-shift,float(rec[xfield]),float(rec[yfield]),float(rec[field])
##                        else:
##                            l,x,y,val=0,float(rec[xfield]),float(rec[yfield]),float(rec[field])
##                        c=(x-xll)/cellsizex
##                        if c-int(c) == 0 and c != 0:
##                            c=int(c)-1
##                        else:
##                            c=int(c)
##                        r=nrow-(y-yll)/cellsizey
##                        if r-int(r) == 0 and r != 0:
##                            r=int(r)-1
##                        else:
##                            r=int(r)
##                    else:
##                        break
##                if not fixedsize:
##                    maxrow,maxcol=max(maxrow,r+1),max(maxcol,c+1)
##                if r >= 0 and r < maxrow and c >= 0 and c < maxcol:
##                    if l > nlay-1:
##                        maparray=concatenate([maparray,ones((l-nlay+1,nrow,ncol),float32)*mv])
##                        if avg:
##                            countarray=concatenate([countarray,ones((l-nlay+1,nrow,ncol))*mv])
##                        nlay=l+1
##                    if r > nrow-1:
##                        maparray=concatenate([maparray,ones((nlay,r-nrow+10,ncol),float32)*mv],axis=1)
##                        if avg:
##                            countarray=concatenate([countarray,ones((nlay,r-nrow+10,ncol))*mv],axis=1)
##                        nrow=r+10
##                    if c > ncol-1:
##                        maparray=concatenate([maparray,ones((nlay,nrow,c-ncol+10),float32)*mv],axis=2)
##                        if avg:
##                            countarray=concatenate([countarray,ones((nlay,nrow,c-ncol+10))*mv],axis=2)
##                        ncol=c+10
##                    if maparray[l,r,c] == mv:
##                        maparray[l,r,c]=val
##                        if avg:
##                            countarray[l,r,c]=1
##                    else:
##                        maparray[l,r,c]=maparray[l,r,c]+val
##                        if avg:
##                            countarray[l,r,c]=countarray[l,r,c]+1
##            except:
##                break
##        inf.close()
##        if avg:
##            maparray=where(maparray != mv,maparray/countarray,maparray)
##        maparray=maparray[:,:maxrow,:maxcol]
##        if extent != None:
##            try:
##                if len(extent) == 8:
##                    clone2=extent[:]
##                else:
##                    clone2=[extent[0],extent[2],cellsizex,cellsizey,proj,angle,int((extent[1]-extent[0])/cellsizex),int((extent[3]-extent[2])/cellsizey)]
##                for l in range(0,nlay):
##                    maparray[l]=array2intersect(maparray[l],clone1,clone2,1)[0]
##            except:
##                pass
##    return maparray

def text2array(mapfile,mv=-9999,extent=None,clone=None,field=None,shift=1,avg=1,sep=0):
    try:
        float(mv)
    except:
        mv=-9999
    if clone == None:
        if extent != None:
            if len(extent) == 8:
                clone=extent[:]
    maparray,nf,nf0,maxnc,fdim=None,0,0,0,0
    try:
        source=readsource(mapfile)
    except:
        source=0
    if source in [5,6]:
        xll,yll,cellsizex,cellsizey,proj,angle,nrow,ncol=readclone(clone)
        maxrow,maxcol=nrow,ncol
        fixedsize=0
        if nrow > 0 and ncol > 0 or source == 6:
            fixedsize=1
        else:
            nrow,ncol=10,10
        if field == None:
            if source == 5: field=[3]
            else: field=[2]
        else:
            if type(field) in [list,tuple]: field,fdim=list(field),1
            elif type(field) == str: field,fdim=string2indices(field),1
            else: field=[field]
        nlay,nf=1,len(field); nc=ones((nlay)).tolist()
        maparray,countarray=[],[]
        for l in range(0,nlay):
            maparray.append([]); countarray.append([])
            for i in range(0,nc[l]):
                maparray[-1].append(ones((nrow,ncol,nf),float32)*mv)
                if avg and not sep:
                    countarray[-1].append(ones((nrow,ncol,nf))*mv)
        inf=open(mapfile,"r")
        if source == 5:
            inf.readline(); nrec=int(string.split(inf.readline())[0])
        else:
            nrec=int(string.split(inf.readline())[0])
            nfield=int(string.split(inf.readline())[0])
            xfield,yfield,lfield=0,1,-1
            for i in range(0,nfield):
                rec=string.split(inf.readline())
                if string.strip(rec[0]) in ["x","X"]:
                    xfield=i
                elif string.strip(rec[0]) in ["y","Y"]:
                    yfield=i
                elif string.strip(rec[0]) in ["l","L"]:
                    lfield=i
            inf.readline()
        for i in range(0,nrec):
            try:
                rec=string.split(inf.readline())
                nf1=0
                if source == 5:
                    if len(rec) > 3:
                        l,r,c=int(rec[0])-shift,int(rec[1])-shift,int(rec[2])-shift
                        val=ones((nf),float32)*mv
                        for j in range(0,nf):
                            if field[j] <= len(rec)-1:
                                val[j]=float(rec[field[j]]); nf1=nf1+1
                    else:
                        break
                else:
                    if len(rec) >= max(xfield,yfield,lfield,max(field))+1:
                        if lfield != -1: l=int(rec[lfield])-shift
                        else: l=0
                        x,y=float(rec[xfield]),float(rec[yfield])
                        val=ones((nf),float32)*mv
                        for j in range(0,nf):
                            if field[j] <= nfield-1:
                                val[j]=float(rec[field[j]]); nf1=nf1+1
                        c=(x-xll)/cellsizex
                        if c-int(c) == 0 and c != 0:
                            c=int(c)-1
                        else:
                            c=int(c)
                        r=nrow-(y-yll)/cellsizey
                        if r-int(r) == 0 and r != 0:
                            r=int(r)-1
                        else:
                            r=int(r)
                    else:
                        break
                nf0=max(nf0,nf1)
                if not fixedsize:
                    maxrow,maxcol=max(maxrow,r+1),max(maxcol,c+1)
                if r >= 0 and r < maxrow and c >= 0 and c < maxcol:
                    if l > nlay-1:
                        for j in range(nlay-1,l):
                            maparray.append([]); countarray.append([]); nc.append(1)
                            for k in range(0,nc[-1]):
                                maparray[-1].append(ones((nrow,ncol,nf),float32)*mv)
                                if avg and not sep:
                                    countarray[-1].append(ones((nrow,ncol,nf))*mv)
                        nlay=l+1
                    if r > nrow-1:
                        for j in range(0,nlay):
                            for k in range(0,nc[j]):
                                maparray[j][k]=concatenate([maparray[j][k],ones((r-nrow+10,ncol,nf),float32)*mv],axis=0)
                                if avg and not sep:
                                    countarray[j][k]=concatenate([countarray[j][k],ones((r-nrow+10,ncol,nf))*mv],axis=0)
                        nrow=r+10
                    if c > ncol-1:
                        for j in range(0,nlay):
                            for k in range(0,nc[j]):
                                maparray[j][k]=concatenate([maparray[j][k],ones((nrow,c-ncol+10,nf),float32)*mv],axis=1)
                                if avg and not sep:
                                    countarray[j][k]=concatenate([countarray[j][k],ones((nrow,c-ncol+10,nf))*mv],axis=1)
                        ncol=c+10
                    ic=zeros((nlay))
                    if sep:
                        while True:
                            if maparray[l][ic[l]][r,c,0] != mv: ic[l]=ic[l]+1
                            else: break
                            if ic[l] > nc[l]-1:
                                maparray[l].append(ones((nrow,ncol,nf),float32)*mv)
                                if avg and not sep:
                                    countarray[l].append(ones((nrow,ncol,nf))*mv)
                                nc[l]=nc[l]+1
                    if maparray[l][ic[l]][r,c,0] == mv:
                        maparray[l][ic[l]][r,c,:]=array(val,float32)
                        if avg and not sep:
                            countarray[l][ic[l]][r,c,:]=1
                    else:
                        maparray[l][ic[l]][r,c,:]=maparray[l][ic[l]][r,c,:]+array(val,float32)
                        if avg and not sep:
                            countarray[l][ic[l]][r,c,:]=countarray[l][ic[l]][r,c,:]+1
            except:
                break
        inf.close()
        if avg and not sep:
            for l in range(0,nlay):
                for i in range(0,nc[l]):
                    maparray[l][i]=where(maparray[l][i] != mv,maparray[l][i]/countarray[l][i],maparray[l][i])
        for l in range(0,nlay):
            for i in range(0,nc[l]):
                maparray[l][i]=maparray[l][i][:maxrow,:maxcol,:]
        if extent != None:
            try:
                if len(extent) == 8:
                    clone2=extent[:]
                else:
                    clone2=[extent[0],extent[2],cellsizex,cellsizey,proj,angle,int((extent[1]-extent[0])/cellsizex),int((extent[3]-extent[2])/cellsizey)]
                for l in range(0,nlay):
                    for i in range(0,nc[l]):
                        for f in range(0,nf):
                            maparray[l][i][:,:,f]=array2intersect(maparray[l][i][:,:,f],clone1,clone2,1)[0]
            except:
                pass
        maxnc=max(nc)
        if not fdim and nf == 1:
            for l in range(0,nlay):
                for i in range(0,nc[l]):
                    maparray[l][i]=maparray[l][i][:,:,0]
        if not sep:
            for l in range(0,nlay):
                maparray[l]=maparray[l][0]
        if not sep and not fdim and nf == 1:
            maparray=array(maparray)
    return maparray,maxnc,nf0  # maparray: nlay,ncount,nrow,ncol,nfield (nlay,ncount: list)

def array2asc(maparray,ascfile,clone=None,mv=None,clipmap=None,format=None,rz=None,header=None):
    at0=maparray.dtype.name
    mapshape=maparray.shape
    if rank(maparray) != 2:
        raise Exception,"rank of array is %d (should be 2)" %(rank(maparray))
    clone=readclone(clone)
    xll,yll,cellsizex,cellsizey,proj,angle,nrow,ncol=clone
    if nrow == 0 and ncol == 0:
        nrow,ncol=mapshape
    elif mapshape[0] != nrow or mapshape[1] != ncol:
        raise Exception,"array does not fit clone"
    try:
        float(mv)
    except:
        mv=None
    maskarray=zeros((nrow,ncol),uint8)
    if mv != None:
        at=get_arrtype([maparray.min(),maparray.max(),mv])
        if at == "float32" and at0 == "float64": at=at0
        maparray=array(maparray,at)
        maskarray=array(where(maparray == mv,1,maskarray),uint8)
    if clipmap != None:
        cliparray=None
        try:
            cliparray=array(where(spatial2array(clipmap) > 0,1,0),uint8)
        except:
            try:
                clipmap.shape; cliparray=array(where(clipmap > 0,1,0),uint8)
            except:
                try:
                    mvclip=float(clipmap); cliparray=array(where(maparray == mvclip,0,1),uint8)
                except:
                    pass
        if cliparray != None:
            if cliparray.shape == mapshape:
                maskarray=array(where(cliparray == 0,1,maskarray),uint8)
            del cliparray
    if format == None:
        format=" %s"
    if rz not in [None,0]:
        rz=1
    else:
        rz=0
    if mv == None:
        minval=where(maskarray == 1,maparray.max(),maparray).min()
        if maparray.dtype.name in ["uint8","uint16","uint32"] and minval > 0:
            mv=0
        else:
            mv=minval-1
    if maparray.dtype.name in ["uint8","uint16","uint32","int8","int16","int32"]:
        if mv-int(mv) == 0:
            mv=int(mv)
    outf=open(ascfile,"w")
    if type(header) == str:
        outf.write(header)
        if header[-1] != "\n": outf.write("\n")
    else:
        outf.write("NCOLS        %s\nNROWS        %s\nXLLCORNER    %s\nYLLCORNER    %s\nCELLSIZE     %s\nNODATA_VALUE %s\n" \
               %(ncol,nrow,xll,yll,cellsizex,mv))
    for r in range(0,nrow):
        for c in range(0,ncol):
            if maskarray[r,c] == 1:
                val=format %(mv)
            else:
                val=format %(maparray[r,c])
            if rz:
                if c == 0 and val[0] == " ":
                    val=val[1:]
                if string.find(string.lower(val),"e") == -1:
                    while len(val) > 1 and string.find(val,".") != -1:
                        if val[-1] == "0" or val[-1] == ".":
                            val=val[:-1]
                        else:
                            break
            outf.write(val)
        outf.write("\n")
    outf.close()
    return ascfile

def array2idf(maparray,idffile,clone=None,mv=None,clipmap=None):
    mapshape=maparray.shape
    if rank(maparray) != 2:
        raise Exception,"rank of array is %d (should be 2)" %(rank(maparray))
    xll,yll,cellsizex,cellsizey,proj,angle,nrow,ncol=readclone(clone)
    if nrow == 0 and ncol == 0:
        nrow,ncol=mapshape
    elif mapshape[0] != nrow or mapshape[1] != ncol:
        raise Exception,"array does not fit clone"
    try:
        float(mv)
    except:
        mv=None
    maparray=array(maparray,float32)
    maskarray=zeros((nrow,ncol),uint8)
    if mv != None:
        maskarray=array(where(maparray == mv,1,maskarray),uint8)
    if clipmap != None:
        cliparray=None
        try:
            cliparray=array(where(spatial2array(clipmap) > 0,1,0),uint8)
        except:
            try:
                clipmap.shape; cliparray=array(where(clipmap > 0,1,0),uint8)
            except:
                try:
                    mvclip=float(clipmap); cliparray=array(where(maparray == mvclip,0,1),uint8)
                except:
                    pass
        if cliparray != None:
            if cliparray.shape == mapshape:
                maskarray=array(where(cliparray == 0,1,maskarray),uint8)
            del cliparray
    if mv == None:
        minval=where(maskarray == 1,maparray.max(),maparray).min()
        mv=min(-9999,minval-1)
    maparray=array(where(maskarray == 0,maparray,mv),float32)
    if maskarray.sum() == nrow*ncol:
        minval=maxval=mv
    elif maskarray.sum() == 0:
        minval,maxval=maparray.min(),maparray.max()
    else:
        maskedmaparray=MA.array(maparray,mask=maskarray)
        minval,maxval=maskedmaparray.min(),maskedmaparray.max()
        del maskedmaparray
    xur=xll+ncol*cellsizex
    yur=yll+nrow*cellsizey
    header=struct.pack("4B 2L 7f l 2f",247,4,0,0,ncol,nrow,xll,xur,yll,yur,minval,maxval,mv,0,cellsizex,cellsizey)
    outf=open(idffile,"wb"); outf.write(header)
    limit=16600000
    maparray=ravel(maparray)
    for i in range(0,nrow*ncol,limit):
        outf.write(maparray[i:min(nrow*ncol,i+limit)].tostring())
    outf.close()
    return idffile

def array2map(maparray,mapfile,clone=None,mv=None,clipmap=None,mapformat=None):
    mapshape,mapformat=maparray.shape,string.lower(str(mapformat))
    if rank(maparray) != 2:
        raise Exception,"rank of array is %d (should be 2)" %(rank(maparray))
    xll,yll,cellsizex,cellsizey,proj,angle,nrow,ncol=readclone(clone)
    if nrow == 0 and ncol == 0:
        nrow,ncol=mapshape
    elif mapshape[0] != nrow or mapshape[1] != ncol:
        raise Exception,"array does not fit clone"
    try:
        float(mv)
    except:
        mv=None
    maskarray=zeros((nrow,ncol),uint8)
    if mapformat not in ["boolean","ldd","nominal","ordinal","directional","scalar"]:
        if maparray.dtype in [int8,int16,int32,uint8,uint16,uint32]:
            mapformat="nominal"
        else:
            mapformat="scalar"
    if mapformat in ["boolean","ldd","nominal","ordinal"]:
        if mv != None:
            mv=int(mv)
        if (maparray.max() < 255 or (maparray.max() == 255 and mv == 255)) and maparray.min() >= 0:
            maparray=array(maparray,uint8)
            maskarray=array(where(maparray == 255,1,maskarray),uint8)
        else:
            maparray=array(maparray,int32)
            maskarray=array(where(maparray == -2**31,1,maskarray),uint8)
    elif mapformat in ["directional","scalar"]:
        maparray=array(maparray,float32)
    if mv != None and (mv < maparray.min() or mv > maparray.max()):
        mv=None
    if mv != None:
        maskarray=array(where(maparray == mv,1,maskarray),uint8)
    if clipmap != None:
        cliparray=None
        try:
            cliparray=array(where(spatial2array(clipmap) > 0,1,0),uint8)
        except:
            try:
                clipmap.shape; cliparray=array(where(clipmap > 0,1,0),uint8)
            except:
                try:
                    mvclip=float(clipmap); cliparray=array(where(maparray == mvclip,0,1),uint8)
                except:
                    pass
        if cliparray != None:
            if cliparray.shape == mapshape:
                maskarray=array(where(cliparray == 0,1,maskarray),uint8)
            del cliparray
    if maskarray.sum() == nrow*ncol:
        minval=maxval=mv
    elif maskarray.sum() == 0:
        minval,maxval=maparray.min(),maparray.max()
    else:
        maskedmaparray=MA.array(maparray,mask=maskarray)
        minval,maxval=maskedmaparray.min(),maskedmaparray.max()
        del maskedmaparray
    if proj == 1:
        yul=yll+nrow*cellsizey
    else:
        yul=yll-nrow*cellsizey
    header1=struct.pack("=27s5BHLHLHL14B","RUU CROSS SYSTEM MAP FORMAT",0,0,0,0,0,2,0,proj,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0)
    header3=struct.pack("=ddLLddd",xll,yul,nrow,ncol,cellsizex,cellsizey,angle)
    for n in range(0,124):
        header3=header3+struct.pack("=B",0)
    if mapformat == "boolean":
        header2=struct.pack("=HH H3h H3h",224,0,0,-1,-1,-1,1,-1,-1,-1)
        xarray=array(where(maskarray == 0,where(maparray > 0,1,where(maparray < 0,255,0)),255),uint8)
    elif mapformat == "ldd":
        header2=struct.pack("=HH H3h H3h",240,0,0,-1,-1,-1,9,-1,-1,-1)
        xarray=array(where(maskarray == 0,where(maparray > 9,5,where(maparray < 1,255,maparray)),255),uint8)
    elif mapformat == "nominal":
        if maparray.dtype.name == "uint8":
            header2=struct.pack("=HH H3h H3h",226,0,int(minval),-1,-1,-1,int(maxval),-1,-1,-1)
            xarray=array(where(maskarray == 0,maparray,255),uint8)
        else:
            header2=struct.pack("=HH 4l",226,38,int(minval),0,int(maxval),0)
            xarray=array(where(maskarray == 0,maparray,-2**31),int32)
    elif mapformat == "ordinal":
        if maparray.dtype.name == "uint8":
            header2=struct.pack("=HH H3h H3h",242,0,int(minval),-1,-1,-1,int(maxval),-1,-1,-1)
            xarray=array(where(maskarray == 0,maparray,255),uint8)
        else:
            header2=struct.pack("=HH 4l",242,38,int(minval),0,int(maxval),0)
            xarray=array(where(maskarray == 0,maparray,-2**31),int32)
    elif mapformat == "directional":
        header2=struct.pack("=HH flfl",251,90,minval,-1,maxval,-1)
        xarray=array(where(maparray >= 360,-1,where(maparray < 0,-1,maparray)),float32)
        missing,format="\xff\xff\xff\xff","=f"
    else:
        mapformat="scalar"
        header2=struct.pack("=HH flfl",235,90,minval,-1,maxval,-1)
        xarray=array(maparray,float32)
        missing,format="\xff\xff\xff\xff","=f"
    outf=open(mapfile,"wb"); outf.write(header1+header2+header3)
    if maskarray.max() == 1 and mapformat in ["directional","scalar"]:
        for r in range(0,nrow):
            for c in range(0,ncol):
                if maskarray[r,c] == 1:
                    outf.write(missing)
                else:
                    outf.write(struct.pack(format,xarray[r,c]))
    else:
        limit=16600000
        if xarray.dtype.name == "uint8":
            limit=limit*4
        xarray=ravel(xarray)
        for i in range(0,nrow*ncol,limit):
            outf.write(xarray[i:min(nrow*ncol,i+limit)].tostring())
    outf.close()
    return mapfile

def array2grid(maparray,gridfile,clone=None,mv=None,clipmap=None):
    sp=splitpath(gridfile)
    count=0
    tempfile="%s/temp%d.map" %(sp[0],count)
    while os.path.isfile(tempfile):
        count=count+1
        tempfile="%s/temp%d.map" %(sp[0],count)
    try:
        if maparray.dtype.name in ["uint8","uint16","uint32","int8","int16","int32"]:
            array2map(maparray,tempfile,clone,mv,clipmap,"nominal")
        else:
            array2map(maparray,tempfile,clone,mv,clipmap,"scalar")
        newgridfile=map2grid(tempfile,gridfile)
        if not os.path.isdir(gridfile): raise
    except:
        try:
            os.remove(tempfile)
        except:
            pass
        count=0
        tempfile="%s/temp%d.asc" %(sp[0],count)
        while os.path.isfile(tempfile):
            count=count+1
            tempfile="%s/temp%d.asc" %(sp[0],count)
        try:
            array2asc(maparray,tempfile,clone,mv,clipmap)
            if maparray.dtype.name in ["uint8","uint16","uint32","int8","int16","int32"]:
                newgridfile=asc2grid(tempfile,gridfile,1)
            else:
                newgridfile=asc2grid(tempfile,gridfile)
        except:
            pass
    try:
        os.remove(tempfile)
    except:
        pass
    return newgridfile

def array2mfcol(maparray,mapfile,clone=None,mv=None,clipmap=None,formats=None,div=None,rz=None):
    mapshape=maparray.shape
    if rank(maparray) not in [2,3]:
        raise Exception,"rank of array is %d (should be 2 or 3)" %(rank(maparray))
    elif rank(maparray) == 2:
        maparray=array([maparray]); mapshape=maparray.shape
    clone=readclone(clone)
    xll,yll,cellsizex,cellsizey,proj,angle,nrow,ncol=clone
    if nrow == 0 and ncol == 0:
        nrow,ncol=mapshape[1:3]
    elif mapshape[1] != nrow or mapshape[2] != ncol:
        raise Exception,"array does not fit clone"
    try:
        float(mv)
    except:
        mv=None
    maskarray=zeros((nrow,ncol),uint8)
    if mv != None and mv >= maparray.min() and mv <= maparray.max():
        maskarray=array(where(maparray == mv,1,maskarray),uint8)
    else:
        mv=maparray.max()+1
    if clipmap != None:
        cliparray=None
        try:
            cliparray=array(where(spatial2array(clipmap) > 0,1,0),uint8)
        except:
            try:
                clipmap.shape; cliparray=array(where(clipmap > 0,1,0),uint8)
            except:
                try:
                    mvclip=float(clipmap); cliparray=array(where(maparray == mvclip,0,1),uint8)
                except:
                    pass
        if cliparray != None:
            if cliparray.shape == mapshape:
                maskarray=array(where(cliparray == 0,1,maskarray),uint8)
            del cliparray
    if type(formats) not in [list,tuple]:
        formats=["%d","%s","%s"]
    else:
        formats=list(formats)
    for i in range(len(formats),2):
        formats.append("%s")
    for i in range(len(formats),3):
        formats.append("")
    if formats[2] not in [None,""]:
        x,y=index2coord([nrow,ncol],clone)
    if div == None:
        div=" "
    if rz not in [None,0]:
        rz=1
    else:
        rz=0
    nl,nr,nc=mapshape
    cellist=[]
    for l in range(0,nl):
        for r in range(0,nr):
            for c in range(0,nc):
                if maparray[l,r,c] != mv:
                    if formats[2] not in [None,""]:
                        cellist.append([formats[0] %(l),formats[0] %(r),formats[0] %(c),\
                                        formats[1] %(maparray[l,r,c]),\
                                        formats[2] %(x[c]),formats[2] %(y[r])])
                    else:
                        cellist.append([formats[0] %(l),formats[0] %(r),formats[0] %(c),\
                                        formats[1] %(maparray[l,r,c])])
                    if rz:
                        for i in range(0,len(cellist[-1])):
                            val=cellist[-1][i]
                            if string.find(string.lower(val),"e") == -1:
                                while len(val) > 1 and string.find(val,".") != -1:
                                    if val[-1] == "0" or val[-1] == ".":
                                        val=val[:-1]
                                    else:
                                        break
                                cellist[-1][i]=val
    first=""
    if div == " " and rz == 0:
        first=" "
    outf=open(mapfile,"w")
    if formats[2] not in [None,""]:
        outf.write(first+"%s  L R C Value X Y\n" %(string.join([formats[0] %(len(cellist)),formats[0] %(0)],div)))
    else:
        outf.write(first+"%s  L R C Value\n" %(string.join([formats[0] %(len(cellist)),formats[0] %(0)],div)))
    outf.write(first+"%s\n" %(formats[0] %(len(cellist))))
    for i in range(0,len(cellist)):
        outf.write(first+"%s\n" %(string.join(cellist[i],div)))
    outf.close()
    return mapfile

def array2ipf(maparray,mapfile,clone=None,mv=None,clipmap=None,formats=None,div=None,rz=None):
    mapshape=maparray.shape
    if rank(maparray) not in [2,3]:
        raise Exception,"rank of array is %d (should be 2 or 3)" %(rank(maparray))
    elif rank(maparray) == 2:
        maparray=array([maparray]); mapshape=maparray.shape
    clone=readclone(clone)
    xll,yll,cellsizex,cellsizey,proj,angle,nrow,ncol=clone
    if nrow == 0 and ncol == 0:
        nrow,ncol=mapshape[1:3]
    elif mapshape[1] != nrow or mapshape[2] != ncol:
        raise Exception,"array does not fit clone"
    try:
        float(mv)
    except:
        mv=None
    maskarray=zeros((nrow,ncol),uint8)
    if mv != None and mv >= maparray.min() and mv <= maparray.max():
        maskarray=array(where(maparray == mv,1,maskarray),uint8)
    else:
        mv=maparray.max()+1
    if clipmap != None:
        cliparray=None
        try:
            cliparray=array(where(spatial2array(clipmap) > 0,1,0),uint8)
        except:
            try:
                clipmap.shape; cliparray=array(where(clipmap > 0,1,0),uint8)
            except:
                try:
                    mvclip=float(clipmap); cliparray=array(where(maparray == mvclip,0,1),uint8)
                except:
                    pass
        if cliparray != None:
            if cliparray.shape == mapshape:
                maskarray=array(where(cliparray == 0,1,maskarray),uint8)
            del cliparray
    if type(formats) not in [list,tuple]:
        formats=["%10d","%10.3f"]
    else:
        formats=list(formats)
    for i in range(len(formats),2):
        formats.append("%s")
    x,y=index2coord([nrow,ncol],clone)
    if div == None:
        div=""
    if rz not in [None,0]:
        rz=1
    else:
        rz=0
    nl,nr,nc=mapshape
    rowcol=indices((nrow,ncol)); row,col=rowcol[0],rowcol[1]
    cellist=[]
    for l in range(0,nl):
        comparr=ravel(where(maparray[l] != mv,1,0))
        row0,col0=compress(comparr,ravel(row),0),compress(comparr,ravel(col),0)
        for j in range(0,len(row0)):
            r,c=row0[j],col0[j]
            cellist.append([formats[0] %(x[c]),formats[0] %(y[r]),\
                            formats[1] %(maparray[l,r,c]),\
                            "%10d" %(l)])
            if rz:
                for i in range(0,len(cellist[-1])):
                    val=cellist[-1][i]
                    if string.find(string.lower(val),"e") == -1:
                        while len(val) > 1 and string.find(val,".") != -1:
                            if val[-1] == "0" or val[-1] == ".":
                                val=val[:-1]
                            else:
                                break
                        cellist[-1][i]=val
    first=""
    if div == " " and rz == 0:
        first=" "
    outf=open(mapfile,"w")
    if nl > 1:
        outf.write("%d\n4\nX\nY\nQ\nL\n%d,%s\n" %(len(cellist),0,"TXT"))
        for i in range(0,len(cellist)):
            outf.write(first+"%s\n" %(string.join(cellist[i],div)))
    else:
        outf.write("%d\n3\nX\nY\nQ\n%d,%s\n" %(len(cellist),0,"TXT"))
        for i in range(0,len(cellist)):
            outf.write(first+"%s\n" %(string.join(cellist[i][:-1],div)))
    outf.close()
    return mapfile

def asc2grid(ascfile,gridfile,integer=None):
    try:
        integer=bool(integer)
    except:
        integer=0
    sp=splitpath(gridfile)
    gp=Dispatch("esriGeoprocessing.GpDispatch.1")
    gp.Workspace=sp[0]
    grids=gp.ListRasters("*","GRID"); grids.reset(); grid=grids.next()
    gridlist=[]
    while grid:
        gridlist.append(sp[0]+"/"+grid)
        grid = grids.next()
    dirname,basename=splitpath(gridfile)[:2]
    if gridfile in gridlist or len(basename) > 13:
        count=0
        gridfile=gridfile[:len(dirname)+1+min(len(basename),13-len(str(count)))]+str(count)
        while 1:
            if gridfile not in gridlist:
                break
            gridfile=gridfile[:-len(str(count))]
            basename=splitpath(gridfile)[1]
            count=count+1
            gridfile=gridfile[:len(dirname)+1+min(len(basename),13-len(str(count)))]+str(count)
    if integer:
        gp.ASCIIToRaster_conversion(ascfile, gridfile, "INTEGER")
    else:
        gp.ASCIIToRaster_conversion(ascfile, gridfile, "FLOAT")
    return gridfile

def grid2asc(gridfile,ascfile):
    gp=Dispatch("esriGeoprocessing.GpDispatch.1")
    gp.RasterToASCII_conversion(gridfile,ascfile)
    return ascfile

def map2grid(mapfile,gridfile):
    sp=splitpath(gridfile)
    gp=Dispatch("esriGeoprocessing.GpDispatch.1")
    gp.Workspace=sp[0]
    grids=gp.ListRasters("*","GRID"); grids.reset(); grid=grids.next()
    gridlist=[]
    while grid:
        gridlist.append(sp[0]+"/"+grid)
        grid = grids.next()
    dirname,basename=splitpath(gridfile)[:2]
    if gridfile in gridlist or len(basename) > 13:
        count=0
        gridfile=gridfile[:len(dirname)+1+min(len(basename),13-len(str(count)))]+str(count)
        while 1:
            if gridfile not in gridlist:
                break
            gridfile=gridfile[:-len(str(count))]
            basename=splitpath(gridfile)[1]
            count=count+1
            gridfile=gridfile[:len(dirname)+1+min(len(basename),13-len(str(count)))]+str(count)
    gp.CopyRaster_management(mapfile,gridfile)
    return gridfile

def clone2intersect(clone1,clone2,big=0):
    xll1,yll1,csx1,csy1,proj1,ang1,nrow1,ncol1=readclone(clone1); xur1,yur1=xll1+ncol1*csx1,yll1+nrow1*csy1
    xll2,yll2,csx2,csy2,proj2,ang2,nrow2,ncol2=readclone(clone2); xur2,yur2=xll2+ncol2*csx2,yll2+nrow2*csy2
    dr1=max(0,(yur1-yur2)/csy1); dr1=-(int(dr1)+bool(roundoff(dr1-int(dr1),1e-10))*bool(not big))
    dr2=max(0,(yll2-yll1)/csy1); dr2=-(int(dr2)+bool(roundoff(dr2-int(dr2),1e-10))*bool(not big))
    dc1=max(0,(xll2-xll1)/csx1); dc1=-(int(dc1)+bool(roundoff(dc1-int(dc1),1e-10))*bool(not big))
    dc2=max(0,(xur1-xur2)/csx1); dc2=-(int(dc2)+bool(roundoff(dc2-int(dc2),1e-10))*bool(not big))
    xll3,ncol3=xll1-dc1*csx1,ncol1+dc1+dc2
    yll3,nrow3=yll1-dr2*csy1,nrow1+dr1+dr2
    return [xll3,yll3,csx1,csy1,1,0.0,nrow3,ncol3],[dr1,dr2,dc1,dc2]

def clone2expand(clone1,clone2,big=0):
    xll1,yll1,csx1,csy1,proj1,ang1,nrow1,ncol1=readclone(clone1); xur1,yur1=xll1+ncol1*csx1,yll1+nrow1*csy1
    xll2,yll2,csx2,csy2,proj2,ang2,nrow2,ncol2=readclone(clone2); xur2,yur2=xll2+ncol2*csx2,yll2+nrow2*csy2
    dr1=max(0,(yur2-yur1)/csy1); dr1=int(dr1)+bool(roundoff(dr1-int(dr1),1e-10))*bool(big)
    dr2=max(0,(yll1-yll2)/csy1); dr2=int(dr2)+bool(roundoff(dr2-int(dr2),1e-10))*bool(big)
    dc1=max(0,(xll1-xll2)/csx1); dc1=int(dc1)+bool(roundoff(dc1-int(dc1),1e-10))*bool(big)
    dc2=max(0,(xur2-xur1)/csx1); dc2=int(dc2)+bool(roundoff(dc2-int(dc2),1e-10))*bool(big)
    xll3,ncol3=xll1-dc1*csx1,ncol1+dc1+dc2
    yll3,nrow3=yll1-dr2*csy1,nrow1+dr1+dr2
    return [xll3,yll3,csx1,csy1,1,0.0,nrow3,ncol3],[dr1,dr2,dc1,dc2]

def clone2reform(clone1,clone2,big=0):
    clone3,n1=clone2intersect(clone1,clone2,big)
    clone3,n2=clone2expand(clone3,clone2,big)
    return clone3,[n1[0]+n2[0],n1[1]+n2[1],n1[2]+n2[2],n1[3]+n2[3]]

def clipclone(clone,cliparr):
    clone=readclone(clone)
    ind=indices(cliparr.shape,int32)
    rmin,rmax,cmin,cmax=where(cliparr != 0,ind[0],clone[6]).min(),where(cliparr != 0,ind[0],-1).max(),where(cliparr != 0,ind[1],clone[7]).min(),where(cliparr != 0,ind[1],-1).max()
    return [clone[0]+cmin*clone[2],clone[1]+(clone[6]-rmax-1)*clone[3],clone[2],clone[3],clone[4],clone[5],rmax-rmin+1,cmax-cmin+1]

def array2intersect(maparray,clone1,clone2,big=0):
    maparr=maparray.copy()
    clone3,n=clone2intersect(clone1,clone2,big)
    nrow,ncol=maparr.shape
    maparr=maparr[max(0,-n[0]):max(0,nrow+n[1]),max(0,-n[2]):max(0,ncol+n[3])]
    return maparr,clone3

def array2expand(maparray,clone1,clone2,big=0,mv=-9999):
    try:
        if mv-int(mv) == 0:
            mv=int(mv)
    except:
        mv=-9999
    if maparray.dtype.name != "float64":
        maparraytype=get_arrtype([maparray.min(),maparray.max(),mv],None)
    else:
        maparraytype=float64
    maparr=array(maparray,maparraytype)
    clone3,n=clone2expand(clone1,clone2,big)
    nrow,ncol=maparr.shape
    if n[0] > 0:
        maparr=concatenate([ones((n[0],ncol),maparraytype)*mv,maparr],0); nrow,ncol=maparr.shape
    if n[1] > 0:
        maparr=concatenate([maparr,ones((n[1],ncol),maparraytype)*mv],0); nrow,ncol=maparr.shape
    if n[2] > 0:
        maparr=concatenate([ones((nrow,n[2]),maparraytype)*mv,maparr],1); nrow,ncol=maparr.shape
    if n[3] > 0:
        maparr=concatenate([maparr,ones((nrow,n[3]),maparraytype)*mv],1)
    return maparr,clone3

def array2reform(maparray,clone1,clone2,big=0,mv=-9999):
    try:
        if mv-int(mv) == 0:
            mv=int(mv)
    except:
        mv=-9999
    if maparray.dtype.name != "float64":
        maparraytype=get_arrtype([maparray.min(),maparray.max(),mv],None)
    else:
        maparraytype=float64
    maparr=array(maparray,maparraytype)
    clone3,n=clone2reform(clone1,clone2,big)
    nrow,ncol=maparr.shape
    maparr=maparr[max(0,-n[0]):max(0,nrow+n[1]),max(0,-n[2]):max(0,ncol+n[3])]; nrow,ncol=maparr.shape
    if n[0] > 0:
        maparr=concatenate([ones((n[0],ncol),maparraytype)*mv,maparr],0); nrow,ncol=maparr.shape
    if n[1] > 0:
        maparr=concatenate([maparr,ones((n[1],ncol),maparraytype)*mv],0); nrow,ncol=maparr.shape
    if n[2] > 0:
        maparr=concatenate([ones((nrow,n[2]),maparraytype)*mv,maparr],1); nrow,ncol=maparr.shape
    if n[3] > 0:
        maparr=concatenate([maparr,ones((nrow,n[3]),maparraytype)*mv],1)
    return maparr,clone3

def array2resample_alt(arr,clone1,clone2,reform=True,nodata=-9999,method="avg"):
    if abs(array(clone1,float64)-array(clone2,float64)).sum() != 0:

        if not reform: clone2=clone2intersect(clone2,clone1,1)[0]
        nrow1,ncol1=clone1[6:8]
        nrow2,ncol2=clone2[6:8]
        dr1,dr2,dc1,dc2=clone2intersect(clone2,clone1,1)[1]
        r1,r2,c1,c2=max(0,-dr1),min(nrow2,nrow2+dr2),max(0,-dc1),min(ncol2,ncol2+dc2)

        arr2=ones((nrow2,ncol2),float32)*nodata

        x1,y1=clone2xyarr(clone1,False)
        xl1,xr1=x1-clone1[2]/2.,x1+clone1[2]/2.
        yl1,yu1=y1-clone1[3]/2.,y1+clone1[3]/2.
        x2,y2=clone2xyarr(clone2,False)
        xl2,xr2=x2-clone2[2]/2.,x2+clone2[2]/2.
        yl2,yu2=y2-clone2[3]/2.,y2+clone2[3]/2.

        dx=zeros((ncol2,ncol1),float32)
        dy=zeros((nrow2,nrow1,1),float32)

        arr1=MA.masked_values(arr,nodata).ravel()
        if arr1.mask.min() != True:

            if ncol2 < ncol1:
                for c in range(c1,c2):
                    dx[c]=maximum(minimum(xr1,xr2[c])-maximum(xl1,xl2[c]),0)
            else:
                for c in range(0,ncol1):
                    dx[:,c]=maximum(minimum(xr2,xr1[c])-maximum(xl2,xl1[c]),0)

            if nrow2 < nrow1:
                for r in range(r1,r2):
                    dy[r,:,0]=maximum(minimum(yu1,yu2[r])-maximum(yl1,yl2[r]),0)
            else:
                for r in range(0,nrow1):
                    dy[:,r,0]=maximum(minimum(yu2,yu1[r])-maximum(yl2,yl1[r]),0)

            if string.find(method,"sum") != -1 or string.find(method,"tot") != -1:
                for r in range(r1,r2):
                    for c in range(c1,c2):
                        w=MA.array(ravel(dx[c]*dy[r]),mask=arr1.mask)
                        if w.sum() != 0:
                            arr2[r,c]=compress(w > 0,arr1,0).sum()
            elif string.find(method,"min") != -1:
                for r in range(r1,r2):
                    for c in range(c1,c2):
                        w=MA.array(ravel(dx[c]*dy[r]),mask=arr1.mask)
                        if w.sum() != 0:
                            arr2[r,c]=compress(w > 0,arr1,0).min()
            elif string.find(method,"max") != -1:
                for r in range(r1,r2):
                    for c in range(c1,c2):
                        w=MA.array(ravel(dx[c]*dy[r]),mask=arr1.mask)
                        if w.sum() != 0:
                            arr2[r,c]=compress(w > 0,arr1,0).max()
            elif string.find(method,"harm") != -1:
                for r in range(r1,r2):
                    for c in range(c1,c2):
                        w=MA.array(ravel(dx[c]*dy[r]),mask=arr1.mask)
                        w=where(arr1 == 0,0,w)
                        if w.sum() != 0:
                            a,w=compress(w != 0,arr1,0),compress(w != 0,w,0)
                            a=((a*w)**-1).sum()
                            if a != 0: arr2[r,c]=w.sum()/a
            elif string.find(method,"log10") != -1:
                for r in range(r1,r2):
                    for c in range(c1,c2):
                        w=MA.array(ravel(dx[c]*dy[r]),mask=arr1.mask)
                        w=where(arr1 == 0,0,w)
                        if w.sum() != 0:
                            a,w=compress(w != 0,arr1,0),compress(w != 0,w,0)
                            arr2[r,c]=power(10,(log10(a)*w).sum()/w.sum())
            elif string.find(method,"log") != -1 or string.find(method,"ln") != -1:
                for r in range(r1,r2):
                    for c in range(c1,c2):
                        w=MA.array(ravel(dx[c]*dy[r]),mask=arr1.mask)
                        w=where(arr1 == 0,0,w)
                        if w.sum() != 0:
                            a,w=compress(w != 0,arr1,0),compress(w != 0,w,0)
                            arr2[r,c]=exp((log(a)*w).sum()/w.sum())
            else:
                for r in range(r1,r2):
                    for c in range(c1,c2):
                        w=MA.array(ravel(dx[c]*dy[r]),mask=arr1.mask)
                        if w.sum() != 0:
                            arr2[r,c]=(arr1*w).sum()/w.sum()
        return arr2
    else: return arr,clone1

def array2resample(maparray,clone1,clone2,reform=True,mv=-9999,method="avg"):
    clone1ini,clone2ini=deepcopy(clone1),deepcopy(clone2)
    nodata=mv
    if abs(array(clone1,float64)-array(clone2,float64)).sum() != 0:
        try:
            try:
                if nodata-int(nodata) == 0:
                    nodata=int(nodata)
            except:
                nodata=-9999
            try: method=string.lower(method)
            except: method="avg"
            if maparray.dtype.name != "float64":
                maparraytype=get_arrtype([maparray.min(),maparray.max(),nodata],None)
            else:
                maparraytype=float64
            maparr,clone1=array2intersect(array(maparray,maparraytype),clone1,clone2,1)
            xll1,yll1,csx1,csy1,proj1,ang1,nrow1,ncol1=readclone(clone1)
            xll2,yll2,csx2,csy2,proj2,ang2,nrow2,ncol2=readclone(clone2)
            csx0,csy0=calc_gcd(csx1,csx2),calc_gcd(csy1,csy2)
            if xll1-xll2 != 0: csx0=calc_gcd(csx0,xll1-xll2)
            if yll1-yll2 != 0: csy0=calc_gcd(csy0,yll1-yll2)
            if (((csx1*ncol1)%csx2)/csx0)%2 != 0:
                csx0=csx0/2
            if (((csy1*nrow1)%csy2)/csy0)%2 != 0:
                csy0=csy0/2
            nrow0,ncol0=int((csy1/csy0)*nrow1),int((csx1/csx0)*ncol1)
            maparr=repeat(repeat(maparr,nrow0/nrow1,axis=0),ncol0/ncol1,axis=1)
            clone0=[xll1,yll1,csx0,csy0,proj1,ang1,nrow0,ncol0]
            if reform:
                maparr,clone0=array2reform(maparr,clone0,clone2,0,nodata)
            else:
                maparr,clone0=array2intersect(maparr,clone0,clone2,0)
            xll0,yll0,csx0,csy0,proj0,ang0,nrow0,ncol0=clone0
            nrow3,ncol3=int(roundoff(nrow0*csy0/csy2,1e-10)),int(roundoff(ncol0*csx0/csx2,1e-10))
            if nrow3 > 0 and ncol3 > 0:
                dr,dc=int(csy2/csy0),int(csx2/csx0)
                if string.find(method,"sum") != -1 or string.find(method,"tot") != -1:
                    maparr=array(MA.filled(MA.sum(MA.masked_values(\
                        reshape(swapaxes(reshape(maparr,(nrow0/dr,dr,ncol0)),1,2),(nrow0/dr,ncol0/dc,dr*dc)),\
                        value=nodata),axis=-1),fill_value=nodata),dtype=maparraytype)
                elif string.find(method,"min") != -1:
                    nodata0=maparr.max()+1
                    maparr=reshape(swapaxes(reshape(maparr,(nrow0/dr,dr,ncol0)),1,2),(nrow0/dr,ncol0/dc,dr*dc))
                    maparr=sort(where(maparr == nodata,nodata0,maparr),axis=-1)[:,:,0]
                    maparr=array(where(maparr == nodata0,nodata,maparr),dtype=maparraytype)
                elif string.find(method,"max") != -1:
                    nodata0=maparr.min()-1
                    maparr=reshape(swapaxes(reshape(maparr,(nrow0/dr,dr,ncol0)),1,2),(nrow0/dr,ncol0/dc,dr*dc))
                    maparr=sort(where(maparr == nodata,nodata0,maparr),axis=-1)[:,:,-1]
                    maparr=array(where(maparr == nodata0,nodata,maparr),dtype=maparraytype)
                elif string.find(method,"harm") != -1:
                    nodataarr=array(where(maparr != nodata,where(maparr != 0,0,1),1),uint8)
                    maparr=where(nodataarr == 1,1,maparr); maparr=where(nodataarr == 1,nodata,1/maparr)
                    maparr=array(MA.filled(MA.average(MA.masked_values(\
                        reshape(swapaxes(reshape(maparr,(nrow0/dr,dr,ncol0)),1,2),(nrow0/dr,ncol0/dc,dr*dc)),\
                        value=nodata),axis=-1),fill_value=nodata),dtype=maparraytype)
                    nodataarr=array(where(maparr != nodata,where(maparr != 0,0,1),1),uint8)
                    maparr=where(nodataarr == 1,1,maparr); maparr=where(nodataarr == 1,nodata,1/maparr)
                elif string.find(method,"log10") != -1:
                    nodataarr=array(where(maparr != nodata,where(maparr > 0,0,1),1),uint8)
                    maparr=where(nodataarr == 1,1,maparr); maparr=where(nodataarr == 1,nodata,log10(maparr))
                    maparr=array(MA.filled(MA.average(MA.masked_values(\
                        reshape(swapaxes(reshape(maparr,(nrow0/dr,dr,ncol0)),1,2),(nrow0/dr,ncol0/dc,dr*dc)),\
                        value=nodata),axis=-1),fill_value=nodata),dtype=maparraytype)
                    maparr=where(maparr != nodata,power(10,maparr),nodata)
                elif string.find(method,"log") != -1 or string.find(method,"ln") != -1:
                    nodataarr=array(where(maparr != nodata,where(maparr > 0,0,1),1),uint8)
                    maparr=where(nodataarr == 1,1,maparr); maparr=where(nodataarr == 1,nodata,log(maparr))
                    maparr=array(MA.filled(MA.average(MA.masked_values(\
                        reshape(swapaxes(reshape(maparr,(nrow0/dr,dr,ncol0)),1,2),(nrow0/dr,ncol0/dc,dr*dc)),\
                        value=nodata),axis=-1),fill_value=nodata),dtype=maparraytype)
                    maparr=where(maparr != nodata,exp(maparr),nodata)
                else:
                    maparr=array(MA.filled(MA.average(MA.masked_values(\
                        reshape(swapaxes(reshape(maparr,(nrow0/dr,dr,ncol0)),1,2),(nrow0/dr,ncol0/dc,dr*dc)),\
                        value=nodata),axis=-1),fill_value=nodata),dtype=maparraytype)
            else:
                maparr=zeros((0,0),maparraytype)
            return maparr,[xll0,yll0,csx2,csy2,1,0.0,nrow3,ncol3]
        except:
            return array2resample_alt(maparray,clone1ini,clone2ini,reform,nodata,method),clone2
    else:
        return maparray,clone1

def windowarr(arr,dwinarr=1,avg_tot=0,nodata=-9999): # dwinarr=1: 3x3 window
    arrtype=arr.dtype.name
    if arrtype != float64: arr=array(arr,float32)
    if type(dwinarr) not in [str,bool,int,long,float,string_,bool_,uint8,uint16,uint32,uint64,int8,int16,int32,int64,float16,float32,float64]:
        if dwinarr.max() == dwinarr.min(): dwinarr=float(dwinarr.max())
    if type(dwinarr) in [str,bool,int,long,float,string_,bool_,uint8,uint16,uint32,uint64,int8,int16,int32,int64,float16,float32,float64]:
        dwinarr=float(dwinarr)
        if dwinarr == int(dwinarr): dwinmax=int(dwinarr)
        else: dwinmax=int(dwinarr)+1
    else:
        dwinarr=array(where(dwinarr == nodata,0,dwinarr),float32)
        dwinmax=minimum(maximum(arr.shape[0]-1,arr.shape[1]-1),dwinarr.max())
        if dwinmax == int(dwinmax): dwinmax=int(dwinmax)
        else: dwinmax=int(dwinmax)+1
    cnt=array(where(arr != nodata,1,0),float32)
    arr=where(arr != nodata,arr,0)
    arr1,cnt1=arr.copy(),cnt.copy()
    if type(dwinarr) in [float,float16,float32,float64]:
        for dr in range(-dwinmax,0):
            for dc in range(-dwinmax,0):
                mult=(1-minimum(maximum(0,-dr-dwinarr),1))*(1-minimum(maximum(0,-dc-dwinarr),1))
                arr1[:dr,:dc]=arr1[:dr,:dc]+mult*arr[-dr:,-dc:]
                cnt1[:dr,:dc]=cnt1[:dr,:dc]+mult*cnt[-dr:,-dc:]
            for dc in range(1,dwinmax+1):
                mult=(1-minimum(maximum(0,-dr-dwinarr),1))*(1-minimum(maximum(0,dc-dwinarr),1))
                arr1[:dr,dc:]=arr1[:dr,dc:]+mult*arr[-dr:,:-dc]
                cnt1[:dr,dc:]=cnt1[:dr,dc:]+mult*cnt[-dr:,:-dc]
            mult=(1-minimum(maximum(0,-dr-dwinarr),1))
            arr1[:dr,:]=arr1[:dr,:]+mult*arr[-dr:,:]
            cnt1[:dr,:]=cnt1[:dr,:]+mult*cnt[-dr:,:]
        for dr in range(1,dwinmax+1):
            for dc in range(-dwinmax,0):
                mult=(1-minimum(maximum(0,dr-dwinarr),1))*(1-minimum(maximum(0,-dc-dwinarr),1))
                arr1[dr:,:dc]=arr1[dr:,:dc]+mult*arr[:-dr,-dc:]
                cnt1[dr:,:dc]=cnt1[dr:,:dc]+mult*cnt[:-dr,-dc:]
            for dc in range(1,dwinmax+1):
                mult=(1-minimum(maximum(0,dr-dwinarr),1))*(1-minimum(maximum(0,dc-dwinarr),1))
                arr1[dr:,dc:]=arr1[dr:,dc:]+mult*arr[:-dr,:-dc]
                cnt1[dr:,dc:]=cnt1[dr:,dc:]+mult*cnt[:-dr,:-dc]
            mult=(1-minimum(maximum(0,dr-dwinarr),1))
            arr1[dr:,:]=arr1[dr:,:]+mult*arr[:-dr,:]
            cnt1[dr:,:]=cnt1[dr:,:]+mult*cnt[:-dr,:]
        for dc in range(-dwinmax,0):
            mult=(1-minimum(maximum(0,-dc-dwinarr),1))
            arr1[:,:dc]=arr1[:,:dc]+mult*arr[:,-dc:]
            cnt1[:,:dc]=cnt1[:,:dc]+mult*cnt[:,-dc:]
        for dc in range(1,dwinmax+1):
            mult=(1-minimum(maximum(0,dc-dwinarr),1))
            arr1[:,dc:]=arr1[:,dc:]+mult*arr[:,:-dc]
            cnt1[:,dc:]=cnt1[:,dc:]+mult*cnt[:,:-dc]
    else:
        for dr in range(-dwinmax,0):
            for dc in range(-dwinmax,0):
                mult=(1-minimum(maximum(0,-dr-dwinarr),1))*(1-minimum(maximum(0,-dc-dwinarr),1))
                arr1[:dr,:dc]=arr1[:dr,:dc]+mult[:dr,:dc]*arr[-dr:,-dc:]
                cnt1[:dr,:dc]=cnt1[:dr,:dc]+mult[:dr,:dc]*cnt[-dr:,-dc:]
            for dc in range(1,dwinmax+1):
                mult=(1-minimum(maximum(0,-dr-dwinarr),1))*(1-minimum(maximum(0,dc-dwinarr),1))
                arr1[:dr,dc:]=arr1[:dr,dc:]+mult[:dr,dc:]*arr[-dr:,:-dc]
                cnt1[:dr,dc:]=cnt1[:dr,dc:]+mult[:dr,dc:]*cnt[-dr:,:-dc]
            mult=(1-minimum(maximum(0,-dr-dwinarr),1))
            arr1[:dr,:]=arr1[:dr,:]+mult[:dr,:]*arr[-dr:,:]
            cnt1[:dr,:]=cnt1[:dr,:]+mult[:dr,:]*cnt[-dr:,:]
        for dr in range(1,dwinmax+1):
            for dc in range(-dwinmax,0):
                mult=(1-minimum(maximum(0,dr-dwinarr),1))*(1-minimum(maximum(0,-dc-dwinarr),1))
                arr1[dr:,:dc]=arr1[dr:,:dc]+mult[dr:,:dc]*arr[:-dr,-dc:]
                cnt1[dr:,:dc]=cnt1[dr:,:dc]+mult[dr:,:dc]*cnt[:-dr,-dc:]
            for dc in range(1,dwinmax+1):
                mult=(1-minimum(maximum(0,dr-dwinarr),1))*(1-minimum(maximum(0,dc-dwinarr),1))
                arr1[dr:,dc:]=arr1[dr:,dc:]+mult[dr:,dc:]*arr[:-dr,:-dc]
                cnt1[dr:,dc:]=cnt1[dr:,dc:]+mult[dr:,dc:]*cnt[:-dr,:-dc]
            mult=(1-minimum(maximum(0,dr-dwinarr),1))
            arr1[dr:,:]=arr1[dr:,:]+mult[dr:,:]*arr[:-dr,:]
            cnt1[dr:,:]=cnt1[dr:,:]+mult[dr:,:]*cnt[:-dr,:]
        for dc in range(-dwinmax,0):
            mult=(1-minimum(maximum(0,-dc-dwinarr),1))
            arr1[:,:dc]=arr1[:,:dc]+mult[:,:dc]*arr[:,-dc:]
            cnt1[:,:dc]=cnt1[:,:dc]+mult[:,:dc]*cnt[:,-dc:]
        for dc in range(1,dwinmax+1):
            mult=(1-minimum(maximum(0,dc-dwinarr),1))
            arr1[:,dc:]=arr1[:,dc:]+mult[:,dc:]*arr[:,:-dc]
            cnt1[:,dc:]=cnt1[:,dc:]+mult[:,dc:]*cnt[:,:-dc]
    cnt1=where(cnt1 == 0,-1,cnt1)
    if avg_tot == 0: arr1=arr1/cnt1
    arr1=where(cnt1 != -1,arr1,nodata)
    return array(arr1,arrtype)

def windowmax(arr,dwinarr=1,nodata=-9999):
    arrtype=arr.dtype.name
    if arrtype != float64: arr=array(arr,float32)
    if type(dwinarr) in [str,bool,int,long,float,string_,bool_,uint8,uint16,uint32,uint64,int8,int16,int32,int64,float16,float32,float64]: dwinarr,dwinmax=int(dwinarr),int(dwinarr)
    else:
        dwinarr=array(around(dwinarr),int32)
        dwinmax=min(max(arr.shape[0]-1,arr.shape[1]-1),dwinarr.max())
    minval=min(nodata-1,arr.min()-1)
    arr=where(arr != nodata,arr,minval)
    arr1=arr.copy()
    for dr in range(-dwinmax,0):
        for dc in range(-dwinmax,0):
            if type(dwinarr) != int:
                arr1[:dr,:dc]=where(dwinarr[:dr,:dc] >= -dr,where(dwinarr[:dr,:dc] >= -dc,maximum(arr1[:dr,:dc],arr[-dr:,-dc:]),arr1[:dr,:dc]),arr1[:dr,:dc])
            else: arr1[:dr,:dc]=maximum(arr1[:dr,:dc],arr[-dr:,-dc:])
        for dc in range(1,dwinmax+1):
            if type(dwinarr) != int:
                arr1[:dr,dc:]=where(dwinarr[:dr,dc:] >= -dr,where(dwinarr[:dr,dc:] >= dc,maximum(arr1[:dr,dc:],arr[-dr:,:-dc]),arr1[:dr,dc:]),arr1[:dr,dc:])
            else: arr1[:dr,dc:]=maximum(arr1[:dr,dc:],arr[-dr:,:-dc])
        if type(dwinarr) != int:
            arr1[:dr,:]=where(dwinarr[:dr,:] >= -dr,maximum(arr1[:dr,:],arr[-dr:,:]),arr1[:dr,:])
        else: arr1[:dr,:]=maximum(arr1[:dr,:],arr[-dr:,:])
    for dr in range(1,dwinmax+1):
        for dc in range(-dwinmax,0):
            if type(dwinarr) != int:
                arr1[dr:,:dc]=where(dwinarr[dr:,:dc] >= dr,where(dwinarr[dr:,:dc] >= -dc,maximum(arr1[dr:,:dc],arr[:-dr,-dc:]),arr1[dr:,:dc]),arr1[dr:,:dc])
            else: arr1[dr:,:dc]=maximum(arr1[dr:,:dc],arr[:-dr,-dc:])
        for dc in range(1,dwinmax+1):
            if type(dwinarr) != int:
                arr1[dr:,dc:]=where(dwinarr[dr:,dc:] >= dr,where(dwinarr[dr:,dc:] >= dc,maximum(arr1[dr:,dc:],arr[:-dr,:-dc]),arr1[dr:,dc:]),arr1[dr:,dc:])
            else: arr1[dr:,dc:]=maximum(arr1[dr:,dc:],arr[:-dr,:-dc])
        if type(dwinarr) != int:
            arr1[dr:,:]=where(dwinarr[dr:,:] >= dr,maximum(arr1[dr:,:],arr[:-dr,:]),arr1[dr:,:])
        else: arr1[dr:,:]=maximum(arr1[dr:,:],arr[:-dr,:])
    for dc in range(-dwinmax,0):
        if type(dwinarr) != int:
            arr1[:,:dc]=where(dwinarr[:,:dc] >= -dc,maximum(arr1[:,:dc],arr[:,-dc:]),arr1[:,:dc])
        else: arr1[:,:dc]=maximum(arr1[:,:dc],arr[:,-dc:])
    for dc in range(1,dwinmax+1):
        if type(dwinarr) != int:
            arr1[:,dc:]=where(dwinarr[:,dc:] >= dc,maximum(arr1[:,dc:],arr[:,:-dc]),arr1[:,dc:])
        else: arr1[:,dc:]=maximum(arr1[:,dc:],arr[:,:-dc])
    arr1=where(arr1 != minval,arr1,nodata)
    return array(arr1,arrtype)

def windowavg(arr,dwinarr=1,nodata=-9999):
    return windowarr(arr,dwinarr,0,nodata)
def windowharmavg(arr,dwinarr=1,nodata=-9999):
    nodatarr=array(where(arr != nodata,where(arr != 0,0,1),1),uint8)
    arr=where(nodatarr == 1,nodata,arr); arr=where(arr != nodata,1/arr,nodata)
    arr=windowarr(arr,dwinarr,0,nodata)
    nodatarr=array(where(arr != nodata,where(arr != 0,0,1),1),uint8)
    arr=where(nodatarr == 1,nodata,arr); arr=where(arr != nodata,1/arr,nodata)
    return arr
def windowtot(arr,dwinarr=1,nodata=-9999):
    return windowarr(arr,dwinarr,1,nodata)
def windowmin(arr,dwinarr=1,nodata=-9999):
    return -windowmax(where(arr != nodata,-arr,nodata),dwinarr,nodata)
def windowaverage(arr,dwinarr=1,nodata=-9999):
    return windowavg(arr,dwinarr,nodata)
def windowharmaverage(arr,dwinarr=1,nodata=-9999):
    return windowharmavg(arr,dwinarr,nodata)
def windowtotal(arr,dwinarr=1,nodata=-9999):
    return windowtot(arr,dwinarr,nodata)
def windowsum(arr,dwinarr=1,nodata=-9999):
    return windowtot(arr,dwinarr,nodata)
def windowmaximum(arr,dwinarr=1,nodata=-9999):
    return windowmax(arr,dwinarr,nodata)
def windowminimum(arr,dwinarr=1,nodata=-9999):
    return windowmin(arr,dwinarr,nodata)

def arr_nodata(arr,nodata=-9999):
    nd=array(where(arr == nodata,1,0),uint8)
    return where(nd == 1,1,arr.copy()),nd

def arr2border(arr,thick=False,nodata=-9999):
    nrow,ncol=arr.shape
    arr=array(where(arr == nodata,0,where(arr == 0,0,1)),uint8)
    arr2=zeros((nrow,ncol),uint8)
    arr2=arr2+(arr.copy()-concatenate([zeros((1,ncol),uint8),arr[:-1,:]]))
    arr2=arr2+(arr.copy()-concatenate([arr[1:,:],zeros((1,ncol),uint8)]))
    arr2=arr2+(arr.copy()-concatenate([zeros((nrow,1),uint8),arr[:,:-1]],axis=1))
    arr2=arr2+(arr.copy()-concatenate([arr[:,1:],zeros((nrow,1),uint8)],axis=1))
    if thick:
        arr2=arr2+(arr.copy()-concatenate([zeros((nrow,1),uint8),concatenate([zeros((1,ncol-1),uint8),arr[:-1,:-1]])],axis=1))
        arr2=arr2+(arr.copy()-concatenate([concatenate([arr[1:,1:],zeros((1,ncol-1),uint8)]),zeros((nrow,1),uint8)],axis=1))
        arr2=arr2+(arr.copy()-concatenate([zeros((nrow,1),uint8),concatenate([arr[1:,:-1],zeros((1,ncol-1),uint8)])],axis=1))
        arr2=arr2+(arr.copy()-concatenate([concatenate([zeros((1,ncol-1),uint8),arr[:-1,1:]]),zeros((nrow,1),uint8)],axis=1))
    arr2=array(where(arr == 1,where(arr2 == 0,0,1),0),uint8)
    return arr2

def arr_calc(l0,func="+",nodata=-9999,at0=bool,clones0=None,fill=None,lnodata=None):
    ## Set nodata for each variable
    if lnodata == None: lnodata=[nodata]
    elif type(lnodata) in [complex,bool,int,long,float,bool_,uint8,uint16,uint32,uint64,int8,int16,int32,int64,float16,float32,float64]: lnodata=[lnodata]
    else: lnodata=var2list(lnodata)
    for i in range(len(lnodata),len(l0)): lnodata.append(nodata)
    ## Set fill value for each variable
    if fill != None:
        if type(fill) in [complex,bool,int,long,float,bool_,uint8,uint16,uint32,uint64,int8,int16,int32,int64,float16,float32,float64]: fill=[fill]
        else: fill=var2list(fill)
        for i in range(len(fill),len(l0)): fill.append(fill[-1])
    ## Set initial clone for each variable
    if clones0 != None:
        if type(clones0) in [complex,str,bool,int,long,float,string_,bool_,uint8,uint16,uint32,uint64,int8,int16,int32,int64,float16,float32,float64]: clones0=[]
        else: clones0=var2list(clones0)
        for i in range(len(clones0),len(l0)): clones0.append(None)
        for i in range(0,len(l0)):
            if readsource(l0[i]) in [1,2,3,4]:
                clones0[i]=readclone(l0[i])
    ## If variable not needed, turn variable off
    if func not in ["+","-","*","/","**"]:
        for i in range(0,len(l0)):
            if string.find(func,"l[%d]" %(i)) == -1:
                l0[i]=None
                if clones0 != None: clones0[i]=None
    ## Read maps
    for i in range(0,len(l0)):
        if readsource(l0[i]) in [1,2,3,4]:
            l0[i]=spatial2array(l0[i],lnodata[i])
    ## Set array type
    at=get_arrtype(nodata,at0)
    for i in range(0,len(lnodata)): at=get_arrtype(lnodata[i],at)
    for i in range(0,len(l0)): at=get_arrtype(l0[i],at)
    at0=float32
    if at == float64: at0=float64
    elif at in [bool,uint8,int8,uint16,int16,uint32,int32]: at0=int32
    ## Set overall clone if needed
    if clones0 != None:
        clones,gcd,xll,yll,xur,yur=[],[None,None],1e31,1e31,-1e31,-1e31
        for i in range(0,len(l0)):
            if clones0 != None: clones.append(clones0[i])
            else:
                ash=get_varspecs(l0[i])[1]
                if len(ash) == 2 and len(get_shape(ash)) == 1:
                    nr,nc=ash; clones.append([0.,0.,-1.,-1.,1,0.,nr,nc])
                else: clones.append(None)
        for i in range(0,len(clones)):
            if clones[i] != None:
                if clones[i][2] == -1:
                    for j in range(0,i)+range(i+1,len(clones)):
                        if clones[j] != None:
                            if clones[j][2] != -1 and clones[i][-2] == clones[j][-2] and clones[i][-1] == clones[i][-1]:
                                clones[i]=deepcopy(clones[j]); break
                if clones[i][2] != -1:
                    if gcd[0] == None: gcd=clones[i][2:4]
                    else: gcd[0],gcd[1]=calc_gcd(gcd[0],clones[i][2]),calc_gcd(gcd[1],clones[i][3])
                    xll,yll=min(xll,clones[i][0]),min(yll,clones[i][1])
                    xur,yur=max(xur,clones[i][0]+clones[i][2]*clones[i][7]),max(yur,clones[i][1]+clones[i][3]*clones[i][6])
        clone=[xll,yll,gcd[0],gcd[1],1,0.,int((yur-yll)/gcd[1]),int((xur-xll)/gcd[0])]
        for i in range(0,len(l0)):
            if clones[i] != None:
                l0[i]=array2resample(l0[i],clones[i],clone,True,lnodata[i],"avg")[0]
                if fill != None: l0[i]=where(l0[i] == lnodata[i],fill[i],l0[i])
    ## Set array type for each variable and set nodata array
    l,nd,all_nodata=deepcopy(l0),None,False
    for i in range(0,len(l)):
        if type(l[i]) not in [type(None),complex,str,bool,int,long,float,string_,bool_,uint8,uint16,uint32,uint64,int8,int16,int32,int64,float16,float32,float64]:
            l[i]=array(l[i],at0)
            a0,nd0=arr_nodata(l[i],lnodata[i])
            l[i]=a0.copy()
            if nd == None: nd=nd0.copy()
            else: nd=where(nd0 == 1,1,nd)
            if func == "/" and i != 0:
                a0,nd0=arr_nodata(l[i],0)
                l[i]=a0.copy()
                if nd == None: nd=nd0.copy()
                else: nd=where(nd0 == 1,1,nd)
        elif i != 0 and func == "/" and l[i] == 0:
            all_nodata=True
    ## If all cells are nodata, return nodata
    if all_nodata:
        try: return ones(nd.shape,at0)*nodata
        except: return nodata
    ## Calculate function
    if func in ["+","-","*","/","**"]:
        cmd="result=l[0]"
        for i in range(1,len(l)):
            cmd=cmd+"%sl[%d]" %(func,i)
    else:
        cmd="result=%s" %(func)
        #for i in range(0,len(l)): cmd=string.replace(cmd,"l%d" %(i),"l[%d]" %(i))
    exec(cmd)
    ## Set nodata cells and return result
    try:
        result=where(nd == 1,nodata,result)
        if at0 in [bool,uint8,int8,uint16,int16,uint32,int32]: at0=get_arrtype(result,at0)
        if clones0 != None: return array(result,at0),clone
        else: return array(result,at0)
    except:
        if clones0 != None: return result,clone
        else: return result

def interpolate_arr2xy(l_xy,arr,clone,nodata=-9999):
    dim=1
    l_xy=array(l_xy)
    if rank(l_xy) == 1: dim,l_xy=0,array([l_xy])
    l_rc=swapaxes(xy2rc(swapaxes(l_xy,0,1),clone),0,1)
    xll,yll,csx,csy,proj,ang,nrow,ncol=clone
    l_v=[]
    for i in range(0,len(l_xy)):
        v=nodata
        r,c=l_rc[i]
        if r >= 0 and r < nrow and c >= 0 and c < ncol:
            v=arr[r,c]
            if v != nodata:
                x,y=l_xy[i]
                r1,c1,r2,c2=max(0,r-1),max(0,c-1),min(nrow,r+2),min(ncol,c+2)
                xyarr=indices((r2-r1,c2-c1),float64)
                xarr,yarr=(xyarr[1]*csx)+xll+csx*0.5+csx*c1,(xyarr[0][::-1]*csy)+yll+csy*0.5+csy*(nrow-r2)
                dx,dy=maximum(csx-abs(xarr-x),0),maximum(csy-abs(yarr-y),0)
                dxy=dx*dy; dxy=where(arr[r1:r2,c1:c2] == nodata,0,dxy)
                dxy=dxy/dxy.sum()
                v=(arr[r1:r2,c1:c2].copy()*dxy).sum()
        l_v.append(v)
    if dim == 0: l_v=l_v[0]
    return l_v

def index2coord(maparray,clone):
    if type(maparray) in [list,tuple]:
        mapshape=maparray
    else:
        mapshape=maparray.shape
    xll,yll,cellsizex,cellsizey,proj,angle,nrow,ncol=readclone(clone)
    if nrow == 0 and ncol == 0:
        nrow,ncol=mapshape[:2]
    elif (nrow != mapshape[0]) or (ncol != mapshape[1]):
        raise Exception,"array does not fit clone"
    x=(arange(0,ncol,dtype=float32)+0.5)*cellsizex+xll
    if proj == 1:
        y=(arange(0,nrow,dtype=float32)[::-1]+0.5)*cellsizey+yll
    else:
        y=(arange(0,nrow,dtype=float32)+0.5-nrow)*cellsizey+yll
    return x,y

def createlinearray(clone,pointlist,coor=None,num=None):
    if type(clone) in [list,tuple]:
        linearray=zeros((clone[6],clone[7]),uint8)
    else:
        try:
            linearray=zeros((clone.shape),uint8)
        except:
            clone=readclone(clone)
            linearray=zeros((clone[6],clone[7]),uint8)
    if coor != None:
        xul,yll,cellsizex,cellsizey,proj,angle,nr,nc=clone
        if proj == 1:
            yul=yll+nr*cellsizey
        else:
            yul=yll-nr*cellsizey
        for p in range(0,len(pointlist)):
            pointlist[p][0]=int(((float(pointlist[p][0])-xul)/(cellsizex*nc))*nc)
            if proj == 1:
                pointlist[p][1]=int(((yul-float(pointlist[p][1]))/(cellsizey*nr))*nr)
            else:
                pointlist[p][1]=int(((float(pointlist[p][1]-yul))/(cellsizey*nr))*nr)
    number=1
    for p in range(0,len(pointlist)-1):
        p1,p2=pointlist[p],pointlist[p+1]
        deltac,deltar=float(p2[0]-p1[0]),float(p2[1]-p1[1])
        if abs(deltar) > abs(deltac):
            rstep=deltar/abs(deltar)
            if deltac == 0:
                cstep=0
            else:
                cstep=(deltac/abs(deltac))*abs(deltac/deltar)
            count=int(abs(deltar))
        else:
            if deltac == 0:
                cstep=0
            else:
                cstep=deltac/abs(deltac)
            if deltar == 0:
                rstep=0
            else:
                rstep=(deltar/abs(deltar))*abs(deltar/deltac)
            count=int(abs(deltac))
        c,r=p1[0],p1[1]
        for n in range(0,count):
            if r >= 0 and r < nr and c >= 0 and c < nc:
                linearray[int(r),int(around(c))]=number
                if num != None:
                    number=number+1
                for m in [4,2,1]:
                    if number > 256**m-1:
                        linearray=array(linearray,"uint"+str(8*m*2)); break
            r,c=r+rstep,c+cstep
        if p2[0] >= 0 and p2[0] < nc and p2[1] >= 0 and p2[1] < nr:
            linearray[p2[1],p2[0]]=number
    return linearray

def createpatternmap(clone,direction=1,step=4):
    if os.path.isfile(str(clone)):
        clone=readclone(clone)
    nrow,ncol=clone[6],clone[7]
    maparray=zeros((nrow,ncol),uint8)
    step=int(step)
    if direction in [1,9]:
        for r in range(0,nrow):
            for c in range(step-1-r%step,ncol,step):
                maparray[r,c]=1
    elif direction in [3,7]:
        for r in range(0,nrow):
            for c in range(r%step,ncol,step):
                maparray[r,c]=1
    elif direction in [2,8]:
        for r in range(0,nrow):
            for c in range(step/2,ncol,step):
                maparray[r,c]=1
    elif direction in [4,6]:
        for c in range(0,ncol):
            for r in range(step/2,nrow,step):
                maparray[r,c]=1
    else:
        for r in range(step/2,nrow,step):
            for c in range(step/2,ncol,step):
                maparray[r,c]=1
    return maparray

def clone2xyarr(clone,return_arr=True):
    xll,yll,csx,csy,proj,ang,nrow,ncol=readclone(clone)
    x=(arange(0,ncol,dtype=float32)+0.5)*csx+xll
    if proj == 1: y=(arange(0,nrow,dtype=float32)[::-1]+0.5)*csy+yll
    else: y=(arange(-nrow,0,dtype=float32)+0.5)*csy+yll
    if return_arr:
        x=repeat([x],nrow,0)
        y=repeat(reshape(y,(nrow,1)),ncol,-1)
    return x,y

def points2array(clone,pointlist,coor=None,calc="mean"):
    # pointlist: [[x,y,value], .. ]
    # coor != None: x,y are real coordinates instead of indices
    # calc: min, max, total, mean
    if type(clone) in [list,tuple]:
        pointarray=zeros((clone[6],clone[7]),float32)
    else:
        try:
            pointarray=zeros((clone.shape),float32)
        except:
            clone=readclone(clone)
            pointarray=zeros((clone[6],clone[7]),float32)
    pointnumarray=zeros(pointarray.shape)
    if coor != None:
        plist=deepcopy(pointlist); pointlist=[]
        xul,yll,cellsizex,cellsizey,proj,angle,nr,nc=clone
        xur=xul+cellsizex*nc
        if proj == 1:
            yul=yll+nr*cellsizey
        else:
            yul=yll-nr*cellsizey
        for p in range(0,len(plist)):
            x,y=plist[p][0],plist[p][1]
            if x >= xul and x <= xur and y >= min(yll,yul) and y <= max(yll,yul):
                newx=int(((float(x)-xul)/(xur-xul))*nc)
                if proj == 1:
                    newy=int(((yul-float(y))/(cellsizey*nr))*nr)
                else:
                    newy=int(((float(y)-yul)/(cellsizey*nr))*nr)
                pointlist.append([newx,newy,plist[p][2]])
    calc,calcflag=string.lower(str(calc)),1
    for p in pointlist:
        c,r=p[0],p[1]
        if len(p) >= 3 and calcflag == 1:
            if pointnumarray[r,c] == 0:
                pointarray[r,c]=p[2]
            else:
                if calc == "max":
                    pointarray[r,c]=max(pointarray[r,c],p[2])
                elif calc == "min":
                    pointarray[r,c]=min(pointarray[r,c],p[2])
                else:
                    pointarray[r,c]=pointarray[r,c]+p[2]
            pointnumarray[r,c]=pointnumarray[r,c]+1
        else:
            calcflag=0
            pointarray[r,c]=1
    if calcflag == 0:
        pointarray=array(where(pointarray > 0,1,0),uint8)
    elif calc not in ["min","max","total"]:
        for r in range(0,pointarray.shape[0]):
            for c in range(0,pointarray.shape[1]):
                if pointnumarray[r,c] != 0:
                    pointarray[r,c]=pointarray[r,c]/pointnumarray[r,c]
    return pointarray

def point2ind(xyl,clone):
    x,y=xyl
    clone=readclone(clone); xll,yll,csx,csy,proj,ang,nrow,ncol=clone
    if proj == 1:
        r=nrow-int((y-yll)/csy)-1
        if y == yll+csy*nrow:
            r=0
    else:
        r=nrow-int((yll-y)/csy)-1
        if y == yll-csy*nrow:
            r=0
    c=int((x-xll)/csx)
    if x == xll+csx*ncol:
        c=ncol-1
    return r,c

def xy2rc(xy,clone): # xy: 2xN matrix; rc: 2xN matrix
    xarr=array(xy[0],float64)
    yarr=array(xy[1],float64)
    clone=readclone(clone); xll,yll,csx,csy,proj,ang,nrow,ncol=clone
    if proj == 1:
        rarr=-array((yarr.copy()-yll)/csy,int32)-1+nrow
        rarr=where(yarr == yll+csy*nrow,0,rarr)
    else:
        rarr=-array((-yarr.copy()+yll)/csy,int32)-1+nrow
        rarr=where(yarr == yll-csy*nrow,0,rarr)
    carr=array((xarr.copy()-xll)/csx,int32)
    carr=where(xarr == xll+csx*ncol,ncol-1,carr)
    return array([rarr,carr],int32)

def ind2point(rcl,clone,ll=0):
    r,c=rcl
    if ll not in [0,None,0,False,""]:
        ll=1
    else:
        ll=0
    clone=readclone(clone); xll,yll,csx,csy,proj,ang,nrow,ncol=clone
    if proj == 1:
        y=yll+(nrow-r-0.5-0.5*ll)*csy
    else:
        y=yll-(nrow-r-0.5-0.5*ll)*csy
    x=xll+(c+0.5-0.5*ll)*csx
    return x,y

def rc2xy(rc,clone,ll=False):
    rarr=array(rc[0])
    carr=array(rc[1])
    if ll not in [0,None,False]: ll=1
    else: ll=0
    clone=readclone(clone); xll,yll,csx,csy,proj,ang,nrow,ncol=clone
    if proj == 1:
        yarr=(-rarr.copy()-0.5-0.5*ll+nrow)*csy+yll
    else:
        yarr=(rarr.copy()+0.5+0.5*ll-nrow)*csy+yll
    xarr=(carr.copy()+0.5-0.5*ll)*csx+xll
    return xarr,yarr

def get_random_array(clone_map,norm_lognorm_gsim,mean0,std0,add_mult=1,nran=1,zi_0_5=2,variogram="0 Sph(0)",nodata=-9999):
    import numarray.random_array as RAN
    zlut=[[1,84.1],[1.28,90],[1.645,95],[1.96,97.5],[2.55,99.5],[4.5,100]]
        # 0) Z=1:     PR=0.159 ==> 68.2% in range x +/- x*std0 ==> zie p84.1
        # 1) Z=1.28:  PR=0.1   ==> 80%   in range x +/- x*std0 ==> zie p90
        # 2) Z=1.645: PR=0.05  ==> 90%   in range x +/- x*std0 ==> zie p95
        # 3) Z=1.96:  PR=0.025 ==> 95%   in range x +/- x*std0 ==> zie p97.5
        # 4) Z=2.55:  PR=0.005 ==> 99%   in range x +/- x*std0 ==> zie p99.5
        # 5) Z=4.5:   PR~0.0   ==> ~100% in range x +/- x*std0 ==> zie p100
    clone=readclone(clone_map)
    z=zlut[zi_0_5][0]
    std=std0/z
    if norm_lognorm_gsim in [0,1] and std0 == 0: nran=1
    ranarr=resize(array(mean0,float64).copy(),(nran,clone[6],clone[7]))
    isnodata=array(where(ranarr == nodata,1,0),uint8)
    if not (norm_lognorm_gsim in [0,1] and std0 == 0):
        if norm_lognorm_gsim == 2:
            ranval=normalize(gstat_sim(clone_map,variogram,nran,nodata),[-std0,std0],2,nodata,[100-zlut[zi_0_5][1],zlut[zi_0_5][1]])
            if add_mult == 0: ranarr=ranarr+ranval.copy()
            else: ranarr=ranarr*(ranval.copy()+1)
        else:
            if norm_lognorm_gsim == 0:
                if add_mult == 0: ranarr=RAN.normal(ranarr,std)
                else: ranarr=RAN.normal(ranarr,ranarr*std)
            else:
                if where(ranarr > 0,1,0).sum() > 0:
                    if add_mult == 0:
                        ranarr=ranarr+exp(RAN.normal(zeros(ranarr.shape,float64),std))
                    else:
                        ranarr1=where(ranarr == 0,1,where(ranarr < 0,-ranarr.copy(),ranarr.copy()))
                        ranarr1=exp(RAN.normal(log(ranarr1),std))
                        ranarr=where(ranarr != 0,where(ranarr < 0,-ranarr1.copy(),ranarr1.copy()),ranarr)
        ranarr=where(isnodata == 1,nodata,ranarr)
    return ranarr


## GSTAT FUNCTIONS ##

def gstat_sim(clone,variogram,nsim=1,nodata=-9999,gstatexe="m:/progs/PCRaster/apps/gstat.exe"):
    chrset=[""]
    for i in range(0,26):
        chrset.append(chr(i+97))
    for i in range(0,26):
        for j in range(0,26):
            chrset.append(chr(i+97)+chr(j+97))
    for i in range(0,len(chrset)):
        modfile=setnewpath("_gs%s.mod" %(chrset[i]),1,2,0)
        if string.find(splitpath(modfile)[1],"(") == -1: break
    for i in range(0,len(chrset)):
        predmap=setnewpath("_gs%s" %(chrset[i]),1,2,0)
        if string.find(splitpath(predmap)[1],"(") == -1: break
    maskfile=False
    try:
        if os.path.isfile(clone):
            maskmap=clone; clone=readclone(maskmap); maskfile=True
    except: pass
    if not maskfile:
        for i in range(0,len(chrset)):
            maskmap=setnewpath("_gs%s.map" %(chrset[i]),1,2,0)
            if string.find(splitpath(maskmap)[1],"(") == -1: break
        array2spatial(3,ones((clone[6],clone[7]),uint8),maskmap,clone,nodata)
    outf=open(modfile,"w")
    outf.write("data(v): dummy, sk_mean=0.0, max=10;\n")
    outf.write("variogram(v): %s;\n" %(variogram))
    outf.write("mask: '%s';\n" %(os.path.normpath(maskmap)))
    outf.write("method: gs;\n")
    outf.write("set nsim=%d;\n" %(nsim))
    outf.write("predictions(v): '%s';\n" %(os.path.normpath(predmap)))
    outf.close()
    os.system('start "gstat_sim" /WAIT /MIN "%s" "%s"' %(os.path.normpath(gstatexe),os.path.normpath(modfile)))
    if nsim == 1:
        predarr=spatial2array(predmap,nodata)
    else:
        predarr=zeros((nsim,clone[6],clone[7]),float32)
        form="%%0%dd" %(11-len(splitpath(predmap)[1]))
        for i in range(0,nsim):
            predmap1=predmap+form %(i+1); predmap1=predmap1[:-3]+"."+predmap1[-3:]
            predarr[i]=spatial2array(predmap1,nodata)
            os.remove(predmap1)
    if os.path.isfile(predmap):
        os.remove(predmap)
    if os.path.isfile(modfile): os.remove(modfile)
    if not maskfile:
        if os.path.isfile(maskmap): os.remove(maskmap)
    return predarr

## Shape to raster: output raster with indices of shapes; shp2arr1 is faster
def shp2arr(f_shape,clone,precision=0,frac=0.25,st=None,reform=True):

    sf=shapefile.Reader(f_shape)
    shps=sf.shapes()

    lut_st=[["point",1],["line",3],["polygon",5]]
    if st != None: l_st=[lookup(string.lower(st),lut_st,5)]*len(shps)
    else: l_st=[shps[i].shapeType for i in range(0,len(shps))]

    xll,yll,csx,csy,proj,ang,nrow,ncol=readclone(clone)
    xmin=xll+rounddown(min(sf.bbox[0],sf.bbox[2])-xll,csx)
    xmax=xmin+around((max(sf.bbox[0],sf.bbox[2])-xmin)/csx,0)*csx
    if proj == 1:
        ymin=yll+rounddown(min(sf.bbox[1],sf.bbox[3])-yll,csy)
        ymax=ymin+around((max(sf.bbox[1],sf.bbox[3])-ymin)/csy,0)*csy
    else:
        ymax=(yll-nrow*csy)+rounddown(min(sf.bbox[1],sf.bbox[3])-(yll-nrow*csy),csy)
        ymin=ymax+around((max(sf.bbox[1],sf.bbox[3])-ymax)/csy,0)*csy
    if (3 in l_st or 5 in l_st) and precision > 0:
        if not reform:
            nrow,ncol=int(around(abs(ymax-ymin)/csy,1)),int(around(abs(xmax-xmin)/csx,1))
            clone=[xmin,ymin,csx,csy,proj,ang,nrow,ncol]
            reform=True
        csx,csy=csx/(precision+1),csy/(precision+1)
    nrow0,ncol0=int(around(abs(ymax-ymin)/csy,1)),int(around(abs(xmax-xmin)/csx,1))
    clone0=[xmin,ymin,csx,csy,proj,ang,nrow0,ncol0]
    if not reform:
        clone=deepcopy(clone0)
        xll,yll,csx,csy,proj,ang,nrow,ncol=clone

    arr=zeros((nrow,ncol),int32)
    frac=ones((nrow,ncol),float32)*frac

    if 3 in l_st or 5 in l_st:

        for i in range(0,len(shps)):
            img=Image.new("P",(ncol0,nrow0),0)
            drw=ImageDraw.Draw(img)
            rc=take(swapaxes(xy2rc(swapaxes(shps[i].points,0,1),clone0),0,1),[1,0],1)
            try: prts=shps[i].parts.tolist()+[len(rc)]
            except: prts=[0,len(pnts)]
            if l_st[i] == 3:
                for j in range(0,len(prts)-1):
                    drw.line(ravel(rc[prts[j]:prts[j+1]]).tolist(),fill=1)
            elif l_st[i] == 5:
                for j in range(0,len(prts)-1):
                    drw.polygon(ravel(rc[prts[j]:prts[j+1]]).tolist(),fill=1)

            arr0=array(reshape(array(img.getdata()),(nrow0,ncol0)),float32)
            if reform:
                arr0=array2resample(arr0,clone0,clone,True,-1,"avg")[0]
            arr=where(arr0 > frac,i+1,arr)
            frac=maximum(arr0,frac)

    if 1 in l_st:
        for i in range(0,len(shps)):
            if l_st[i] == 1:
                rc=xy2rc(swapaxes(shps[i].points,0,1),clone0)
                arr[rc[0],rc[1]]=where(arr[rc[0],rc[1]] == 0,i+1,arr[rc[0],rc[1]])

    return array(arr,uint32),clone

## Shape to raster: output raster with 1 for all shapes  >> faster than shp2arr
def shp2arr1(f_shape,clone,precision=0,frac=0.25,st=None,reform=True):

    sf=shapefile.Reader(f_shape)
    shps=sf.shapes()

    lut_st=[["point",1],["line",3],["polygon",5]]
    if st != None: l_st=[lookup(string.lower(st),lut_st,5)]*len(shps)
    else: l_st=[shps[i].shapeType for i in range(0,len(shps))]

    xll,yll,csx,csy,proj,ang,nrow,ncol=readclone(clone)
    xmin=xll+rounddown(min(sf.bbox[0],sf.bbox[2])-xll,csx)
    xmax=xmin+around((max(sf.bbox[0],sf.bbox[2])-xmin)/csx,0)*csx
    if proj == 1:
        ymin=yll+rounddown(min(sf.bbox[1],sf.bbox[3])-yll,csy)
        ymax=ymin+around((max(sf.bbox[1],sf.bbox[3])-ymin)/csy,0)*csy
    else:
        ymax=(yll-nrow*csy)+rounddown(min(sf.bbox[1],sf.bbox[3])-(yll-nrow*csy),csy)
        ymin=ymax+around((max(sf.bbox[1],sf.bbox[3])-ymax)/csy,0)*csy
    if (3 in l_st or 5 in l_st) and precision > 0:
        if not reform:
            nrow,ncol=int(around(abs(ymax-ymin)/csy,1)),int(around(abs(xmax-xmin)/csx,1))
            clone=[xmin,ymin,csx,csy,proj,ang,nrow,ncol]
            reform=True
        csx,csy=csx/(precision+1),csy/(precision+1)
    nrow0,ncol0=int(around(abs(ymax-ymin)/csy,1)),int(around(abs(xmax-xmin)/csx,1))
    clone0=[xmin,ymin,csx,csy,proj,ang,nrow0,ncol0]
    if not reform:
        clone=deepcopy(clone0)

    arr=zeros((nrow0,ncol0),int32)

    if 3 in l_st or 5 in l_st:

        img=Image.new("P",(ncol0,nrow0),0)
        drw=ImageDraw.Draw(img)

        for i in range(0,len(shps)):
            rc=take(swapaxes(xy2rc(swapaxes(shps[i].points,0,1),clone0),0,1),[1,0],1)
            try: prts=shps[i].parts.tolist()+[len(rc)]
            except: prts=[0,len(pnts)]
            if l_st[i] == 3:
                for j in range(0,len(prts)-1):
                    drw.line(ravel(rc[prts[j]:prts[j+1]]).tolist(),fill=1)
            elif l_st[i] == 5:
                for j in range(0,len(prts)-1):
                    drw.polygon(ravel(rc[prts[j]:prts[j+1]]).tolist(),fill=1)

        arr=array(reshape(array(img.getdata()),(nrow0,ncol0)),int32)

    if 1 in l_st:
        for i in range(0,len(shps)):
            if l_st[i] == 1:
                rc=xy2rc(swapaxes(shps[i].points,0,1),clone0)
                arr[rc[0],rc[1]]=1

    if reform:
        arr=array(where(array2resample(array(arr,float32),clone0,clone,True,-1,"avg")[0] >= frac,1,0),uint32)

    return array(arr,uint8),clone

