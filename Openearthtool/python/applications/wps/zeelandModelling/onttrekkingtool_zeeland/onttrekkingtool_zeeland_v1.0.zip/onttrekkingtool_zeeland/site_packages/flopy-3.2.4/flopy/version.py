# flopy version file

major = 3
minor = 2
micro = 4
commit = 1265

__version__ = '{:d}.{:d}.{:d}'.format(major, minor, micro)
__build__ = '{:d}.{:d}.{:d}.{:d}'.format(major, minor, micro, commit)
