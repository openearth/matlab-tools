#### IMPORTS ####

from general_func import get_power10, roundoff, rounddown, roundup
import numpy as np
import numpy.ma as ma
import pylab
from pylab import *
import string
from copy import deepcopy


#### SCALES, LEGENDS, BOUNDARIES ####

class legendScale(dict):

    def __init__(self,data=None,n=None,scale_type="linear",perc_bnd=[0,100],colorscale="jet"):

        self.__boundaries=[]
        self.__frm="%s"
        self.__ticks=[]
        self.__labels=[]
        self.__imodlabels=[]
        self.__colorscale=colorscale
        self.__rgba=np.array([])
        self.__cmap=None

        if type(data) != type(None):
            self.setBoundaries(data,n,scale_type,perc_bnd)
            self.setLegend(self.__colorscale)

    def __str__(self):
        """Method to create a string representation of the legendScale object.

        Returns
        -------
        result : str
            String of the raster data array.
        """
        s=""
        s+="boundaries:\n %s\n" %(self.__boundaries)
        s+="frm: %s\n" %(self.__frm)
        s+="ticks: %s\n" %(self.__ticks)
        s+="labels: %s\n" %(self.__labels)
        s+="imodlabels: %s\n" %(self.__imodlabels)
        s+="colorscale: %s\n" %(self.__colorscale)
        s+="rgba:\n %s\n" %(self.__rgba)
        return s

    def copy(self):
        return deepcopy(self)

    def getBoundaries(self):
        return self.__boundaries

    def getFrm(self):
        return self.__frm

    def getTicks(self):
        return self.__ticks

    def getLabels(self):
        return self.__labels

    def getImodLabels(self):
        return self.__imodlabels

    def getColorscale(self):
        return self.__colorscale

    def getRgba(self):
        return self.__rgba

    def getCmap(self):
        return self.__cmap

    def setBoundaries(self,data,n=None,scale_type="linear",perc_bnd=[0,100]):
        """Method to set suitable boundary values (intervals) for classification of the data.

        The boundaries may be used for classification into legends (colour scales), histogram bins etc.

        Parameters
        ----------
        data : numpy array (ndarray or MaskedArray) or array_like
            The data to base the boundaries on. Masked values will not be included in the determination of the boundaries.

        n : int or None (optional)
            Number of intervals. This is an initial number; the final number of intervals may differ depending on the determined interval width.

            If *n* is None then the initial number of intervals will be 8.

        scale_type : str (optional)
            Two types are supported: 'linear' and 'histogram'.

            If *scale_type* is 'linear' then the intervals will have equal widths.

            If *scale_type* is 'histogram' then the interval widths will be based on the distribution of values (percentiles).

        perc_bnd : numpy array or array_like (optional)
            Lower and upper percentiles to be used as initial minimum and maximum boundary values.

        Returns
        -------
        boundaries : numpy ndarray
            Boundaries values.

        frm : str
            String format (% format) to format the boundaries values.
        """

        ## Convert data to a flattened numpy ndarray; input data could be masked_array, ndarray or array-like
        try:
            data.gi(); data=data[:]
        except:
            pass
        data=ma.array(data)

        if np.rank(data.mask) != 0:
            data=np.compress(np.ravel(data.mask) != True,np.ravel(data.data))
        else:
            data=np.ravel(data.data)

        ## If only nodata set boundaries to nan
        if len(data) == 0:

            boundaries=np.array([-1e31,1e31])
            frm="%s"

        else:

            ## Get minimum and maximum value between given percentile boundaries
            perc_bnd=np.array(perc_bnd)
            if len(data) > 1:
                vmin=float(np.percentile(data,max(0,perc_bnd.min())))
                vmax=float(np.percentile(data,min(100,perc_bnd.max())))
            else:
                vmin,vmax=float(data.min()),float(data.max())

            ## If min and max are the same set boundaries to this value
            if vmin == vmax:

                ####interval=10**get_power10(vmax)/float(n)
                ####interval_base=10**get_power10(interval)
                ####interval=roundoff(interval,interval_base)
                ####vmin=roundoff(vmin-(n/2)*interval,interval_base)
                ####vmax=roundoff(vmin+n*interval,interval_base)
                boundaries=np.array([vmin,vmax+10**(get_power10(vmax)-7)])
                interval=0

            else:

                ## Set initial number of intervals; default = 8, minimum = 1.
                if n == None:
                    n=8
                n=max(1,n)

                ## Determine boundaries
                vmin0,vmax0=vmin,vmax
                vspan=vmax-vmin
                interval=vspan/float(n)
                interval_base=10**get_power10(interval)
                interval=roundoff(interval,interval_base)
                vmin=rounddown(vmin,interval_base*10)
                vmax=roundup(vmax,interval_base*10)

                if scale_type != "linear" and len(data) > 1:
                    boundaries=np.array([vmin]+[np.percentile(data,p) for p in np.arange(100./n,100.-100./(n*2),100./n)]+[vmax])
                    dboundaries=boundaries[1:]-boundaries[:-1]
                    boundaries=np.concatenate([boundaries[:1],np.compress(dboundaries != 0,boundaries[1:])])
                    interval=np.compress(dboundaries != 0,dboundaries).min()
                else:
                    boundaries=np.arange(vmin,vmax+interval,interval)
                    cp=np.ones((len(boundaries),),bool)
                    for i in range(0,len(boundaries)-1):
                        if boundaries[i+1] <= vmin0+interval_base*1e-7:
                            cp[i]=False
                        else:
                            break
                    for i in range(1,len(boundaries)):
                        if boundaries[-i-1] >= vmax0-interval_base*1e-7:
                            cp[-i]=False
                        else:
                            break
                    boundaries=np.compress(cp,boundaries)

                ## If number of intervals is 1 then force this
                if n == 1:
                    boundaries=boundaries[[0,-1]]

            ## Determine string format (%-format)
            pwr1=get_power10(interval)
            if pwr1 >= 0: pwr1+=1
            pwr2=get_power10(vmax)
            if pwr2 >= 0: pwr2+=1
            nsig=pwr2-pwr1+1
            if pwr1 < 0:
                ndeci=abs(pwr1)
                ndigit=max(ndeci+2,nsig)
            else:
                ndeci=0
                ndigit=nsig
            if ndigit > nsig+4: frm="%%.%de" %(nsig-1)
            else: frm="%%.%df" %(ndeci)

        self.__boundaries=boundaries.copy()
        self.__frm=frm

        self.setTicks()
        self.setLabels()
        self.setLegend()

    def putBoundaries(self,boundaries):

        self.__boundaries=np.array(boundaries,np.float64).copy()
        self.setTicks()
        self.setLabels()
        self.setLegend()

    def setUnder(self,rgba=None):

        if min(self.__boundaries) >= -1e30:
            if type(rgba) == type(None) and type(self.__colorscale) == type(None):
                rgba=np.array([0.5,0.5,0.5,1.0])
            elif type(rgba) != type(None):
                rgba=np.array([v for v in rgba]+[1.,1.,1.,1.])[:4]
            else:
                rgba=None
            if self.__boundaries[0] >= self.__boundaries[-1]:
                self.__boundaries=np.insert(self.__boundaries,len(self.__boundaries),-1e31)
                if type(rgba) != type(None):
                    self.__rgba=np.insert(self.__rgba,len(self.__rgba),rgba[:4],0)
            else:
                self.__boundaries=np.insert(self.__boundaries,0,-1e31)
                if type(rgba) != type(None):
                    self.__rgba=np.insert(self.__rgba,0,rgba[:4],0)
            self.setTicks()
            self.setLabels()
            if len(self.__imodlabels) == len(self.__labels)-1:
                if self.__boundaries[0] >= self.__boundaries[-1]:
                    self.__imodlabels+=[string.replace(self.__labels[-1],"< ","<= ")]
                else:
                    self.__imodlabels=[string.replace(self.__labels[0],"< ","<= ")]+self.__imodlabels
            self.setImodLabels()
            self.setLegend()

    def setOver(self,rgba=None):

        if max(self.__boundaries) <= 1e30:
            if type(rgba) == type(None) and type(self.__colorscale) == type(None):
                rgba=np.array([0.25,0.25,0.25,1.0])
            elif type(rgba) != type(None):
                rgba=np.array([v for v in rgba]+[1.,1.,1.,1.])[:4]
            else:
                rgba=None
            if self.__boundaries[0] <= self.__boundaries[-1]:
                self.__boundaries=np.insert(self.__boundaries,len(self.__boundaries),1e31)
                if type(rgba) != type(None):
                    self.__rgba=np.insert(self.__rgba,len(self.__rgba),rgba[:4],0)
            else:
                self.__boundaries=np.insert(self.__boundaries,0,1e31,0)
                if type(rgba) != type(None):
                    self.__rgba=np.insert(self.__rgba,0,rgba[:4])
            self.setTicks()
            self.setLabels()
            if len(self.__imodlabels) == len(self.__labels)-1:
                if self.__boundaries[0] <= self.__boundaries[-1]:
                    self.__imodlabels+=[self.__labels[-1]]
                else:
                    self.__imodlabels=[self.__labels[0]]+self.__imodlabels
            self.setImodLabels()
            self.setLegend()

    def setTicks(self):

        self.__ticks=[]

        if len(self.__boundaries) > 0:

            if self.__boundaries[0] < -1e30:   self.__ticks+=["<"]
            elif self.__boundaries[0] > 1e30:  self.__ticks+=[">"]
            else:                              self.__ticks+=[self.__frm %(self.__boundaries[0])]
            for x in self.__boundaries[1:-1]:  self.__ticks+=[self.__frm %(x)]
            if self.__boundaries[-1] < -1e30:  self.__ticks+=["<"]
            elif self.__boundaries[-1] > 1e30: self.__ticks+=[">"]
            else:                              self.__ticks+=[self.__frm %(self.__boundaries[-1])]

    def putTicks(self,ticks):

        if len(ticks) == len(self.__boundaries):
            self.__ticks=ticks[:]

    def setLabels(self):

        self.__labels=[]

        if len(self.__boundaries) > 1:

            if self.__boundaries[0] < -1e30:
                self.__labels+=["< %s" %(self.__frm %(self.__boundaries[1]))]
            elif self.__boundaries[0] > 1e30:
                self.__labels+=["> %s" %(self.__frm %(self.__boundaries[1]))]
            elif self.__boundaries[0] <= 0 and self.__boundaries[1] <= 0:
                self.__labels+=["%s - %s" %(self.__frm %(max(self.__boundaries[0],self.__boundaries[1])),self.__frm %(min(self.__boundaries[0],self.__boundaries[1])))]
            else:
                self.__labels+=["%s - %s" %(self.__frm %(min(self.__boundaries[0],self.__boundaries[1])),self.__frm %(max(self.__boundaries[0],self.__boundaries[1])))]
            if len(self.__boundaries) > 2:
                for i in range(1,len(self.__boundaries)-2):
                    if self.__boundaries[i] <= 0 and self.__boundaries[i+1] <= 0:
                        self.__labels+=["%s - %s" %(self.__frm %(max(self.__boundaries[i],self.__boundaries[i+1])),self.__frm %(min(self.__boundaries[i],self.__boundaries[i+1])))]
                    else:
                        self.__labels+=["%s - %s" %(self.__frm %(min(self.__boundaries[i],self.__boundaries[i+1])),self.__frm %(max(self.__boundaries[i],self.__boundaries[i+1])))]
                if self.__boundaries[-1] < -1e30:
                    self.__labels+=["< %s" %(self.__frm %(self.__boundaries[-2]))]
                elif self.__boundaries[-1] > 1e30:
                    self.__labels+=["> %s" %(self.__frm %(self.__boundaries[-2]))]
                elif self.__boundaries[-1] <= 0 and self.__boundaries[-2] <= 0:
                    self.__labels+=["%s - %s" %(self.__frm %(max(self.__boundaries[-1],self.__boundaries[-2])),self.__frm %(min(self.__boundaries[-1],self.__boundaries[-2])))]
                else:
                    self.__labels+=["%s - %s" %(self.__frm %(min(self.__boundaries[-1],self.__boundaries[-2])),self.__frm %(max(self.__boundaries[-1],self.__boundaries[-2])))]

    def putLabels(self,labels):

        if len(labels) == len(self.__boundaries)-1:
            self.__labels=labels[:]

    def setImodLabels(self):

        if len(self.__imodlabels) < len(self.__boundaries)-1:
            self.__imodlabels=deepcopy(self.__labels)

    def putImodLabels(self,imodlabels):

        if len(imodlabels) == len(self.__boundaries)-1:
            self.__imodlabels=imodlabels

    def setLegend(self,colorscale=None,alfa=1):

        if colorscale == None:
            colorscale=self.__colorscale

        n=len(self.__boundaries)-1

        if n <= 0:

            self.__rgba=np.array([])
            self.__cmap=None

        else:

            if colorscale != None:

                l_colorscale=[
                    "Red2lYel",\
                    "dRed2lYel",\
                    "Red2Whi",\
                    "dRed2Whi",\
                    "Red2lRed",\
                    "dRed2lRed",\
                    "Blu2Whi",\
                    "dBlu2Whi",\
                    "Blu2lBlu",\
                    "dBlu2lBlu",\
                    "Red2Whi2Blu",\
                    "dRed2Whi2dBlu",\
                    "Red2Gry2Blu",\
                    "dRed2Gry2dBlu",\
                    "dRed2dBlu_dif",\
                    "Red2Whi2Gre",\
                    "Red2Gry2Gre",\
                    "BluGrnYelRed",\
                    "regenboog",\
                    ]

                l_rgba=[
                    [(255,0,0),(255,60,0),(255,102,0),(255,153,0),(255,204,0),(255,240,0),(255,255,68),(255,255,136),(255,255,204)],\
                    [(153,0,0),(204,0,0),(255,0,0),(255,60,0),(255,102,0),(255,153,0),(255,204,0),(255,240,0),(255,255,68),(255,255,136),(255,255,204)],\
                    [(255,0,0),(255,195,195),(255,255,255)],\
                    [(153,0,0),(255,0,0),(255,195,195),(255,255,255)],\
                    [(255,0,0),(255,240,240)],\
                    [(153,0,0),(255,0,0),(255,120,120),(255,240,240)],\
                    [(0,0,255),(195,195,255),(255,255,255)],\
                    [(0,0,153),(0,0,255),(195,195,255),(255,255,255)],\
                    [(0,0,255),(240,240,255)],\
                    [(0,0,153),(0,0,255),(120,120,255),(240,240,255)],\
                    [(255,0,0),(255,195,195),(255,255,255),(195,195,255),(0,0,255)],\
                    [(153,0,0),(255,0,0),(255,195,195),(255,255,255),(195,195,255),(0,0,255),(0,0,153)],\
                    [(255,0,0),(255,195,195),(255,255,255),(195,195,255),(0,0,255)],\
                    [(153,0,0),(255,0,0),(255,195,195),(255,255,255),(195,195,255),(0,0,255),(0,0,153)],\
                    [(153,0,0),(204,0,0),(255,0,0),(255,60,0),(255,102,0),(255,153,0),(255,204,0),(255,240,0),(255,255,68),(255,255,136),(255,255,204),(255,255,255),(204,255,255),(136,255,255),(68,255,255),(0,240,255),(0,204,255),(0,153,255),(0,102,255),(0,60,255),(0,0,255),(0,0,199),(0,0,143)],\
                    [(255,0,0),(255,255,255),(0,255,0)],\
                    [(255,0,0),(255,255,255),(0,255,0)],\
                    [(0,0,255),(0,153,0),(0,255,0),(255,255,153),(255,255,0),(255,204,0),(255,102,0),(255,0,0),(153,0,0),(102,0,0)],\
                    [(255,0,0),(255,204,0),(255,255,0),(190,255,0),(0,255,0),(0,255,255),(0,190,255),(0,0,255),(127,0,255),(255,0,255),(255,0,127)]
                    ]

                if colorscale in l_colorscale or (colorscale[-2:] == "_r" and colorscale[:-2] in l_colorscale):

                    if colorscale[-2:] == "_r":
                        rgba=l_rgba[l_colorscale.index(colorscale[:-2])][::-1]
                    else:
                        rgba=l_rgba[l_colorscale.index(colorscale)]

                    rgba=[(x+(alfa*255,))[:4] for x in rgba]
                    rgba=np.array(rgba)

                    d=(len(rgba)-1.)/(n-1.)
                    i=np.arange(0,len(rgba)-1+d-1e-8,d)
                    i1=np.array(i,uint32)
                    i2=minimum(i1+1,len(rgba)-1)
                    f1=np.repeat(np.reshape(1-np.mod(i,1),(len(i),1)),4,1)
                    f2=1-f1

                    rgba=(rgba[i1]*f1+rgba[i2]*f2)/255.

                    if colorscale in ["Red2Gry2Blu","dRed2Gry2dBlu","dRed2dBlu_dif","Red2Gry2Gre"] and n%2 == 1:
                        rgba[n/2,:3]=[0.85,0.85,0.85]

                else:

                    rgba=np.array([get_color(i,[0,n-1],colorscale) for i in range(0,n)])
                    rgba[:,3]=alfa

                self.__rgba=rgba.copy()

            if len(self.__rgba) == len(self.__boundaries)-1:

                if min(self.__boundaries) < -1e30 and max(self.__boundaries) > 1e30 and len(self.__boundaries) >= 4:
                    self.__cmap=matplotlib.colors.ListedColormap(self.__rgba[1:-1])
                    if self.__boundaries[0] < self.__boundaries[-1]:
                        self.__cmap.set_under(self.__rgba[0])
                        self.__cmap.set_over(self.__rgba[-1])
                    else:
                        self.__cmap.set_under(self.__rgba[-1])
                        self.__cmap.set_over(self.__rgba[0])
                elif min(self.__boundaries) < -1e30 and len(self.__boundaries) >= 3:
                    if self.__boundaries[0] < self.__boundaries[-1]:
                        self.__cmap=matplotlib.colors.ListedColormap(self.__rgba[1:])
                        self.__cmap.set_under(self.__rgba[0])
                    else:
                        self.__cmap=matplotlib.colors.ListedColormap(self.__rgba[:-1])
                        self.__cmap.set_under(self.__rgba[-1])
                elif max(self.__boundaries) > 1e30 and len(self.__boundaries) >= 3:
                    if self.__boundaries[0] < self.__boundaries[-1]:
                        self.__cmap=matplotlib.colors.ListedColormap(self.__rgba[:-1])
                        self.__cmap.set_over(self.__rgba[-1])
                    else:
                        self.__cmap=matplotlib.colors.ListedColormap(self.__rgba[1:])
                        self.__cmap.set_over(self.__rgba[0])
                else:
                    self.__cmap=matplotlib.colors.ListedColormap(self.__rgba)

            else:

                self.__rgba=np.array([])
                self.__cmap=None

    def putRgba(self,rgba):

        if len(rgba) == len(self.__boundaries)-1:
            self.__rgba=np.array(rgba,np.float64).copy()
            self.__colorscale=None
            self.setLegend()

    def write_imod_leg(self,f_leg):

        rgba=np.array(self.__rgba.copy()*255,np.uint8)
        self.setImodLabels()
        lines=[]
        for i in range(0,len(self.__boundaries)-1):
            label=self.__imodlabels[i].replace("< ","<= ")
            lines+=['%9G %9G %6d %6d %6d "%s"' %(max(self.__boundaries[i],self.__boundaries[i+1]),min(self.__boundaries[i],self.__boundaries[i+1]),rgba[i,0],rgba[i,1],rgba[i,2],label)]
        if self.__boundaries[0] < self.__boundaries[-1]:
            lines=lines[::-1]

        outf=open(f_leg,"w")
        outf.write("%d 1 0 0 0 0 0 1\n" %(len(lines)))
        outf.write("UPPER_BND LOWER_BND   IRED IGREEN  IBLUE DOMAIN\n")
        outf.write("%s\n" %(string.join(lines,"\n")))
        outf.close()

    def make_figure(self,labels=False):

        bounds=self.__boundaries.copy()
        if bounds[0] < -1e30 or bounds[0] > 1e30:
            bounds=bounds[1:]
        if bounds[-1] < -1e30 or bounds[-1] > 1e30:
            bounds=bounds[:-1]

        if labels:
            ticklocs=(self.__boundaries[1:]+self.__boundaries[:-1])*0.5
            ticklabels=self.__labels
        else:
            ticklocs=self.__boundaries
            ticklabels=self.__ticks

        fig=figure(figsize=(1.5,(len(self.__boundaries)-1)/3.5))
        ax=axes([0.05,0.1,0.25,0.8],frameon=False,xticks=[],yticks=[])
        norm=matplotlib.colors.BoundaryNorm(bounds,self.__cmap.N)
        cb=matplotlib.colorbar.ColorbarBase(ax,cmap=self.__cmap,norm=norm,boundaries=self.__boundaries,extend="neither",ticks=ticklocs)
        cb.set_ticklabels(ticklabels)
        setp(cb.ax.get_ymajorticklabels(),fontname="Arial",fontsize=10,fontweight="normal",color=(0,0,0,1))

        if labels:
            setp(cb.ax.get_yticklines(),alpha=0)

        return fig

def get_color(v,v_minmax=None,colorscale="jet",return_r=False):
    if v_minmax == None: v_minmax=[0,1]
    if v_minmax[0] == v_minmax[1]: r=0.5
    else: r=max(0.0,min(1.0,float(v-min(v_minmax))/float(max(v_minmax)-min(v_minmax))))
    if return_r: return r
    else:
        cmap=plt.get_cmap(colorscale)
        return cmap(r)

def read_imod_leg(f_leg):
    inf=open(f_leg,"r"); lines=inf.readlines(); inf.close()
    n=int(lines[0].replace(","," ").split()[0])
    boundaries,rgba,labels=[],[],[]
    for i in range(2,2+n):
        rec=string.split(lines[i].strip().replace(","," "),maxsplit=5)
        if len(boundaries) == 0:
            boundaries+=[float(rec[0])]
        boundaries+=[float(rec[1])]
        rgba+=[(float(rec[2])/255.,float(rec[3])/255.,float(rec[4])/255.,1.0)]
        labels+=[rec[-1].replace('"',"")]
    legScale=legendScale(colorscale=None)
    if boundaries[0] < boundaries[-1]:
        legScale.putBoundaries(boundaries)
        legScale.putRgba(rgba)
        legScale.putImodLabels(labels)
    else:
        legScale.putBoundaries(boundaries[::-1])
        legScale.putRgba(rgba[::-1])
        legScale.putImodLabels(labels[::-1])
    return legScale

def closegraph():
    pylab.clf(); pylab.close('all')

def closefig():
    closegraph()
