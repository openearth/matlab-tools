FAST viewer back-end tools
==========================

This package provides a set of tools developed in the frame of the European project 
FAST (Project FAST EU FP7 Space) by Deltares.

A Web-viewer has been developed for FAST. Front end applications and WPS back end 
applications have been created as a support to the Web-viewer. This package contains
the back end applications only.