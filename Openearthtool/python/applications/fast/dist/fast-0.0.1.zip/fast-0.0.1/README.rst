FAST viewer back-end tools
==========================

This package provides a set of tools developed in the frame of the European project 
FAST (Project FAST EU FP7 Space) by Deltares. Further information `here <https://packaging.python.org/en/latest/distributing.html>`_.