This netCDF DLL was generated using visual studio.

To use the DLL from C, include netcdf.h and set pre-processor macro DLL_NETCDF.
To use the DLL from Fortran, include netcdf.inc.
